import { useState, useEffect, useCallback } from "react";

const NICHES = [
  { id: "tech", label: "Tech & AI", emoji: "🤖", color: "#00d4ff" },
  { id: "motivation", label: "Motivation", emoji: "🔥", color: "#ff6b35" },
  { id: "finance", label: "Finance Tips", emoji: "💰", color: "#00ff88" },
  { id: "lifestyle", label: "Lifestyle", emoji: "✨", color: "#ff6fd8" },
  { id: "coding", label: "Coding", emoji: "💻", color: "#a78bfa" },
  { id: "travel", label: "Travel", emoji: "🌍", color: "#fbbf24" },
  { id: "business", label: "Business", emoji: "📈", color: "#34d399" },
  { id: "humor", label: "Comedy", emoji: "😂", color: "#f87171" },
];

const TIME_SLOTS = [
  { id: "morning", label: "Morning Drop", time: "9:00 AM", icon: "🌅", peak: "High Engagement" },
  { id: "afternoon", label: "Lunch Rush", time: "1:00 PM", icon: "⚡", peak: "Gift Peak" },
  { id: "evening", label: "Prime Time", time: "7:00 PM", icon: "🌙", peak: "Max Reach" },
];

const CONTENT_HOOKS = {
  tech: ["Nobody told you AI can do THIS…", "This free tool is replacing entire teams", "I automated my $5k/month income using this"],
  motivation: ["The 5am habit that changed everything", "Stop being broke. Start doing this.", "They laughed. Then I made $10k."],
  finance: ["The financial trap 90% fall into", "How I saved $500 this month doing nothing", "This investment nobody talks about"],
  lifestyle: ["The morning routine that makes me unstoppable", "I stopped doing this and my life changed", "Things rich people do differently"],
  coding: ["Built a SaaS in 3 hours using this", "The coding trick seniors don't want you to know", "This one line of code saved me 40 hours"],
  travel: ["This country is cheaper than your city", "Travel hack airlines don't want shared", "I live in paradise for $800/month"],
  business: ["Client paid me $3k for this 2-hour task", "Fiverr gig making $200/day (nobody's doing this)", "The business model printing money right now"],
  humor: ["POV: You're a freelancer at 3am", "My client called. I panicked.", "When the deadline is tomorrow and you just started"],
};

const CAPTION_TEMPLATES = [
  "💡 SAVE THIS before it disappears from your feed!\n\n{hook}\n\n{tip1}\n{tip2}\n{tip3}\n\nDrop a 🔥 if this helped you!\n\n{hashtags}",
  "🚨 This is the sign you needed.\n\n{hook}\n\n{tip1}\n{tip2}\n{tip3}\n\nTag someone who NEEDS to see this! 👇\n\n{hashtags}",
  "✅ Bookmark this RIGHT NOW.\n\n{hook}\n\n{tip1}\n{tip2}\n{tip3}\n\nWhat do you think? Comment below! 💬\n\n{hashtags}",
];

function Spinner() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div className="spinner" />
      <span style={{ color: "#888", fontSize: 13 }}>Claude is writing your content…</span>
    </div>
  );
}

function MetricCard({ label, value, sub, color, icon }) {
  return (
    <div className="metric-card" style={{ "--accent": color }}>
      <div className="metric-icon">{icon}</div>
      <div className="metric-value" style={{ color }}>{value}</div>
      <div className="metric-label">{label}</div>
      {sub && <div className="metric-sub">{sub}</div>}
    </div>
  );
}

function ContentCard({ item, onRegenerate, loading, slotId }) {
  const [copied, setCopied] = useState(false);

  const copy = (text) => {
    navigator.clipboard.writeText(text).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="content-card">
      <div className="slot-header">
        <span className="slot-badge" style={{ color: item.slotColor }}>
          {item.slotIcon} {item.slotLabel}
        </span>
        <span className="slot-time">{item.slotTime}</span>
        <span className="peak-badge">{item.peak}</span>
      </div>

      {loading ? (
        <div className="loading-state"><Spinner /></div>
      ) : item.script ? (
        <>
          <div className="hook-line">🎣 Hook: <span>{item.hook}</span></div>
          <div className="script-block">
            <div className="block-label">📝 Script</div>
            <pre className="script-text">{item.script}</pre>
          </div>
          <div className="script-block">
            <div className="block-label">📸 Caption</div>
            <pre className="script-text caption-text">{item.caption}</pre>
          </div>
          <div className="hashtag-row">
            {item.hashtags?.split(" ").slice(0, 8).map((h, i) => (
              <span key={i} className="hashtag">{h}</span>
            ))}
          </div>
          <div className="card-actions">
            <button className="action-btn copy-btn" onClick={() => copy(`HOOK: ${item.hook}\n\nSCRIPT:\n${item.script}\n\nCAPTION:\n${item.caption}\n\nHASHTAGS:\n${item.hashtags}`)}>
              {copied ? "✅ Copied!" : "📋 Copy All"}
            </button>
            <button className="action-btn regen-btn" onClick={() => onRegenerate(slotId)}>
              🔄 Regenerate
            </button>
            <button className="action-btn schedule-btn">
              📅 Scheduled
            </button>
          </div>
        </>
      ) : (
        <div className="empty-state">
          <div className="empty-icon">🎬</div>
          <div>Generate content to fill this slot</div>
        </div>
      )}
    </div>
  );
}

export default function InstagramAutomation() {
  const [selectedNiche, setSelectedNiche] = useState(null);
  const [queue, setQueue] = useState({ morning: {}, afternoon: {}, evening: {} });
  const [loadingSlots, setLoadingSlots] = useState({});
  const [activeTab, setActiveTab] = useState("generator");
  const [generatingAll, setGeneratingAll] = useState(false);
  const [totalGenerated, setTotalGenerated] = useState(0);
  const [apiError, setApiError] = useState(null);

  const generateForSlot = useCallback(async (slotId, niche) => {
    if (!niche) return;
    const nicheData = NICHES.find(n => n.id === niche);
    const hooks = CONTENT_HOOKS[niche] || CONTENT_HOOKS.motivation;
    const randomHook = hooks[Math.floor(Math.random() * hooks.length)];
    const slot = TIME_SLOTS.find(s => s.id === slotId);

    setLoadingSlots(prev => ({ ...prev, [slotId]: true }));
    setApiError(null);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `You are an expert Instagram Reels content strategist. You specialize in creating viral, monetization-optimized content that drives gifts, followers, and branded partnerships. You write punchy, hook-driven scripts optimized for the ${slot.label} posting window (${slot.time}). Always return ONLY valid JSON, no markdown, no extra text.`,
          messages: [{
            role: "user",
            content: `Create a complete Instagram Reel content package for the "${nicheData.label}" niche.

Hook to use: "${randomHook}"

Return ONLY this JSON (no markdown, no backticks):
{
  "hook": "The exact opening hook line (max 10 words, punchy)",
  "script": "Full 45-60 second reel script with clear sections: [HOOK 0-5s], [VALUE 5-40s], [CTA 40-50s]. Use line breaks. Include gestures/visual cues in brackets.",
  "caption": "Engaging Instagram caption using the template with emojis, line breaks, call to action (200-300 chars)",
  "hashtags": "20 strategic hashtags mixing viral (#reels #viral) + niche-specific + mid-tier tags. Space-separated.",
  "tips": ["tip1", "tip2", "tip3"],
  "contentType": "One of: Tutorial | Storytime | POV | Listicle | Reaction | Transformation",
  "giftTrigger": "One specific line in the script designed to trigger viewer gifts/engagement"
}`
          }]
        })
      });

      const data = await response.json();
      if (data.error) throw new Error(data.error.message);

      const text = data.content.map(c => c.text || "").join("");
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);

      setQueue(prev => ({
        ...prev,
        [slotId]: {
          ...parsed,
          slotLabel: slot.label,
          slotTime: slot.time,
          slotIcon: slot.icon,
          slotColor: slotId === "morning" ? "#fbbf24" : slotId === "afternoon" ? "#f87171" : "#a78bfa",
          peak: slot.peak,
        }
      }));
      setTotalGenerated(p => p + 1);
    } catch (err) {
      setApiError(`Generation failed: ${err.message}`);
      setQueue(prev => ({
        ...prev,
        [slotId]: {
          hook: "Content generation failed",
          script: "Please try again.",
          caption: "",
          hashtags: "",
          slotLabel: slot.label,
          slotTime: slot.time,
          slotIcon: slot.icon,
          slotColor: "#888",
          peak: slot.peak,
        }
      }));
    } finally {
      setLoadingSlots(prev => ({ ...prev, [slotId]: false }));
    }
  }, []);

  const generateAll = async () => {
    if (!selectedNiche) return;
    setGeneratingAll(true);
    for (const slot of TIME_SLOTS) {
      await generateForSlot(slot.id, selectedNiche);
      await new Promise(r => setTimeout(r, 800));
    }
    setGeneratingAll(false);
  };

  const nicheData = NICHES.find(n => n.id === selectedNiche);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body { background: #080810; }

        .app {
          font-family: 'DM Sans', sans-serif;
          background: #080810;
          min-height: 100vh;
          color: #e8e8f0;
          padding: 0;
        }

        .header {
          background: linear-gradient(135deg, #0d0d20 0%, #130d2a 50%, #0d1a1f 100%);
          border-bottom: 1px solid rgba(255,255,255,0.06);
          padding: 20px 28px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          position: sticky;
          top: 0;
          z-index: 100;
          backdrop-filter: blur(20px);
        }

        .logo {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .logo-icon {
          width: 36px;
          height: 36px;
          background: linear-gradient(135deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 18px;
        }

        .logo-text {
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 17px;
          letter-spacing: -0.3px;
        }

        .logo-text span { 
          background: linear-gradient(135deg, #f09433, #dc2743, #bc1888);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .header-status {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          color: #00ff88;
          background: rgba(0,255,136,0.08);
          border: 1px solid rgba(0,255,136,0.2);
          padding: 5px 12px;
          border-radius: 20px;
        }

        .status-dot {
          width: 6px;
          height: 6px;
          background: #00ff88;
          border-radius: 50%;
          animation: pulse 2s infinite;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }

        .metrics-row {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 14px;
          padding: 24px 28px 0;
        }

        .metric-card {
          background: #0e0e1e;
          border: 1px solid rgba(255,255,255,0.07);
          border-radius: 14px;
          padding: 18px;
          display: flex;
          flex-direction: column;
          gap: 4px;
          position: relative;
          overflow: hidden;
          transition: border-color 0.2s;
        }

        .metric-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0; right: 0;
          height: 2px;
          background: var(--accent, #888);
          opacity: 0.7;
        }

        .metric-icon { font-size: 20px; margin-bottom: 4px; }
        .metric-value {
          font-family: 'Syne', sans-serif;
          font-weight: 800;
          font-size: 24px;
          line-height: 1;
        }
        .metric-label { font-size: 12px; color: #666; font-weight: 500; }
        .metric-sub { font-size: 11px; color: #444; margin-top: 2px; }

        .tabs {
          display: flex;
          gap: 0;
          padding: 20px 28px 0;
          border-bottom: 1px solid rgba(255,255,255,0.06);
          margin-bottom: 0;
        }

        .tab {
          background: none;
          border: none;
          color: #555;
          font-family: 'DM Sans', sans-serif;
          font-size: 13px;
          font-weight: 500;
          padding: 10px 20px;
          cursor: pointer;
          border-bottom: 2px solid transparent;
          transition: all 0.2s;
          margin-bottom: -1px;
        }

        .tab.active {
          color: #e8e8f0;
          border-bottom-color: #dc2743;
        }

        .tab:hover:not(.active) { color: #999; }

        .main-content { padding: 24px 28px; }

        .section-title {
          font-family: 'Syne', sans-serif;
          font-size: 15px;
          font-weight: 700;
          letter-spacing: 0.5px;
          color: #888;
          text-transform: uppercase;
          margin-bottom: 14px;
        }

        .niche-grid {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 10px;
          margin-bottom: 24px;
        }

        .niche-btn {
          background: #0e0e1e;
          border: 1px solid rgba(255,255,255,0.07);
          border-radius: 12px;
          padding: 14px 10px;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 6px;
          font-family: 'DM Sans', sans-serif;
        }

        .niche-btn:hover {
          border-color: rgba(255,255,255,0.15);
          transform: translateY(-1px);
        }

        .niche-btn.selected {
          border-color: var(--nc);
          background: rgba(0,0,0,0.3);
          box-shadow: 0 0 20px rgba(0,0,0,0.5);
        }

        .niche-emoji { font-size: 22px; }
        .niche-label { font-size: 11px; color: #999; font-weight: 500; }
        .niche-btn.selected .niche-label { color: #e8e8f0; }

        .generate-bar {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 24px;
          padding: 16px 20px;
          background: #0e0e1e;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 14px;
        }

        .gen-info {
          flex: 1;
        }

        .gen-title {
          font-family: 'Syne', sans-serif;
          font-weight: 700;
          font-size: 14px;
          margin-bottom: 2px;
        }

        .gen-sub {
          font-size: 12px;
          color: #555;
        }

        .generate-btn {
          background: linear-gradient(135deg, #f09433, #dc2743, #bc1888);
          border: none;
          color: white;
          font-family: 'Syne', sans-serif;
          font-weight: 700;
          font-size: 13px;
          padding: 10px 20px;
          border-radius: 10px;
          cursor: pointer;
          transition: all 0.2s;
          white-space: nowrap;
        }

        .generate-btn:hover { opacity: 0.9; transform: translateY(-1px); }
        .generate-btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

        .queue-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 16px;
        }

        .content-card {
          background: #0e0e1e;
          border: 1px solid rgba(255,255,255,0.07);
          border-radius: 16px;
          padding: 18px;
          display: flex;
          flex-direction: column;
          gap: 14px;
          min-height: 340px;
        }

        .slot-header {
          display: flex;
          align-items: center;
          gap: 8px;
          flex-wrap: wrap;
        }

        .slot-badge {
          font-family: 'Syne', sans-serif;
          font-weight: 700;
          font-size: 13px;
        }

        .slot-time {
          font-size: 12px;
          color: #555;
          background: rgba(255,255,255,0.05);
          padding: 2px 8px;
          border-radius: 20px;
        }

        .peak-badge {
          font-size: 10px;
          color: #00ff88;
          border: 1px solid rgba(0,255,136,0.3);
          padding: 2px 8px;
          border-radius: 20px;
          margin-left: auto;
        }

        .hook-line {
          font-size: 12px;
          color: #888;
          font-style: italic;
          padding: 8px 12px;
          background: rgba(255,255,255,0.03);
          border-left: 2px solid #dc2743;
          border-radius: 0 6px 6px 0;
        }

        .hook-line span {
          color: #e8e8f0;
          font-style: normal;
          font-weight: 500;
        }

        .script-block {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .block-label {
          font-size: 11px;
          color: #555;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .script-text {
          font-family: 'DM Sans', sans-serif;
          font-size: 12px;
          color: #c0c0d0;
          line-height: 1.7;
          white-space: pre-wrap;
          word-break: break-word;
          background: rgba(255,255,255,0.03);
          border: 1px solid rgba(255,255,255,0.05);
          border-radius: 8px;
          padding: 10px 12px;
          max-height: 120px;
          overflow-y: auto;
        }

        .caption-text { max-height: 80px; }

        .script-text::-webkit-scrollbar { width: 4px; }
        .script-text::-webkit-scrollbar-track { background: transparent; }
        .script-text::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }

        .hashtag-row {
          display: flex;
          flex-wrap: wrap;
          gap: 5px;
        }

        .hashtag {
          font-size: 11px;
          color: #bc1888;
          background: rgba(188,24,136,0.08);
          border: 1px solid rgba(188,24,136,0.2);
          padding: 2px 8px;
          border-radius: 20px;
        }

        .card-actions {
          display: flex;
          gap: 8px;
          margin-top: auto;
        }

        .action-btn {
          flex: 1;
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.08);
          color: #aaa;
          font-family: 'DM Sans', sans-serif;
          font-size: 11px;
          font-weight: 500;
          padding: 7px 6px;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.15s;
          white-space: nowrap;
        }

        .action-btn:hover { background: rgba(255,255,255,0.08); color: #e8e8f0; }

        .copy-btn:hover { border-color: rgba(0,212,255,0.4); color: #00d4ff; }
        .regen-btn:hover { border-color: rgba(248,177,71,0.4); color: #fbbf24; }
        .schedule-btn { background: rgba(0,255,136,0.08); border-color: rgba(0,255,136,0.2); color: #00ff88; }

        .loading-state {
          flex: 1;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .empty-state {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 10px;
          color: #333;
          font-size: 13px;
        }

        .empty-icon { font-size: 32px; }

        .spinner {
          width: 16px;
          height: 16px;
          border: 2px solid rgba(255,255,255,0.1);
          border-top-color: #dc2743;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        .error-bar {
          background: rgba(248,113,113,0.08);
          border: 1px solid rgba(248,113,113,0.2);
          color: #f87171;
          padding: 10px 16px;
          border-radius: 10px;
          font-size: 12px;
          margin-bottom: 16px;
        }

        /* STRATEGY TAB */
        .strategy-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }

        .strategy-card {
          background: #0e0e1e;
          border: 1px solid rgba(255,255,255,0.07);
          border-radius: 14px;
          padding: 20px;
        }

        .strategy-card h3 {
          font-family: 'Syne', sans-serif;
          font-size: 14px;
          font-weight: 700;
          margin-bottom: 14px;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .strategy-item {
          display: flex;
          gap: 10px;
          margin-bottom: 12px;
          align-items: flex-start;
        }

        .strategy-num {
          width: 22px;
          height: 22px;
          border-radius: 50%;
          background: linear-gradient(135deg, #dc2743, #bc1888);
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 10px;
          font-weight: 700;
          flex-shrink: 0;
          margin-top: 1px;
        }

        .strategy-text { font-size: 12px; color: #aaa; line-height: 1.6; }
        .strategy-text strong { color: #e8e8f0; }

        .monetize-badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-size: 10px;
          padding: 3px 10px;
          border-radius: 20px;
          font-weight: 600;
          margin-top: 4px;
        }

        .badge-gift { background: rgba(251,191,36,0.1); color: #fbbf24; border: 1px solid rgba(251,191,36,0.2); }
        .badge-brand { background: rgba(0,212,255,0.1); color: #00d4ff; border: 1px solid rgba(0,212,255,0.2); }
        .badge-follow { background: rgba(0,255,136,0.1); color: #00ff88; border: 1px solid rgba(0,255,136,0.2); }

        .stack-card {
          background: #0e0e1e;
          border: 1px solid rgba(255,255,255,0.07);
          border-radius: 14px;
          padding: 20px;
          grid-column: 1 / -1;
        }

        .stack-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
          margin-top: 14px;
        }

        .stack-item {
          background: rgba(255,255,255,0.03);
          border: 1px solid rgba(255,255,255,0.06);
          border-radius: 10px;
          padding: 12px;
        }

        .stack-step {
          font-size: 10px;
          color: #555;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          margin-bottom: 6px;
        }

        .stack-name {
          font-family: 'Syne', sans-serif;
          font-size: 13px;
          font-weight: 700;
          margin-bottom: 4px;
        }

        .stack-desc { font-size: 11px; color: #666; line-height: 1.5; }

        @media (max-width: 768px) {
          .metrics-row { grid-template-columns: repeat(2, 1fr); }
          .niche-grid { grid-template-columns: repeat(4, 1fr); }
          .queue-grid { grid-template-columns: 1fr; }
          .strategy-grid { grid-template-columns: 1fr; }
          .stack-grid { grid-template-columns: 1fr 1fr; }
        }
      `}</style>

      <div className="app">
        <div className="header">
          <div className="logo">
            <div className="logo-icon">📱</div>
            <div className="logo-text">
              Reel<span>Auto</span> Studio
            </div>
          </div>
          <div className="header-status">
            <div className="status-dot" />
            {totalGenerated} scripts generated today
          </div>
        </div>

        <div className="metrics-row">
          <MetricCard label="Daily Reels" value="3×" sub="9AM · 1PM · 7PM" color="#dc2743" icon="🎬" />
          <MetricCard label="Gift Triggers" value="Active" sub="Branded Content ON" color="#fbbf24" icon="🎁" />
          <MetricCard label="AI Scripts" value={totalGenerated} sub="Generated this session" color="#00d4ff" icon="🤖" />
          <MetricCard label="Monetization" value="2 Types" sub="Gifts + Branded Content" color="#00ff88" icon="💰" />
        </div>

        <div className="tabs">
          <button className={`tab ${activeTab === "generator" ? "active" : ""}`} onClick={() => setActiveTab("generator")}>
            🎬 Content Generator
          </button>
          <button className={`tab ${activeTab === "strategy" ? "active" : ""}`} onClick={() => setActiveTab("strategy")}>
            📈 Strategy & Stack
          </button>
        </div>

        <div className="main-content">
          {activeTab === "generator" && (
            <>
              <div className="section-title">1. Pick your niche</div>
              <div className="niche-grid">
                {NICHES.map(n => (
                  <button
                    key={n.id}
                    className={`niche-btn ${selectedNiche === n.id ? "selected" : ""}`}
                    style={{ "--nc": n.color }}
                    onClick={() => setSelectedNiche(n.id)}
                  >
                    <span className="niche-emoji">{n.emoji}</span>
                    <span className="niche-label" style={{ color: selectedNiche === n.id ? n.color : undefined }}>
                      {n.label}
                    </span>
                  </button>
                ))}
              </div>

              <div className="generate-bar">
                <div className="gen-info">
                  <div className="gen-title">
                    {selectedNiche ? `Generating ${nicheData.emoji} ${nicheData.label} content` : "Select a niche above"}
                  </div>
                  <div className="gen-sub">
                    {selectedNiche
                      ? "Claude AI will write unique hooks, scripts, captions & hashtags for all 3 time slots"
                      : "Claude will create viral scripts, captions, and hashtags optimized for engagement & monetization"}
                  </div>
                </div>
                <button
                  className="generate-btn"
                  disabled={!selectedNiche || generatingAll}
                  onClick={generateAll}
                >
                  {generatingAll ? "⏳ Generating…" : "⚡ Generate Today's Queue"}
                </button>
              </div>

              {apiError && <div className="error-bar">⚠️ {apiError}</div>}

              <div className="section-title">2. Today's content queue</div>
              <div className="queue-grid">
                {TIME_SLOTS.map(slot => (
                  <ContentCard
                    key={slot.id}
                    slotId={slot.id}
                    item={queue[slot.id] || { slotLabel: slot.label, slotTime: slot.time, slotIcon: slot.icon, slotColor: "#666", peak: slot.peak }}
                    loading={loadingSlots[slot.id]}
                    onRegenerate={(id) => generateForSlot(id, selectedNiche)}
                  />
                ))}
              </div>
            </>
          )}

          {activeTab === "strategy" && (
            <div className="strategy-grid">
              <div className="strategy-card">
                <h3>🎁 How to Maximize Gifts</h3>
                {[
                  { text: <><strong>Go Live after posting each Reel.</strong> Reels drive traffic to your Live where gifts happen. Post → wait 30 min → go Live for 15 mins.</>, badge: "badge-gift", badgeText: "💛 Gift Driver" },
                  { text: <><strong>Use direct CTAs for gifts.</strong> Say "Send me a rose if this helped you!" at the end of every Reel. Explicit asks convert 3× better.</>, badge: "badge-gift", badgeText: "💛 Gift Driver" },
                  { text: <><strong>Creator Bonus + Gifts combo.</strong> Make sure Gifts payout is enabled in your monetization settings — Reels with high watch time qualify for bonus payouts too.</>, badge: "badge-follow", badgeText: "✅ Setup" },
                ].map((item, i) => (
                  <div className="strategy-item" key={i}>
                    <div className="strategy-num">{i + 1}</div>
                    <div>
                      <div className="strategy-text">{item.text}</div>
                      <span className={`monetize-badge ${item.badge}`}>{item.badgeText}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="strategy-card">
                <h3>📣 Branded Content Playbook</h3>
                {[
                  { text: <><strong>Niches that attract sponsors fast:</strong> Tech tools, Finance tips, Business/freelancing. Brands DM creators with 1k–10k followers in these niches actively.</>, badge: "badge-brand", badgeText: "💼 Brand Magnet" },
                  { text: <><strong>Enable "Brand Partnership" label</strong> in your pro account. Tag brands you mention even unpaid — it shows up in their analytics and they'll notice you.</>, badge: "badge-brand", badgeText: "💼 Setup Required" },
                  { text: <><strong>Rate card after 100 followers:</strong> Start at $50/Reel for micro-nano deals. As you grow, $300–$1k/Reel is standard for 5k–10k engaged accounts in high-CPM niches.</>, badge: "badge-brand", badgeText: "💰 Revenue" },
                ].map((item, i) => (
                  <div className="strategy-item" key={i}>
                    <div className="strategy-num">{i + 1}</div>
                    <div>
                      <div className="strategy-text">{item.text}</div>
                      <span className={`monetize-badge ${item.badge}`}>{item.badgeText}</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="stack-card">
                <h3 style={{ fontFamily: "Syne, sans-serif", fontSize: 14, fontWeight: 700, marginBottom: 4 }}>
                  🛠️ Full Automation Stack — Deploy This While You Work on Upwork/Fiverr
                </h3>
                <p style={{ fontSize: 12, color: "#555", marginBottom: 0 }}>
                  Use this dashboard for scripts → plug into these tools for a fully hands-off pipeline
                </p>
                <div className="stack-grid">
                  {[
                    { step: "Step 1 — Script", name: "This Dashboard", desc: "Claude AI generates unique hooks, scripts, captions & hashtags daily. Copy with one click.", color: "#dc2743" },
                    { step: "Step 2 — Video", name: "InVideo AI / Pika", desc: "Paste your script. AI auto-creates the Reel with voiceover, B-roll & captions. Free tiers available.", color: "#f09433" },
                    { step: "Step 3 — Schedule", name: "Meta Business Suite", desc: "Free Instagram scheduler. Upload your Reel, set 9AM / 1PM / 7PM and it auto-posts. 100% free.", color: "#fbbf24" },
                    { step: "Step 4 — Hashtags", name: "Already Included", desc: "This dashboard generates 20 optimized hashtags per post. Mix viral + niche + mid-tier for max reach.", color: "#00d4ff" },
                    { step: "Step 5 — Engagement", name: "ManyChat (DM bot)", desc: "Auto-reply to comments with 'keyword'. Boost algorithmic reach without manual effort. Free plan available.", color: "#a78bfa" },
                    { step: "Step 6 — Analytics", name: "Instagram Insights", desc: "Track which time slot performs best weekly. Shift your best-performing niche to morning for max impressions.", color: "#00ff88" },
                  ].map((s, i) => (
                    <div className="stack-item" key={i}>
                      <div className="stack-step">{s.step}</div>
                      <div className="stack-name" style={{ color: s.color }}>{s.name}</div>
                      <div className="stack-desc">{s.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
