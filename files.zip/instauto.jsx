import { useState, useEffect, useRef, useCallback } from "react";

// ─── Config ──────────────────────────────────────────────────────────────────
const NICHES = [
  { id: "tech",       label: "Tech & AI",   emoji: "🤖", color: "#00c2ff", rgb: "0,194,255"   },
  { id: "finance",    label: "Finance",      emoji: "💰", color: "#00e87a", rgb: "0,232,122"   },
  { id: "coding",     label: "Coding",       emoji: "💻", color: "#a78bfa", rgb: "167,139,250" },
  { id: "business",   label: "Business",     emoji: "📈", color: "#f59e0b", rgb: "245,158,11"  },
  { id: "motivation", label: "Motivation",   emoji: "🔥", color: "#ff6b35", rgb: "255,107,53"  },
  { id: "lifestyle",  label: "Lifestyle",    emoji: "✨", color: "#ff6fd8", rgb: "255,111,216" },
];

const CANVAS_W   = 405;
const CANVAS_H   = 720;
const REC_SECS   = 30;
const DEFAULT_SCHEDULE = ["09:00", "13:00", "19:00"];

// ─── Canvas helpers ───────────────────────────────────────────────────────────
const ease = t => 1 - Math.pow(1 - Math.min(1, t), 3);

function rrect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function wrapText(ctx, text, x, y, maxW, lh) {
  const words = text.split(" ");
  let line = "", curY = y;
  for (const w of words) {
    const test = line + w + " ";
    if (ctx.measureText(test).width > maxW && line) {
      ctx.fillText(line.trim(), x, curY);
      line = w + " ";
      curY += lh;
    } else line = test;
  }
  ctx.fillText(line.trim(), x, curY);
  return curY;
}

// ─── Draw one animation frame onto canvas ─────────────────────────────────────
function drawFrame(ctx, t, content, niche) {
  const W = CANVAS_W, H = CANVAS_H;
  const col = niche?.color || "#3b82f6";
  const rgb = niche?.rgb   || "59,130,246";

  // ── background ─────────────────────────────────────────────
  ctx.clearRect(0, 0, W, H);
  const bg = ctx.createRadialGradient(W * 0.5, H * 0.15, 0, W * 0.5, H * 0.5, H * 0.9);
  bg.addColorStop(0, `rgba(${rgb},0.18)`);
  bg.addColorStop(0.55, "#05050f");
  bg.addColorStop(1, "#02020a");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  // diagonal stripe texture
  ctx.save();
  ctx.strokeStyle = `rgba(${rgb},0.07)`;
  ctx.lineWidth = 1;
  const shift = (t * 18) % 36;
  for (let i = -H; i < W + H; i += 36) {
    ctx.beginPath();
    ctx.moveTo(i + shift, 0);
    ctx.lineTo(i + shift + H * 0.6, H);
    ctx.stroke();
  }
  ctx.restore();

  // ── top bar / handle ────────────────────────────────────────
  const topAlpha = ease(Math.max(0, t - 0.3) * 3);
  if (topAlpha > 0) {
    ctx.save();
    ctx.globalAlpha = topAlpha;
    ctx.fillStyle = `rgba(${rgb},0.12)`;
    ctx.fillRect(0, 0, W, 52);
    ctx.font = "bold 12px monospace";
    ctx.fillStyle = `rgba(255,255,255,0.5)`;
    ctx.textAlign = "center";
    ctx.fillText("● ● ●", W / 2, 32);
    ctx.restore();
  }

  // ── glowing hook text (t ≥ 1) ──────────────────────────────
  if (t >= 1 && content?.hook) {
    const p   = ease((t - 1) * 1.4);
    const yOff = (1 - p) * 70;
    ctx.save();
    ctx.globalAlpha = p;
    ctx.translate(0, yOff);

    // accent line
    ctx.shadowColor  = col;
    ctx.shadowBlur   = 18;
    ctx.fillStyle    = col;
    rrect(ctx, W * 0.08, H * 0.23, W * 0.84, 5, 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // hook text
    const hookSize = content.hook.length > 28 ? 21 : 26;
    ctx.font      = `900 ${hookSize}px 'Arial Black', Impact, sans-serif`;
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.shadowColor = "rgba(0,0,0,0.9)";
    ctx.shadowBlur  = 8;
    wrapText(ctx, content.hook.toUpperCase(), W / 2, H * 0.265, W * 0.82, 32);
    ctx.restore();
  }

  // ── three value points (t ≥ 6, 10, 14) ─────────────────────
  if (content?.tips) {
    content.tips.slice(0, 3).forEach((tip, i) => {
      const st = 6 + i * 5;
      if (t < st) return;
      const p  = ease((t - st) * 1.5);
      const xOff = (1 - p) * -50;
      const baseY = H * 0.46 + i * 78;
      ctx.save();
      ctx.globalAlpha = p;
      ctx.translate(xOff, 0);

      ctx.fillStyle = col;
      ctx.fillRect(16, baseY - 2, 3, 58);

      ctx.font      = `bold 36px 'Arial Black', sans-serif`;
      ctx.fillStyle = `rgba(${rgb},0.25)`;
      ctx.textAlign = "left";
      ctx.fillText(i + 1, 26, baseY + 38);

      ctx.font      = "500 13px Arial, sans-serif";
      ctx.fillStyle = "rgba(255,255,255,0.88)";
      wrapText(ctx, tip, 70, baseY + 14, W - 88, 18);
      ctx.restore();
    });
  }

  // ── CTA (t ≥ 22) ─────────────────────────────────────────────
  if (t >= 22) {
    const p      = ease((t - 22) * 1.2);
    const bounce = Math.sin((t - 22) * 3.5) * Math.max(0, 1 - (t - 22) * 0.4) * 4;
    ctx.save();
    ctx.globalAlpha = p;

    ctx.shadowColor = col;
    ctx.shadowBlur  = 22;
    ctx.fillStyle   = col;
    rrect(ctx, W * 0.1, H * 0.83 + bounce, W * 0.8, 48, 24);
    ctx.fill();
    ctx.shadowBlur = 0;

    ctx.font      = "bold 14px Arial, sans-serif";
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.fillText("FOLLOW FOR MORE  ✦", W / 2, H * 0.83 + 29 + bounce);

    ctx.font      = "12px Arial, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.45)";
    ctx.fillText("🎁  Send a gift if this helped!", W / 2, H * 0.83 + 68);
    ctx.restore();
  }

  // ── niche watermark ──────────────────────────────────────────
  ctx.globalAlpha = 0.28;
  ctx.font        = "11px monospace";
  ctx.fillStyle   = col;
  ctx.textAlign   = "right";
  ctx.fillText(`${niche?.emoji || ""} ${niche?.label || ""}`, W - 12, H - 12);
  ctx.globalAlpha = 1;
}

// ─── Hooks ────────────────────────────────────────────────────────────────────
function useLog() {
  const [logs, setLogs] = useState([]);
  const add = useCallback((msg, type = "info") =>
    setLogs(prev => [...prev.slice(-99), { msg, type, time: new Date().toLocaleTimeString() }])
  , []);
  return [logs, add, () => setLogs([])];
}

// ─── Sub-components ───────────────────────────────────────────────────────────
function Field({ label, hint, ...props }) {
  return (
    <div className="field">
      <label>{label}</label>
      <input {...props} />
      {hint && <span className="hint">{hint}</span>}
    </div>
  );
}

function StatusRow({ label, ok, value }) {
  return (
    <div className="sr">
      <span className={`dot ${ok ? "g" : "y"}`} />
      <span className="sr-label">{label}</span>
      <span className="sr-val" style={{ color: ok ? "#22c55e" : "#f59e0b" }}>{value}</span>
    </div>
  );
}

function LogConsole({ logs, style }) {
  const ref = useRef();
  useEffect(() => { if (ref.current) ref.current.scrollTop = ref.current.scrollHeight; }, [logs]);
  return (
    <div className="logbox" style={style} ref={ref}>
      {logs.length === 0
        ? <span className="log-empty">No activity yet.</span>
        : logs.map((l, i) => (
          <div key={i} className={`log-line ${l.type}`}>
            <span className="log-t">[{l.time}]</span>
            <span className="log-m">{l.msg}</span>
          </div>
        ))}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function InstaAuto() {
  const [tab,       setTab]       = useState("setup");
  const [creds,     setCreds]     = useState({ igId: "", igToken: "", cloud: "", preset: "" });
  const [nicheId,   setNicheId]   = useState(null);
  const [content,   setContent]   = useState(null);
  const [videoBlob, setVideoBlob] = useState(null);
  const [genBusy,   setGenBusy]   = useState(false);
  const [recBusy,   setRecBusy]   = useState(false);
  const [recPct,    setRecPct]    = useState(0);
  const [postBusy,  setPostBusy]  = useState(false);
  const [autoOn,    setAutoOn]    = useState(false);
  const [schedule,  setSchedule]  = useState(DEFAULT_SCHEDULE);
  const [logs, addLog, clearLogs] = useLog();

  const canvasRef  = useRef(null);
  const animRef    = useRef(null);
  const recRef     = useRef(null);

  const niche      = NICHES.find(n => n.id === nicheId);
  const credsOk    = creds.igId && creds.igToken && creds.cloud && creds.preset;

  // ── canvas animation loop ──────────────────────────────────────────────────
  useEffect(() => {
    const cvs = canvasRef.current;
    if (!cvs) return;
    const ctx  = cvs.getContext("2d");
    let t0 = Date.now();
    const loop = () => {
      const t = ((Date.now() - t0) / 1000) % (REC_SECS + 2);
      drawFrame(ctx, t, content, niche);
      animRef.current = requestAnimationFrame(loop);
    };
    animRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animRef.current);
  }, [content, niche]);

  // ── automation scheduler ───────────────────────────────────────────────────
  useEffect(() => {
    if (!autoOn) return;
    addLog("⚙️ Automation ON — checking schedule every minute");
    const iv = setInterval(async () => {
      const now = new Date();
      const hhmm = `${String(now.getHours()).padStart(2,"0")}:${String(now.getMinutes()).padStart(2,"0")}`;
      if (schedule.includes(hhmm)) {
        addLog(`⏰ Scheduled trigger at ${hhmm}!`);
        await fullPipeline();
      }
    }, 60_000);
    return () => { clearInterval(iv); addLog("⚙️ Automation OFF"); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoOn, schedule]);

  // ── generate AI content ────────────────────────────────────────────────────
  const generateContent = useCallback(async () => {
    if (!nicheId) return null;
    setGenBusy(true);
    addLog("🤖 Calling Claude AI to generate content…");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 900,
          system: "Expert Instagram Reels strategist. Return ONLY valid JSON, no markdown, no extra text.",
          messages: [{ role: "user", content:
            `Create a viral reel for niche: "${niche?.label}". Return ONLY this JSON:
{
  "hook": "8-word punchy opening hook",
  "tips": ["Key point 1 (≤12 words)", "Key point 2 (≤12 words)", "Key point 3 (≤12 words)"],
  "caption": "Full caption (emojis, value bullets, gift CTA, follow CTA — 250 chars)",
  "hashtags": "#reel #viral ... 20 niche-relevant hashtags"
}` }]
        })
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      const raw    = data.content.map(c => c.text || "").join("").replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(raw);
      const full   = { ...parsed, fullCaption: `${parsed.caption}\n\n${parsed.hashtags}` };
      setContent(full);
      setVideoBlob(null);
      addLog("✅ Content ready!", "success");
      return full;
    } catch (e) {
      addLog(`❌ Content generation failed: ${e.message}`, "error");
      return null;
    } finally {
      setGenBusy(false);
    }
  }, [nicheId, niche, addLog]);

  // ── record canvas to video blob ────────────────────────────────────────────
  const recordVideo = useCallback(() => new Promise((resolve, reject) => {
    const cvs = canvasRef.current;
    if (!cvs) return reject(new Error("Canvas not ready"));

    const stream   = cvs.captureStream(30);
    const mimeType = ["video/mp4;codecs=avc1", "video/webm;codecs=vp9", "video/webm"]
      .find(m => MediaRecorder.isTypeSupported(m)) || "video/webm";

    addLog(`🎥 Recording ${REC_SECS}s reel (${mimeType.split(";")[0]})…`);
    setRecBusy(true);
    setRecPct(0);

    const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 2_500_000 });
    recRef.current = recorder;
    const chunks   = [];

    recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType });
      setVideoBlob(blob);
      setRecBusy(false);
      addLog(`✅ Reel recorded — ${(blob.size / 1024 / 1024).toFixed(1)} MB`, "success");
      resolve(blob);
    };
    recorder.onerror = e => { setRecBusy(false); reject(e.error); };
    recorder.start(400);

    const t0 = Date.now();
    const iv = setInterval(() => {
      const pct = Math.min(100, ((Date.now() - t0) / 1000 / REC_SECS) * 100);
      setRecPct(pct);
      if (pct >= 100) { clearInterval(iv); recorder.stop(); }
    }, 250);
  }), [addLog]);

  // ── upload to Cloudinary (auto-transcodes WebM → MP4) ─────────────────────
  const uploadVideo = useCallback(async blob => {
    addLog("☁️ Uploading video to Cloudinary…");
    const fd = new FormData();
    fd.append("file",            blob, "reel.webm");
    fd.append("upload_preset",   creds.preset);
    fd.append("resource_type",   "video");

    const res  = await fetch(`https://api.cloudinary.com/v1_1/${creds.cloud}/video/upload`, { method: "POST", body: fd });
    if (!res.ok) throw new Error(`Cloudinary ${res.status}: ${await res.text()}`);
    const data = await res.json();

    // Request MP4 transcoded URL via Cloudinary transformation
    const mp4Url = data.secure_url.replace("/upload/", "/upload/f_mp4,vc_h264,ac_aac/");
    addLog(`✅ Hosted → ${mp4Url.slice(0, 60)}…`, "success");
    return mp4Url;
  }, [creds, addLog]);

  // ── post to Instagram Graph API ────────────────────────────────────────────
  const postToIG = useCallback(async (videoUrl, caption) => {
    const base  = `https://graph.facebook.com/v19.0`;
    const token = creds.igToken;
    const igId  = creds.igId;

    // 1. Create media container
    addLog("📤 Creating Instagram media container…");
    const c1 = await fetch(`${base}/${igId}/media`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        media_type: "REELS",
        video_url:  videoUrl,
        caption,
        share_to_feed: true,
        access_token: token,
      })
    });
    const r1 = await c1.json();
    if (r1.error) throw new Error(r1.error.message);
    const creationId = r1.id;
    addLog(`📦 Container: ${creationId}`);

    // 2. Poll until FINISHED
    addLog("⏳ Waiting for Instagram to process video…");
    for (let i = 0; i < 24; i++) {
      await new Promise(r => setTimeout(r, 5000));
      const sr   = await fetch(`${base}/${creationId}?fields=status_code&access_token=${token}`);
      const sd   = await sr.json();
      const code = sd.status_code;
      addLog(`   status: ${code} (${i + 1}/24)`);
      if (code === "FINISHED") break;
      if (code === "ERROR")    throw new Error("Instagram video processing error");
    }

    // 3. Publish
    addLog("🚀 Publishing reel…");
    const c3 = await fetch(`${base}/${igId}/media_publish`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ creation_id: creationId, access_token: token })
    });
    const r3 = await c3.json();
    if (r3.error) throw new Error(r3.error.message);

    addLog(`🎉 REEL LIVE! Post ID: ${r3.id}`, "success");
    return r3;
  }, [creds, addLog]);

  // ── full pipeline ──────────────────────────────────────────────────────────
  const fullPipeline = useCallback(async () => {
    if (postBusy) return;
    setPostBusy(true);
    try {
      let ct  = content   || await generateContent();
      if (!ct)   throw new Error("Content generation failed");

      let vid = videoBlob || await recordVideo();
      if (!vid)  throw new Error("Recording failed");

      const url = await uploadVideo(vid);
      await postToIG(url, ct.fullCaption);
    } catch (e) {
      addLog(`❌ Pipeline error: ${e.message}`, "error");
    } finally {
      setPostBusy(false);
    }
  }, [postBusy, content, videoBlob, generateContent, recordVideo, uploadVideo, postToIG, addLog]);

  // ─────────────────────────────────────────────────────────────────────────────
  //  RENDER
  // ─────────────────────────────────────────────────────────────────────────────
  return (
    <>
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Oxanium:wght@600;700;800&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:wght@400;500;600&display=swap');
      *{box-sizing:border-box;margin:0;padding:0}
      body{background:#03030b}
      .app{font-family:'IBM Plex Sans',sans-serif;background:#03030b;min-height:100vh;color:#d0d0e0;display:flex;flex-direction:column}

      /* ── header ── */
      .hdr{background:#06060f;border-bottom:1px solid rgba(99,102,241,.18);padding:12px 22px;display:flex;align-items:center;gap:14px;position:sticky;top:0;z-index:100}
      .logo{font-family:'Oxanium',sans-serif;font-weight:800;font-size:17px;letter-spacing:1px;background:linear-gradient(110deg,#6366f1,#a855f7,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
      .hdr-sub{font-size:12px;color:#374151}
      .htags{display:flex;gap:6px;margin-left:auto}
      .htag{font-family:'IBM Plex Mono',monospace;font-size:10px;padding:3px 9px;border-radius:4px;border:1px solid;background:rgba(99,102,241,.08);color:#818cf8;border-color:rgba(99,102,241,.25)}
      .htag.g{background:rgba(34,197,94,.07);color:#4ade80;border-color:rgba(34,197,94,.25)}
      .htag.p{background:rgba(168,85,247,.08);color:#c084fc;border-color:rgba(168,85,247,.25)}

      /* ── layout ── */
      .body{display:flex;flex:1;overflow:hidden}
      .sidebar{width:196px;background:#050511;border-right:1px solid rgba(255,255,255,.05);padding:18px 0;display:flex;flex-direction:column;gap:2px;flex-shrink:0}
      .nv{display:flex;align-items:center;gap:9px;padding:10px 18px;font-size:13px;font-weight:500;color:#3f3f5c;cursor:pointer;border:none;background:none;width:100%;text-align:left;border-left:3px solid transparent;transition:all .15s}
      .nv:hover{color:#9ca3af;background:rgba(255,255,255,.02)}
      .nv.on{color:#818cf8;border-left-color:#6366f1;background:rgba(99,102,241,.07)}
      .nv-ic{font-size:15px}
      .nv-badge{margin-left:auto;background:#16a34a;color:#fff;font-size:9px;font-weight:700;padding:1px 6px;border-radius:3px;font-family:'IBM Plex Mono',monospace}

      /* ── main ── */
      .main{flex:1;overflow-y:auto;padding:22px}
      .main::-webkit-scrollbar{width:4px}
      .main::-webkit-scrollbar-thumb{background:#1e1e3a;border-radius:2px}

      /* ── sections ── */
      .sh{font-family:'Oxanium',sans-serif;font-size:10px;font-weight:700;letter-spacing:2px;color:#3f3f5c;text-transform:uppercase;margin-bottom:10px;margin-top:22px}
      .sh:first-child{margin-top:0}
      .card{background:#070712;border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:17px;margin-bottom:13px}
      .ct{font-family:'Oxanium',sans-serif;font-size:13px;font-weight:700;margin-bottom:13px;display:flex;align-items:center;gap:7px;color:#e0e0f0}
      .igrid{display:grid;grid-template-columns:1fr 1fr;gap:11px}
      .field{display:flex;flex-direction:column;gap:5px}
      .field label{font-family:'IBM Plex Mono',monospace;font-size:10px;color:#4b5563;letter-spacing:.5px;text-transform:uppercase}
      input[type=text],input[type=password],input[type=time]{background:#030309;border:1px solid rgba(255,255,255,.08);border-radius:6px;padding:9px 11px;font-family:'IBM Plex Mono',monospace;font-size:12px;color:#d0d0e0;outline:none;width:100%;transition:border-color .15s;color-scheme:dark}
      input:focus{border-color:rgba(99,102,241,.5)}
      input::placeholder{color:#252535}
      .hint{font-size:10px;color:#2d2d45;line-height:1.5}
      .divider{border:none;border-top:1px solid rgba(255,255,255,.04);margin:14px 0}
      .infobox{background:rgba(99,102,241,.06);border:1px solid rgba(99,102,241,.15);border-radius:8px;padding:12px 14px;font-size:11px;color:#7c88b0;line-height:1.8}
      .infobox strong{color:#93c5fd}
      .infobox code{background:rgba(255,255,255,.07);padding:1px 5px;border-radius:3px;font-size:10px}

      /* ── buttons ── */
      .btn{border:none;border-radius:7px;font-family:'IBM Plex Sans',sans-serif;font-size:12px;font-weight:600;padding:9px 16px;cursor:pointer;transition:all .15s;display:inline-flex;align-items:center;justify-content:center;gap:6px}
      .btn:disabled{opacity:.4;cursor:not-allowed}
      .btn-indigo{background:#4f46e5;color:#fff}
      .btn-indigo:hover:not(:disabled){background:#4338ca}
      .btn-purple{background:#7c3aed;color:#fff}
      .btn-purple:hover:not(:disabled){background:#6d28d9}
      .btn-green{background:#15803d;color:#fff}
      .btn-green:hover:not(:disabled){background:#166534}
      .btn-rose{background:rgba(244,63,94,.15);color:#fb7185;border:1px solid rgba(244,63,94,.2)}
      .btn-ghost{background:rgba(255,255,255,.05);color:#777;border:1px solid rgba(255,255,255,.08)}
      .btn-ghost:hover:not(:disabled){color:#ccc;background:rgba(255,255,255,.08)}
      .btn-full{width:100%}

      /* ── studio layout ── */
      .studio{display:grid;grid-template-columns:300px 1fr;gap:15px}
      .cvs-wrap{position:relative;border-radius:12px;overflow:hidden;border:1px solid rgba(255,255,255,.07);background:#000}
      canvas{display:block;width:100%}
      .rec-badge{position:absolute;top:10px;right:10px;background:#ef4444;color:#fff;font-size:10px;font-family:'IBM Plex Mono',monospace;padding:3px 8px;border-radius:4px;font-weight:700;animation:blink 1s infinite}
      @keyframes blink{0%,100%{opacity:1}50%{opacity:.5}}
      .prog-wrap{height:4px;background:rgba(255,255,255,.05);border-radius:2px;margin-top:7px;overflow:hidden}
      .prog-bar{height:100%;background:linear-gradient(90deg,#6366f1,#a855f7);border-radius:2px;transition:width .25s}
      .vid-ok{margin-top:8px;padding:6px 10px;background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.2);border-radius:6px;font-size:11px;color:#4ade80;font-family:'IBM Plex Mono',monospace}
      .btn-row{display:flex;gap:8px;margin-top:9px}

      /* ── niche grid ── */
      .niche-g{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:12px}
      .nb{background:#030309;border:1px solid rgba(255,255,255,.07);border-radius:8px;padding:9px 6px;cursor:pointer;transition:all .15s;display:flex;flex-direction:column;align-items:center;gap:4px;font-family:'IBM Plex Sans',sans-serif}
      .nb:hover{border-color:rgba(255,255,255,.14)}
      .nb.sel{border-color:var(--nc);background:rgba(0,0,0,.4)}
      .nb-em{font-size:18px}
      .nb-lb{font-size:10px;color:#555}
      .nb.sel .nb-lb{color:var(--nc)}

      /* ── content preview ── */
      .cprev{background:#030309;border:1px solid rgba(255,255,255,.06);border-radius:7px;padding:11px;font-size:11.5px;color:#9ca3af;max-height:130px;overflow-y:auto;white-space:pre-wrap;line-height:1.7;font-family:'IBM Plex Mono',monospace;margin-bottom:9px}
      .cprev::-webkit-scrollbar{width:3px}
      .cprev::-webkit-scrollbar-thumb{background:#1e1e3a}

      /* ── status rows ── */
      .sr{display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.04)}
      .sr:last-child{border-bottom:none}
      .dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
      .dot.g{background:#22c55e;box-shadow:0 0 6px #22c55e}
      .dot.y{background:#f59e0b;animation:dp 1.2s infinite}
      @keyframes dp{0%,100%{opacity:1}50%{opacity:.3}}
      .sr-label{font-size:12px;color:#6b7280}
      .sr-val{font-size:11px;margin-left:auto;font-family:'IBM Plex Mono',monospace}

      /* ── log console ── */
      .logbox{background:#02020a;border:1px solid rgba(255,255,255,.05);border-radius:8px;padding:11px;font-family:'IBM Plex Mono',monospace;font-size:11px;height:200px;overflow-y:auto;display:flex;flex-direction:column;gap:3px}
      .logbox::-webkit-scrollbar{width:3px}
      .logbox::-webkit-scrollbar-thumb{background:#1e1e3a}
      .log-empty{color:#1e1e3a}
      .log-line{display:flex;gap:7px}
      .log-t{color:#2d2d45;flex-shrink:0}
      .log-m{color:#6b7280}
      .log-line.success .log-m{color:#4ade80}
      .log-line.error   .log-m{color:#f87171}

      /* ── auto tab ── */
      .sched-row{display:flex;gap:10px;align-items:flex-end;margin-bottom:10px}
      .tf-wrap{display:flex;flex-direction:column;gap:4px}
      .tf-label{font-family:'IBM Plex Mono',monospace;font-size:10px;color:#4b5563;text-transform:uppercase;letter-spacing:.5px}
      .toggle-wrap{display:flex;justify-content:space-between;align-items:center;padding:10px 0}
      .tl-text .tl-main{font-size:14px;color:#c0c0d0;font-weight:500}
      .tl-text .tl-sub{font-size:11px;color:#3f3f5c;margin-top:2px}
      .toggle{width:44px;height:24px;border-radius:12px;cursor:pointer;position:relative;transition:background .2s,border-color .2s;flex-shrink:0;border:1px solid}
      .toggle::after{content:'';position:absolute;top:2px;width:18px;height:18px;border-radius:50%;transition:left .2s,background .2s}
      .step-guide{display:flex;flex-direction:column;gap:10px}
      .sg{display:flex;gap:10px;align-items:flex-start}
      .sg-n{width:22px;height:22px;border-radius:50%;background:rgba(99,102,241,.18);border:1px solid rgba(99,102,241,.4);color:#818cf8;font-size:11px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-family:'IBM Plex Mono',monospace}
      .sg-t{font-size:12px;color:#6b7280;line-height:1.7}
      .sg-t strong{color:#c0c0d0}

      /* ── post tab grid ── */
      .pgrid{display:grid;grid-template-columns:1fr 1fr;gap:13px;margin-bottom:13px}

      /* ── warning box ── */
      .warnbox{background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.2);border-radius:8px;padding:11px 14px;font-size:11px;color:#b45309;line-height:1.7;margin-top:10px}

      @media(max-width:720px){
        .studio{grid-template-columns:1fr}
        .igrid{grid-template-columns:1fr}
        .pgrid{grid-template-columns:1fr}
        .body{flex-direction:column}
        .sidebar{width:100%;flex-direction:row;padding:6px;overflow-x:auto;height:auto}
        .nv{padding:8px 14px;border-left:none;border-bottom:3px solid transparent;white-space:nowrap}
        .nv.on{border-left:none;border-bottom-color:#6366f1}
      }
    `}</style>

    <div className="app">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="hdr">
        <div className="logo">▶ INSTAUTO</div>
        <div className="hdr-sub">AI Reel Creator & Auto-Poster</div>
        <div className="htags">
          <span className="htag">Claude AI</span>
          <span className="htag g">Cloudinary</span>
          <span className="htag p">Instagram API</span>
        </div>
      </div>

      <div className="body">
        {/* ── Sidebar ────────────────────────────────────────── */}
        <div className="sidebar">
          {[
            { id:"setup",  ic:"⚙️",  lb:"Setup"    },
            { id:"studio", ic:"🎬",  lb:"Studio"   },
            { id:"post",   ic:"📤",  lb:"Post Now" },
            { id:"auto",   ic:"🤖",  lb:"Automate", badge: autoOn ? "ON" : null },
            { id:"logs",   ic:"📋",  lb:"Logs"     },
          ].map(({ id, ic, lb, badge }) => (
            <button key={id} className={`nv ${tab===id?"on":""}`} onClick={() => setTab(id)}>
              <span className="nv-ic">{ic}</span>
              {lb}
              {badge && <span className="nv-badge">{badge}</span>}
            </button>
          ))}
        </div>

        {/* ── Main ───────────────────────────────────────────── */}
        <div className="main">

          {/* ════════ SETUP ════════ */}
          {tab==="setup" && <>
            <div className="sh">Instagram API</div>
            <div className="card">
              <div className="ct">📱 Connect Your Instagram Account</div>
              <div className="igrid">
                <Field label="Instagram Business Account ID" type="text"
                  placeholder="17841400000000000"
                  value={creds.igId}
                  onChange={e => setCreds(p=>({...p,igId:e.target.value}))}
                  hint="Instagram app → Settings → Account → Instagram Account ID" />
                <Field label="Long-Lived Access Token" type="password"
                  placeholder="EAAxxxxx..."
                  value={creds.igToken}
                  onChange={e => setCreds(p=>({...p,igToken:e.target.value}))}
                  hint="Needs: instagram_basic + instagram_content_publish permissions" />
              </div>
              <hr className="divider"/>
              <div className="infobox">
                <strong>How to get your Access Token (one-time setup):</strong><br/>
                1. Go to <strong>developers.facebook.com</strong> → My Apps → Create App → Consumer<br/>
                2. Add product: <strong>Instagram Graph API</strong><br/>
                3. Connect your Instagram Creator/Business account to a Facebook Page<br/>
                4. Open <strong>Graph API Explorer</strong> → select your app → generate token with scopes: <code>instagram_basic</code>, <code>instagram_content_publish</code>, <code>pages_read_engagement</code><br/>
                5. Click "Get Long-Lived Token" (valid 60 days — renew monthly)
              </div>
            </div>

            <div className="sh">Video Hosting — Cloudinary (Free)</div>
            <div className="card">
              <div className="ct">☁️ Required: Public URL for Instagram API</div>
              <div className="igrid">
                <Field label="Cloudinary Cloud Name" type="text"
                  placeholder="my-cloud"
                  value={creds.cloud}
                  onChange={e => setCreds(p=>({...p,cloud:e.target.value}))}
                  hint="Found in your Cloudinary dashboard header" />
                <Field label="Unsigned Upload Preset" type="text"
                  placeholder="instagram_reels"
                  value={creds.preset}
                  onChange={e => setCreds(p=>({...p,preset:e.target.value}))}
                  hint="Cloudinary → Settings → Upload → Upload Presets → Add Preset → Unsigned" />
              </div>
              <hr className="divider"/>
              <div className="infobox">
                <strong>Why Cloudinary?</strong><br/>
                Instagram's Reels API cannot accept a raw file upload — it needs a <strong>public HTTPS video URL</strong> it can download from. Cloudinary hosts your recorded WebM, auto-transcodes it to <strong>MP4 (H.264)</strong> via a URL transformation, and serves it over CDN.<br/><br/>
                Free plan: <strong>25 GB storage + 25 GB/month bandwidth</strong> — plenty for daily reels. Sign up free at <strong>cloudinary.com</strong>.
              </div>
            </div>

            <button
              className={`btn ${credsOk?"btn-green":"btn-ghost"}`}
              disabled={!credsOk}
              onClick={() => { addLog("✅ Credentials saved"); setTab("studio"); }}
            >
              {credsOk ? "✅ Save & Go to Studio →" : "⚠️ Fill all 4 fields to continue"}
            </button>
          </>}

          {/* ════════ STUDIO ════════ */}
          {tab==="studio" && <>
            <div className="sh">Content Studio</div>
            <div className="studio">
              {/* Left: Canvas */}
              <div>
                <div className="cvs-wrap">
                  <canvas ref={canvasRef} width={CANVAS_W} height={CANVAS_H}/>
                  {recBusy && <div className="rec-badge">● REC</div>}
                </div>
                {recBusy && (
                  <div className="prog-wrap">
                    <div className="prog-bar" style={{width:`${recPct}%`}}/>
                  </div>
                )}
                <div className="btn-row">
                  <button className="btn btn-indigo" style={{flex:1}}
                    onClick={recordVideo}
                    disabled={recBusy || !content}
                  >
                    {recBusy ? `⏺ ${Math.round(recPct)}%…` : "⏺ Record Reel (30s)"}
                  </button>
                  {videoBlob && (
                    <button className="btn btn-ghost" onClick={() => {
                      const a = Object.assign(document.createElement("a"), {
                        href: URL.createObjectURL(videoBlob), download: "reel.webm"
                      });
                      a.click();
                    }}>⬇</button>
                  )}
                </div>
                {videoBlob && (
                  <div className="vid-ok">✓ Video recorded — {(videoBlob.size/1024/1024).toFixed(1)} MB ready</div>
                )}
                {!content && !genBusy && (
                  <div style={{marginTop:10,fontSize:11,color:"#2d2d45",textAlign:"center"}}>
                    Generate content first to enable recording
                  </div>
                )}
              </div>

              {/* Right: Controls */}
              <div>
                <div className="sh" style={{marginTop:0}}>1 · Pick Niche</div>
                <div className="niche-g">
                  {NICHES.map(n => (
                    <button key={n.id}
                      className={`nb ${nicheId===n.id?"sel":""}`}
                      style={{"--nc": n.color}}
                      onClick={() => { setNicheId(n.id); setContent(null); setVideoBlob(null); }}
                    >
                      <span className="nb-em">{n.emoji}</span>
                      <span className="nb-lb">{n.label}</span>
                    </button>
                  ))}
                </div>

                <button className="btn btn-purple btn-full"
                  onClick={generateContent}
                  disabled={!nicheId || genBusy}
                  style={{marginBottom:14}}
                >
                  {genBusy ? "⏳ Generating…" : "✦ Generate AI Script & Caption"}
                </button>

                {content && <>
                  <div className="sh">2 · Generated Content</div>
                  <div style={{marginBottom:8}}>
                    <div style={{fontSize:10,color:"#4b5563",fontFamily:"IBM Plex Mono,monospace",marginBottom:4}}>HOOK</div>
                    <div style={{fontSize:14,fontWeight:700,color:niche?.color,lineHeight:1.4}}>{content.hook}</div>
                  </div>
                  <div style={{fontSize:10,color:"#4b5563",fontFamily:"IBM Plex Mono,monospace",marginBottom:5}}>CAPTION</div>
                  <div className="cprev">{content.fullCaption}</div>
                  <div className="btn-row" style={{marginBottom:14}}>
                    <button className="btn btn-ghost" style={{fontSize:11}}
                      onClick={() => navigator.clipboard.writeText(content.fullCaption).catch(()=>{})}>
                      📋 Copy Caption
                    </button>
                    <button className="btn btn-ghost" style={{fontSize:11}}
                      onClick={() => { setContent(null); setVideoBlob(null); generateContent(); }}>
                      🔄 Regenerate
                    </button>
                  </div>

                  <div className="sh">3 · Record then Post</div>
                  <button className="btn btn-green btn-full" onClick={() => setTab("post")}>
                    📤 Review & Post →
                  </button>
                </>}
              </div>
            </div>
          </>}

          {/* ════════ POST ════════ */}
          {tab==="post" && <>
            <div className="sh">Post to Instagram</div>
            <div className="pgrid">
              <div className="card">
                <div className="ct">🔍 Preflight Check</div>
                <StatusRow label="Instagram Account ID" ok={!!creds.igId}  value={creds.igId  ? creds.igId.slice(0,10)+"…" : "Missing"} />
                <StatusRow label="Access Token"         ok={!!creds.igToken} value={creds.igToken ? "EAA…"+creds.igToken.slice(-5) : "Missing"} />
                <StatusRow label="Cloudinary Cloud"     ok={!!creds.cloud}  value={creds.cloud  || "Missing"} />
                <StatusRow label="Upload Preset"        ok={!!creds.preset} value={creds.preset || "Missing"} />
                <StatusRow label="AI Content"           ok={!!content}      value={content ? content.hook?.slice(0,20)+"…" : "Not generated"} />
                <StatusRow label="Video File"           ok={!!videoBlob}    value={videoBlob ? `${(videoBlob.size/1024/1024).toFixed(1)} MB` : "Not recorded"} />
              </div>

              <div className="card">
                <div className="ct">📋 Pipeline Steps</div>
                {[
                  ["Generate AI content",                   !!content],
                  ["Record 30s animated reel",              !!videoBlob],
                  ["Upload to Cloudinary → get MP4 URL",    false],
                  ["Create Instagram media container",      false],
                  ["Wait for video processing (≈30–90s)",   false],
                  ["Publish reel to Instagram",             false],
                ].map(([label, done], i) => (
                  <div className="sr" key={i}>
                    <span className={`dot ${done?"g":"y"}`}/>
                    <span className="sr-label">
                      <span style={{color:"#3f3f5c",fontFamily:"IBM Plex Mono,monospace",marginRight:6}}>{i+1}</span>
                      {label}
                    </span>
                    {done && <span style={{marginLeft:"auto",fontSize:10,color:"#4ade80"}}>✓</span>}
                  </div>
                ))}
              </div>
            </div>

            {!credsOk && (
              <div className="warnbox">⚠️ Your credentials are incomplete. Go to Setup and fill in all 4 fields first.</div>
            )}

            <div style={{display:"flex",gap:10,marginTop:4}}>
              {!content   && <button className="btn btn-ghost" onClick={()=>setTab("studio")}>← Generate Content</button>}
              {!videoBlob && content && <button className="btn btn-ghost" onClick={()=>setTab("studio")}>← Record Video</button>}
              <button className="btn btn-green" style={{flex:1}}
                disabled={postBusy || !credsOk || !nicheId}
                onClick={fullPipeline}
              >
                {postBusy ? "⏳ Pipeline running…" : "🚀 Create, Upload & Post Reel Now"}
              </button>
            </div>

            {postBusy && (
              <div className="prog-wrap" style={{marginTop:11}}>
                <div className="prog-bar" style={{width:"100%",animation:"none"}}/>
              </div>
            )}

            <div className="sh">Live Activity Log</div>
            <LogConsole logs={logs} style={{height:220}}/>
          </>}

          {/* ════════ AUTOMATE ════════ */}
          {tab==="auto" && <>
            <div className="sh">Auto-Post Mode</div>
            <div className="card">
              <div className="toggle-wrap">
                <div className="tl-text">
                  <div className="tl-main">🤖 Auto-Post (3× Daily)</div>
                  <div className="tl-sub">
                    {autoOn
                      ? `🟢 Active — will auto-generate & post at ${schedule.join(", ")}`
                      : "Off — enable to post automatically on your schedule"}
                  </div>
                </div>
                <div className="toggle"
                  style={{
                    background: autoOn ? "#15803d" : "#0d0d1f",
                    borderColor: autoOn ? "#4ade80" : "#252535"
                  }}
                  onClick={() => {
                    if (!credsOk && !autoOn) { addLog("⚠️ Complete Setup first", "error"); return; }
                    if (!nicheId && !autoOn) { addLog("⚠️ Select a niche in Studio first", "error"); return; }
                    setAutoOn(p => !p);
                  }}
                >
                  <div style={{
                    position:"absolute",top:2,
                    left: autoOn ? 21 : 2,
                    width:18, height:18,
                    background: autoOn ? "#4ade80" : "#333",
                    borderRadius:"50%",
                    transition:"left .2s, background .2s"
                  }}/>
                </div>
              </div>
              {!credsOk && (
                <div className="warnbox">⚠️ Complete your credentials in Setup before enabling automation.</div>
              )}
            </div>

            <div className="sh">Daily Schedule (3 Posts)</div>
            <div className="card">
              <div className="ct">⏰ Posting Times</div>
              <div className="sched-row">
                {schedule.map((t, i) => (
                  <div className="tf-wrap" key={i}>
                    <div className="tf-label">{["MORNING","AFTERNOON","EVENING"][i]}</div>
                    <input type="time" value={t}
                      onChange={e => setSchedule(s => s.map((v,j) => j===i ? e.target.value : v))}
                    />
                  </div>
                ))}
              </div>
              <div style={{fontSize:11,color:"#3f3f5c",marginTop:6}}>
                💡 Optimal times: 9AM (commute), 1PM (lunch), 7PM (evening scroll)
              </div>
            </div>

            <div className="sh">How It Works</div>
            <div className="card">
              <div className="step-guide">
                {[
                  [<><strong>Every minute</strong>, the app checks if the current time matches your 3 posted times.</>, ],
                  [<>When triggered, it runs the <strong>full pipeline automatically</strong>: generate script → record canvas → upload → post.</>, ],
                  [<><strong>Each post is unique</strong> — Claude generates a fresh hook, script and caption every time.</>, ],
                  [<><strong>Keep this browser tab open</strong> for browser-based scheduling. For true 24/7 unattended posting, deploy this app to Vercel/Netlify and run a cron job (e.g. GitHub Actions) that hits an endpoint 3× daily.</>, ],
                  [<>For <strong>fully serverless automation</strong> without a browser: use Make.com or n8n to orchestrate the Cloudinary + Instagram API calls using a stored pre-recorded video template.</>, ],
                ].map(([text], i) => (
                  <div className="sg" key={i}>
                    <div className="sg-n">{i+1}</div>
                    <div className="sg-t">{text}</div>
                  </div>
                ))}
              </div>
            </div>
          </>}

          {/* ════════ LOGS ════════ */}
          {tab==="logs" && <>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <div className="sh" style={{margin:0}}>Activity Logs</div>
              <button className="btn btn-ghost" style={{fontSize:11}} onClick={clearLogs}>Clear</button>
            </div>
            <LogConsole logs={[...logs].reverse()} style={{height:"calc(100vh - 160px)"}}/>
          </>}

        </div>{/* /main */}
      </div>{/* /body */}
    </div>
    </>
  );
}
