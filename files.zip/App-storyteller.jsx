import { useState, useEffect, useRef, useCallback } from "react";

// ─── Config ────────────────────────────────────────────────────────────────
const NICHES = [
  { id:"tech",       label:"Tech & AI",    emoji:"🤖", color:"#22d3ee", rgb:"34,211,238", bg:["#020d14","#040f1a"], accent:"#0ea5e9" },
  { id:"finance",    label:"Finance Tips", emoji:"💰", color:"#4ade80", rgb:"74,222,128",  bg:["#020e08","#040f0a"], accent:"#16a34a" },
  { id:"coding",     label:"Coding",       emoji:"💻", color:"#a78bfa", rgb:"167,139,250", bg:["#08040e","#0d0620"], accent:"#7c3aed" },
  { id:"business",   label:"Business",     emoji:"📈", color:"#fbbf24", rgb:"251,191,36",  bg:["#0e0c02","#141004"], accent:"#d97706" },
  { id:"motivation", label:"Motivation",   emoji:"🔥", color:"#fb923c", rgb:"251,146,60",  bg:["#0e0602","#140804"], accent:"#ea580c" },
  { id:"lifestyle",  label:"Lifestyle",    emoji:"✨", color:"#f472b6", rgb:"244,114,182", bg:["#0e0208","#14040e"], accent:"#be185d" },
];

const SCHEDULES = [
  { label:"3× Daily (Recommended)", times:["09:00","13:00","19:00"] },
  { label:"2× Daily",               times:["09:00","19:00"]         },
  { label:"Morning Only",           times:["09:00"]                  },
];

const CW = 405, CH = 720, REC_S = 35;

// ─── Math helpers ──────────────────────────────────────────────────────────
const ease    = t => 1 - Math.pow(Math.max(0,Math.min(1,t)),3);
const easeIn  = t => Math.pow(Math.max(0,Math.min(1,t)),2);
const lerp    = (a,b,t) => a+(b-a)*t;
const clamp   = (v,a,b) => Math.min(b,Math.max(a,v));
const rng     = (seed,i) => ((Math.sin(seed*127.1+i*311.7)*43758.5453)%1+1)%1;

// ─── Stickman drawing ──────────────────────────────────────────────────────
function drawStickman(ctx, x, y, scale=1, col="#fff", anim={}) {
  const {
    walkPhase=0, armUp=0, lean=0, jumpY=0,
    celebrate=0, think=0, sad=0, faceExpr="neutral"
  } = anim;

  ctx.save();
  ctx.translate(x, y - jumpY);
  ctx.rotate(lean * 0.08);
  ctx.scale(scale, scale);
  ctx.strokeStyle = col;
  ctx.lineWidth   = 3.5;
  ctx.lineCap     = "round";
  ctx.lineJoin    = "round";

  // shadow
  ctx.save();
  ctx.globalAlpha = 0.18;
  ctx.fillStyle   = "#000";
  ctx.beginPath();
  ctx.ellipse(0, 55, 18*scale, 4, 0, 0, Math.PI*2);
  ctx.fill();
  ctx.restore();

  // body bob
  const bob = Math.sin(walkPhase) * 2.5;

  // ── Head ──
  const headY = -88 + bob;
  ctx.beginPath();
  ctx.arc(0, headY, 16, 0, Math.PI*2);
  ctx.strokeStyle = col; ctx.stroke();
  // head fill
  ctx.fillStyle = "rgba(255,255,255,0.08)";
  ctx.fill();

  // ── Face ──
  ctx.fillStyle = col;
  ctx.strokeStyle = col;
  ctx.lineWidth = 2;
  // eyes
  if(faceExpr === "sad"){
    ctx.beginPath(); ctx.arc(-5, headY-2, 2.5, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(5,  headY-2, 2.5, 0, Math.PI*2); ctx.fill();
    // sad mouth
    ctx.beginPath(); ctx.arc(0, headY+12, 7, 0, Math.PI); ctx.stroke();
  } else if(faceExpr === "happy" || celebrate>0){
    ctx.beginPath(); ctx.arc(-5, headY-2, 2.5, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(5,  headY-2, 2.5, 0, Math.PI*2); ctx.fill();
    // big smile
    ctx.beginPath(); ctx.arc(0, headY+4, 9, 0, Math.PI); ctx.stroke();
  } else if(faceExpr === "surprised"){
    ctx.beginPath(); ctx.arc(-5, headY-2, 3, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(5,  headY-2, 3, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(0, headY+8, 5, 0, Math.PI*2); ctx.stroke();
  } else {
    ctx.beginPath(); ctx.arc(-5, headY-2, 2.5, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.arc(5,  headY-2, 2.5, 0, Math.PI*2); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-6, headY+8); ctx.lineTo(6, headY+8); ctx.stroke();
  }

  // think bubble
  if(think > 0){
    ctx.save(); ctx.globalAlpha = think;
    ctx.strokeStyle = "rgba(255,255,255,0.7)"; ctx.lineWidth=1.5;
    [[-2,4],[4,10],[8,18]].forEach(([dx,dy],i)=>{
      ctx.beginPath(); ctx.arc(20+dx, headY-20-dy, 2+i*1.5, 0, Math.PI*2); ctx.stroke();
    });
    ctx.restore();
  }

  ctx.lineWidth = 3.5;
  ctx.strokeStyle = col;

  // ── Torso ──
  const torsoBot = 30 + bob;
  ctx.beginPath();
  ctx.moveTo(0, headY+16);
  ctx.lineTo(0, torsoBot);
  ctx.stroke();

  // ── Arms ──
  const walkSwing = Math.sin(walkPhase) * 28;
  const leftArmAngle  = (-60 + walkSwing + armUp*(-50)) * Math.PI/180;
  const rightArmAngle = (-60 - walkSwing + armUp*(-50)) * Math.PI/180;
  const armL = 34;
  const shoulderY = headY + 28;

  // left arm
  ctx.beginPath();
  ctx.moveTo(0, shoulderY);
  ctx.lineTo(
    Math.cos(leftArmAngle)*armL,
    shoulderY + Math.sin(leftArmAngle)*armL
  );
  ctx.stroke();

  // right arm
  ctx.beginPath();
  ctx.moveTo(0, shoulderY);
  ctx.lineTo(
    -Math.cos(rightArmAngle)*armL,
    shoulderY + Math.sin(rightArmAngle)*armL
  );
  ctx.stroke();

  // celebrate arms wave
  if(celebrate > 0){
    ctx.save(); ctx.globalAlpha=celebrate;
    const wave = Math.sin(walkPhase*3)*20;
    ctx.strokeStyle=col; ctx.lineWidth=3.5;
    ctx.beginPath();
    ctx.moveTo(0, shoulderY);
    ctx.lineTo(-38, shoulderY-30-wave); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, shoulderY);
    ctx.lineTo(38, shoulderY-30+wave); ctx.stroke();
    ctx.restore();
  }

  // ── Legs ──
  const legSwing = Math.sin(walkPhase) * 30;
  const hipY = torsoBot;
  const legL = 46;

  // left leg
  const lkx = Math.sin((legSwing)*Math.PI/180)*legL;
  const lky = Math.cos((legSwing)*Math.PI/180)*legL;
  ctx.beginPath();
  ctx.moveTo(0, hipY);
  ctx.lineTo(-lkx, hipY+lky*0.7);
  ctx.lineTo(-lkx-Math.sin(legSwing*0.5*Math.PI/180)*8, hipY+legL);
  ctx.stroke();

  // right leg
  ctx.beginPath();
  ctx.moveTo(0, hipY);
  ctx.lineTo(lkx, hipY+lky*0.7);
  ctx.lineTo(lkx+Math.sin(legSwing*0.5*Math.PI/180)*8, hipY+legL);
  ctx.stroke();

  ctx.restore();
}

// ─── Speech bubble ─────────────────────────────────────────────────────────
function drawSpeechBubble(ctx, x, y, text, col, alpha=1, dir="right") {
  if(!text || alpha<=0) return;
  ctx.save();
  ctx.globalAlpha = alpha;

  const pad = 14, maxW = 200, lh = 20;
  ctx.font = "bold 13px 'Arial',sans-serif";

  // word wrap
  const words = text.split(" ");
  const lines = []; let cur = "";
  for(const w of words){
    const test = cur+(cur?" ":"")+w;
    if(ctx.measureText(test).width > maxW-pad*2 && cur){ lines.push(cur); cur=w; }
    else cur=test;
  }
  if(cur) lines.push(cur);

  const bw = Math.min(maxW, Math.max(...lines.map(l=>ctx.measureText(l).width))+pad*2);
  const bh = lines.length*lh + pad*1.5;
  const bx = dir==="right" ? x+10 : x-10-bw;
  const by = y - bh - 20;

  // bubble shadow
  ctx.shadowColor="rgba(0,0,0,0.5)"; ctx.shadowBlur=12;
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.strokeStyle = col; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.roundRect(bx,by,bw,bh,10); ctx.fill(); ctx.stroke();
  ctx.shadowBlur=0;

  // tail
  ctx.beginPath();
  if(dir==="right"){
    ctx.moveTo(bx+16, by+bh);
    ctx.lineTo(x+8, y-4);
    ctx.lineTo(bx+30, by+bh);
  } else {
    ctx.moveTo(bx+bw-16, by+bh);
    ctx.lineTo(x-8, y-4);
    ctx.lineTo(bx+bw-30, by+bh);
  }
  ctx.fillStyle="rgba(255,255,255,0.95)"; ctx.fill();
  ctx.strokeStyle=col; ctx.lineWidth=1.5; ctx.stroke();

  // text
  ctx.fillStyle = "#111";
  ctx.textAlign = "left";
  lines.forEach((ln,i)=>{
    ctx.fillText(ln, bx+pad, by+pad+lh*i+4);
  });

  ctx.restore();
}

// ─── Scene backgrounds ─────────────────────────────────────────────────────
function drawScene(ctx, scene, t, col, rgb, bg) {
  const W=CW, H=CH;

  // sky
  const sky = ctx.createLinearGradient(0,0,0,H);
  sky.addColorStop(0, bg[0]);
  sky.addColorStop(1, bg[1]);
  ctx.fillStyle=sky; ctx.fillRect(0,0,W,H);

  // stars (night feel)
  for(let i=0;i<40;i++){
    const sx=rng(scene,i*3)*W, sy=rng(scene,i*3+1)*H*.5;
    const sa=0.3+rng(scene,i*3+2)*0.5;
    const pulse=0.6+Math.sin(t*2+i)*0.4;
    ctx.globalAlpha=sa*pulse;
    ctx.fillStyle=col;
    ctx.beginPath(); ctx.arc(sx,sy,rng(scene,i+99)<0.2?2:1,0,Math.PI*2); ctx.fill();
  }
  ctx.globalAlpha=1;

  // ground
  const grd=ctx.createLinearGradient(0,H*.78,0,H);
  grd.addColorStop(0,`rgba(${rgb},.12)`);
  grd.addColorStop(1,`rgba(${rgb},.04)`);
  ctx.fillStyle=grd; ctx.fillRect(0,H*.78,W,H*.22);

  // ground line
  ctx.strokeStyle=`rgba(${rgb},.4)`; ctx.lineWidth=1.5;
  ctx.beginPath(); ctx.moveTo(0,H*.78); ctx.lineTo(W,H*.78); ctx.stroke();

  if(scene===0){
    // City silhouette
    ctx.fillStyle=`rgba(${rgb},.06)`;
    [[20,120,50,200],[80,80,60,200],[160,100,45,200],[230,60,55,200],[300,90,50,200],[360,70,40,200]].forEach(([x,h,w])=>{
      ctx.fillRect(x,H*.78-h,w,h);
    });
    // windows
    ctx.fillStyle=`rgba(${rgb},.25)`;
    for(let i=0;i<20;i++){
      if(rng(0,i*7)>0.4){
        const bx=rng(0,i*7+1)*W;
        const by=H*.78-rng(0,i*7+2)*180;
        ctx.fillRect(bx,by,5,7);
      }
    }
  } else if(scene===1){
    // Office/desk
    ctx.strokeStyle=`rgba(${rgb},.25)`; ctx.lineWidth=2;
    const deskY=H*.78-80;
    ctx.beginPath(); ctx.roundRect(W*.15,deskY,W*.7,16,4);
    ctx.fillStyle=`rgba(${rgb},.1)`; ctx.fill(); ctx.stroke();
    // monitor
    ctx.strokeStyle=`rgba(${rgb},.3)`; ctx.lineWidth=1.5;
    ctx.beginPath(); ctx.roundRect(W*.3,deskY-90,140,80,6);
    ctx.fillStyle=`rgba(${rgb},.08)`; ctx.fill(); ctx.stroke();
    // screen glow
    ctx.fillStyle=`rgba(${rgb},.15)`;
    ctx.fillRect(W*.3+6,deskY-84,128,68);
    // code lines on screen
    ctx.fillStyle=`rgba(${rgb},.6)`;
    [20,36,52,68].forEach((ly,i)=>{
      if(rng(1,i*3)>0.3) ctx.fillRect(W*.3+12, deskY-84+ly, rng(1,i*3+1)*80+20, 3);
    });
  } else if(scene===2){
    // Mountain / success landscape
    ctx.fillStyle=`rgba(${rgb},.07)`;
    ctx.beginPath();
    ctx.moveTo(0,H*.78);
    ctx.lineTo(W*.2,H*.45);
    ctx.lineTo(W*.4,H*.62);
    ctx.lineTo(W*.6,H*.38);
    ctx.lineTo(W*.8,H*.55);
    ctx.lineTo(W,H*.78);
    ctx.closePath(); ctx.fill();
    // flag at top
    ctx.strokeStyle=col; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(W*.6,H*.38); ctx.lineTo(W*.6,H*.28); ctx.stroke();
    ctx.fillStyle=col; ctx.globalAlpha=0.8;
    ctx.beginPath();
    ctx.moveTo(W*.6,H*.28); ctx.lineTo(W*.6+24,H*.32); ctx.lineTo(W*.6,H*.36);
    ctx.fill(); ctx.globalAlpha=1;
  } else if(scene===3){
    // Celebration / confetti
    for(let i=0;i<30;i++){
      const cx=rng(3,i*4)*W;
      const cy=(rng(3,i*4+1)*H*.7 + t*40*rng(3,i*4+2))%(H*.75);
      const cr=rng(3,i*4+3);
      ctx.globalAlpha=0.6+Math.sin(t+i)*0.4;
      ctx.fillStyle=`hsl(${(i*37+t*60)%360},80%,65%)`;
      if(cr>0.5){
        ctx.fillRect(cx,cy,6,6);
      } else {
        ctx.beginPath(); ctx.arc(cx,cy,4,0,Math.PI*2); ctx.fill();
      }
    }
    ctx.globalAlpha=1;
  }
}

// ─── Main reel renderer ────────────────────────────────────────────────────
const SCENE_TIMES = [0, 8, 17, 26, 33]; // scene start times

function getScene(t){ return SCENE_TIMES.findLastIndex(s=>t>=s); }

function drawReelFrame(ctx, t, content, niche) {
  if(!niche) return;
  const W=CW, H=CH;
  const col=niche.color, rgb=niche.rgb, bg=niche.bg;
  const scene=getScene(t);
  const sceneT=t-SCENE_TIMES[scene];

  ctx.clearRect(0,0,W,H);

  // ── Scene background ──────────────────────────────────────
  drawScene(ctx, Math.min(scene,3), t, col, rgb, bg);

  // ── Scene transition flash ────────────────────────────────
  const transAlpha = scene>0 ? Math.max(0, 0.5-sceneT*2) : 0;
  if(transAlpha>0){
    ctx.fillStyle=`rgba(255,255,255,${transAlpha})`;
    ctx.fillRect(0,0,W,H);
  }

  // ── Ground shadow / atmosphere ────────────────────────────
  const atm=ctx.createLinearGradient(0,H*.6,0,H);
  atm.addColorStop(0,"rgba(0,0,0,0)");
  atm.addColorStop(1,"rgba(0,0,0,.55)");
  ctx.fillStyle=atm; ctx.fillRect(0,0,W,H);

  // ── Stickman ─────────────────────────────────────────────
  let manX, manY, manAnim, manAlpha=1;
  const groundY = H*.78 - 60;

  if(scene===0){
    // Walk in from left
    const walkIn = easeIn(clamp(sceneT/1.5,0,1));
    manX = lerp(-50, W*.38, walkIn);
    manY = groundY;
    manAnim = { walkPhase:t*4, faceExpr:"neutral", lean:walkIn<1?1:0 };
  } else if(scene===1){
    // At desk / working
    manX = W*.28;
    manY = groundY - 18;
    const thinkPulse = clamp(sceneT-.5,0,1);
    manAnim = {
      walkPhase:0, armUp:0.4,
      faceExpr: sceneT<2?"surprised":"sad",
      think: thinkPulse*0.8+Math.sin(t*2)*0.2
    };
  } else if(scene===2){
    // Walking to mountain / determined
    const progress = clamp(sceneT/7,0,1);
    manX = lerp(W*.1, W*.5, ease(progress));
    manY = groundY - progress*40;
    manAnim = { walkPhase:t*5, faceExpr:"neutral", lean:1, armUp:0.3 };
  } else if(scene===3){
    // Celebration at top
    const jumpT = (sceneT%1.4)/1.4;
    const jumpH = Math.sin(jumpT*Math.PI)*40;
    manX = W*.5 + Math.sin(t*1.5)*15;
    manY = groundY - 40;
    manAnim = {
      walkPhase:t*6, faceExpr:"happy",
      celebrate:1, jumpY:jumpH
    };
  } else {
    manX = W*.5; manY = groundY;
    manAnim = { walkPhase:t*3, faceExpr:"happy", celebrate:0.5 };
  }

  if(manAlpha>0){
    ctx.globalAlpha=manAlpha;
    drawStickman(ctx, manX, manY, 1.15, col, manAnim);
    ctx.globalAlpha=1;
  }

  // ── Speech bubbles ────────────────────────────────────────
  if(content?.scenes){
    const sc = content.scenes[Math.min(scene, content.scenes.length-1)];
    if(sc?.bubble){
      const bubbleAlpha = clamp(sceneT*2.5,0,1) * clamp((SCENE_TIMES[scene+1]||REC_S)-t,0,1);
      const dir = scene===1 ? "right" : "right";
      drawSpeechBubble(ctx, manX+(dir==="right"?20:-20), manY-80, sc.bubble, col, bubbleAlpha, dir);
    }
  }

  // ── Caption bar (bottom) ──────────────────────────────────
  if(content?.scenes){
    const sc = content.scenes[Math.min(scene, content.scenes.length-1)];
    if(sc?.caption){
      const capAlpha = clamp(sceneT*3,0,1);
      ctx.save(); ctx.globalAlpha=capAlpha;
      const capBg = ctx.createLinearGradient(0,H*.82,0,H*.97);
      capBg.addColorStop(0,"rgba(0,0,0,0)");
      capBg.addColorStop(1,"rgba(0,0,0,.88)");
      ctx.fillStyle=capBg; ctx.fillRect(0,H*.82,W,H*.15);
      ctx.font="bold 15px 'Arial Black',sans-serif";
      ctx.fillStyle="#fff"; ctx.textAlign="center";
      ctx.shadowColor=col; ctx.shadowBlur=12;
      ctx.fillText(sc.caption.toUpperCase(), W/2, H*.92);
      ctx.shadowBlur=0;
      // sub line
      if(sc.sub){
        ctx.font="12px 'Arial',sans-serif";
        ctx.fillStyle=col; ctx.shadowBlur=0;
        ctx.fillText(sc.sub, W/2, H*.955);
      }
      ctx.restore();
    }
  }

  // ── Niche badge (always top right) ───────────────────────
  const ba=clamp(t*.8,0,1);
  ctx.save(); ctx.globalAlpha=ba;
  ctx.font="600 11px Arial,sans-serif";
  const btext=`${niche.emoji} ${niche.label.toUpperCase()}`;
  const bw=ctx.measureText(btext).width+20;
  ctx.fillStyle=`rgba(0,0,0,.5)`; ctx.strokeStyle=`rgba(${rgb},.4)`; ctx.lineWidth=1;
  ctx.beginPath(); ctx.roundRect(W-bw-12,12,bw,26,13); ctx.fill(); ctx.stroke();
  ctx.fillStyle=col; ctx.textAlign="right";
  ctx.fillText(btext,W-22,30); ctx.restore();

  // ── Big hook text (scene 0 only) ──────────────────────────
  if(scene===0 && content?.hook){
    const hp=clamp((sceneT-1.5)*2,0,1);
    if(hp>0){
      ctx.save(); ctx.globalAlpha=hp;
      ctx.font=`900 ${content.hook.length>28?20:24}px 'Arial Black',sans-serif`;
      ctx.textAlign="center"; ctx.textBaseline="top";
      const words=content.hook.toUpperCase().split(" ");
      let line="", lines=[], y=H*.1;
      for(const w of words){
        const test=line+(line?" ":"")+w;
        if(ctx.measureText(test).width>W*.85&&line){lines.push(line);line=w;}
        else line=test;
      }
      lines.push(line);
      // bg pill
      ctx.fillStyle="rgba(0,0,0,.6)";
      ctx.beginPath(); ctx.roundRect(W*.06,y-8,W*.88,lines.length*30+20,12); ctx.fill();
      ctx.shadowColor=col; ctx.shadowBlur=18;
      ctx.fillStyle="#fff";
      lines.forEach((ln,i)=>{ ctx.fillText(ln,W/2,y+i*30+4); });
      ctx.restore();
    }
  }

  // ── Floating emoji particles (celebration) ────────────────
  if(scene===3){
    const emojis=["🎉","💰","🔥","⭐","✨","🚀"];
    for(let i=0;i<6;i++){
      const ex=rng(99,i*5)*W;
      const ey=((rng(99,i*5+1)*H - sceneT*60*rng(99,i*5+2)*2)%H+H)%H;
      ctx.font=`${18+rng(99,i*5+3)*10}px serif`;
      ctx.globalAlpha=0.5+Math.sin(t*2+i)*0.4;
      ctx.textAlign="center";
      ctx.fillText(emojis[i%emojis.length],ex,ey);
    }
    ctx.globalAlpha=1;
  }

  // ── Progress bar ──────────────────────────────────────────
  ctx.fillStyle=`rgba(${rgb},.15)`; ctx.fillRect(0,H-3,W,3);
  const pg=ctx.createLinearGradient(0,0,(t/REC_S)*W,0);
  pg.addColorStop(0,col); pg.addColorStop(1,"#fff");
  ctx.fillStyle=pg; ctx.fillRect(0,H-3,(t/REC_S)*W,3);

  // ── Scene indicator dots ──────────────────────────────────
  const dotCount=4;
  for(let i=0;i<dotCount;i++){
    ctx.globalAlpha = i===Math.min(scene,dotCount-1)?1:0.25;
    ctx.fillStyle=col;
    ctx.beginPath(); ctx.arc(W/2+(i-1.5)*14,H-14,3,0,Math.PI*2); ctx.fill();
  }
  ctx.globalAlpha=1;
}

// ─── Storage ───────────────────────────────────────────────────────────────
const store={
  get:k=>{try{return JSON.parse(localStorage.getItem("ia3_"+k)||"null")}catch{return null}},
  set:(k,v)=>{try{localStorage.setItem("ia3_"+k,JSON.stringify(v))}catch{}},
};

const pad=n=>String(n).padStart(2,"0");
const hhmm=d=>`${pad(d.getHours())}:${pad(d.getMinutes())}`;
const fmt=d=>new Date(d).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});

// ─── Voice (Web Speech API) ────────────────────────────────────────────────
function speak(text, rate=0.95, pitch=1.05){
  if(!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utt = new SpeechSynthesisUtterance(text);
  utt.rate=rate; utt.pitch=pitch; utt.volume=1;
  // pick a good voice if available
  const voices=window.speechSynthesis.getVoices();
  const preferred=voices.find(v=>v.name.includes("Google")&&v.lang.startsWith("en"))
    || voices.find(v=>v.lang.startsWith("en-US"))
    || voices[0];
  if(preferred) utt.voice=preferred;
  window.speechSynthesis.speak(utt);
}

const inp={background:"#030309",border:"1px solid rgba(255,255,255,.08)",borderRadius:6,padding:"10px 12px",fontFamily:"monospace",fontSize:12,color:"#d0d0e0",outline:"none",width:"100%"};
const btn={border:"none",borderRadius:8,fontFamily:"monospace",fontSize:12,padding:"10px 18px",cursor:"pointer",transition:"all .15s",display:"inline-flex",alignItems:"center",justifyContent:"center",gap:6};

// ─── App ───────────────────────────────────────────────────────────────────
export default function InstaStoryteller() {
  const [creds,     setCreds]    = useState(()=>store.get("creds")||{igId:"",igToken:"",cloud:"",preset:""});
  const [nicheId,   setNicheId]  = useState(()=>store.get("niche")||null);
  const [schedIdx,  setSchedIdx] = useState(()=>store.get("si")||0);
  const [setupDone, setSetupDone]= useState(()=>store.get("done")||false);
  const [setupStep, setSetupStep]= useState(0);
  const [running,   setRunning]  = useState(false);
  const [content,   setContent]  = useState(null);
  const [status,    setStatus]   = useState("idle");
  const [log,       setLog]      = useState([]);
  const [posts,     setPosts]    = useState(()=>store.get("posts")||[]);
  const [nextPost,  setNextPost] = useState(null);
  const [recPct,    setRecPct]   = useState(0);
  const [showCanvas,setShowCanvas]=useState(true);
  const [voiceOn,   setVoiceOn]  = useState(true);

  const canvasRef  = useRef(null);
  const animRef    = useRef(null);
  const runRef     = useRef(false);
  const contentRef = useRef(null);

  const niche    = NICHES.find(n=>n.id===nicheId);
  const schedule = SCHEDULES[schedIdx]?.times||SCHEDULES[0].times;

  const addLog=useCallback((msg,type="info")=>{
    setLog(p=>[...p.slice(-199),{msg,type,ts:Date.now()}]);
  },[]);

  useEffect(()=>{store.set("creds",creds)},[creds]);
  useEffect(()=>{store.set("niche",nicheId)},[nicheId]);
  useEffect(()=>{store.set("si",schedIdx)},[schedIdx]);
  useEffect(()=>{store.set("done",setupDone)},[setupDone]);
  useEffect(()=>{store.set("posts",posts)},[posts]);

  // canvas loop
  useEffect(()=>{
    const cvs=canvasRef.current; if(!cvs)return;
    const ctx=cvs.getContext("2d");
    let t0=Date.now();
    const loop=()=>{
      const t=((Date.now()-t0)/1000)%(REC_S+2);
      drawReelFrame(ctx,t,contentRef.current,niche);
      animRef.current=requestAnimationFrame(loop);
    };
    animRef.current=requestAnimationFrame(loop);
    return()=>cancelAnimationFrame(animRef.current);
  },[niche]);

  // next post countdown
  useEffect(()=>{
    const iv=setInterval(()=>{
      const now=new Date();
      const nowM=now.getHours()*60+now.getMinutes();
      const slots=schedule.map(t=>{const[h,m]=t.split(":").map(Number);return h*60+m;});
      const future=slots.filter(m=>m>nowM);
      const nextM=future.length?future[0]:slots[0]+1440;
      const diff=nextM-nowM;
      setNextPost(`${Math.floor(diff/60)}h ${diff%60}m`);
    },15000);
    return()=>clearInterval(iv);
  },[schedule]);

  // scheduler
  useEffect(()=>{
    if(!running)return;
    addLog("🤖 Automation started");
    const iv=setInterval(async()=>{
      if(!runRef.current)return;
      if(schedule.includes(hhmm(new Date()))){
        addLog(`⏰ Scheduled post triggered`);
        await pipeline();
      }
    },60_000);
    return()=>{clearInterval(iv);addLog("⏸ Paused")};
  // eslint-disable-next-line
  },[running,schedule]);

  useEffect(()=>{runRef.current=running},[running]);

  // ── Generate storytelling content ─────────────────────────────────────────
  const generateContent=useCallback(async()=>{
    if(!nicheId)return null;
    const nicheObj=NICHES.find(n=>n.id===nicheId);
    setStatus("generating");
    addLog("🤖 Claude writing your story…");
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514",max_tokens:1000,
          system:"Expert viral Instagram Reels storyteller. Return ONLY valid JSON, no markdown, no extra text.",
          messages:[{role:"user",content:`Create a 4-scene storytelling reel for "${nicheObj.label}" niche.
Format: animated stickman character goes through a relatable problem → struggle → solution → celebration.
Return ONLY this JSON:
{
  "hook": "8-word viral opening hook question or statement",
  "voiceover": "Full 30-second spoken script. Natural, conversational, energetic. About 80 words. Written as if spoken aloud by the character.",
  "scenes": [
    {"id":0,"bubble":"Short speech bubble text (max 6 words) - character introduces problem","caption":"Scene headline (4 words max)","sub":"Relatable tagline"},
    {"id":1,"bubble":"Character frustrated speech (max 6 words)","caption":"The struggle is real","sub":"Sound familiar?"},
    {"id":2,"bubble":"Character realizes solution (max 6 words)","caption":"Then I discovered this","sub":"Game changer"},
    {"id":3,"bubble":"Character celebrating (max 6 words)","caption":"Now everything changed","sub":"Follow for more 🔥"}
  ],
  "caption": "Full Instagram caption 200 chars with emojis and hashtags",
  "hashtags": "20 niche hashtags space-separated"
}`}]
        })
      });
      const d=await res.json();
      if(d.error)throw new Error(d.error.message);
      const raw=d.content.map(c=>c.text||"").join("").replace(/```json|```/g,"").trim();
      const ct=JSON.parse(raw);
      ct.fullCaption=`${ct.caption}\n\n${ct.hashtags}`;
      setContent(ct); contentRef.current=ct;
      addLog(`✓ Story ready: "${ct.hook}"`,"success");
      // speak voiceover preview
      if(voiceOn && ct.voiceover){
        setTimeout(()=>speak(ct.voiceover),800);
      }
      return ct;
    }catch(e){addLog(`❌ Story error: ${e.message}`,"error");setStatus("error");return null;}
  },[nicheId,voiceOn,addLog]);

  // ── Record canvas ─────────────────────────────────────────────────────────
  const recordVideo=useCallback(()=>new Promise((resolve,reject)=>{
    const cvs=canvasRef.current;
    if(!cvs)return reject(new Error("Canvas not ready"));
    // stop preview voice during recording
    window.speechSynthesis?.cancel();
    const stream=cvs.captureStream(30);
    const mime=["video/mp4;codecs=avc1","video/webm;codecs=vp9","video/webm"].find(m=>MediaRecorder.isTypeSupported(m))||"video/webm";
    addLog(`🎥 Recording ${REC_S}s…`);
    setStatus("recording");
    const rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:3_000_000});
    const chunks=[];
    rec.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data);};
    rec.onstop=()=>resolve(new Blob(chunks,{type:mime}));
    rec.onerror=e=>reject(e.error);
    rec.start(300);
    const t0=Date.now();
    const iv=setInterval(()=>{
      const pct=Math.min(100,((Date.now()-t0)/1000/REC_S)*100);
      setRecPct(pct);
      if(pct>=100){clearInterval(iv);rec.stop();}
    },200);
  }),[addLog]);

  // ── Upload to Cloudinary ──────────────────────────────────────────────────
  const uploadVideo=useCallback(async blob=>{
    addLog("☁️ Uploading to Cloudinary…");
    setStatus("uploading");
    const fd=new FormData();
    fd.append("file",blob,"story.webm");
    fd.append("upload_preset",creds.preset);
    fd.append("resource_type","video");
    const r=await fetch(`https://api.cloudinary.com/v1_1/${creds.cloud}/video/upload`,{method:"POST",body:fd});
    if(!r.ok)throw new Error(`Cloudinary ${r.status}`);
    const d=await r.json();
    const url=d.secure_url.replace("/upload/","/upload/f_mp4,vc_h264,ac_aac/");
    addLog(`✓ Video hosted`,"success");
    return url;
  },[creds,addLog]);

  // ── Post to Instagram ─────────────────────────────────────────────────────
  const postToIG=useCallback(async(videoUrl,caption)=>{
    addLog("📤 Posting to Instagram…");
    setStatus("posting");
    const base=`https://graph.facebook.com/v19.0`;
    const {igId,igToken}=creds;
    const c1=await fetch(`${base}/${igId}/media`,{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({media_type:"REELS",video_url:videoUrl,caption,share_to_feed:true,access_token:igToken})});
    const r1=await c1.json();
    if(r1.error)throw new Error(r1.error.message);
    addLog(`📦 Container: ${r1.id} — processing…`);
    for(let i=0;i<24;i++){
      await new Promise(r=>setTimeout(r,5000));
      const sr=await fetch(`${base}/${r1.id}?fields=status_code&access_token=${igToken}`);
      const sd=await sr.json();
      addLog(`   ${sd.status_code}`);
      if(sd.status_code==="FINISHED")break;
      if(sd.status_code==="ERROR")throw new Error("IG processing error");
    }
    const c3=await fetch(`${base}/${igId}/media_publish`,{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({creation_id:r1.id,access_token:igToken})});
    const r3=await c3.json();
    if(r3.error)throw new Error(r3.error.message);
    addLog(`🎉 POSTED! ${r3.id}`,"success");
    return r3;
  },[creds,addLog]);

  // ── Full pipeline ─────────────────────────────────────────────────────────
  const pipeline=useCallback(async()=>{
    const {igId,igToken,cloud,preset}=creds;
    if(!igId||!igToken||!cloud||!preset||!nicheId){addLog("❌ Missing setup","error");return;}
    try{
      const ct=await generateContent(); if(!ct)return;
      await new Promise(r=>setTimeout(r,1000));
      const blob=await recordVideo(); if(!blob)return;
      const url=await uploadVideo(blob);
      const r=await postToIG(url,ct.fullCaption);
      const nicheObj=NICHES.find(n=>n.id===nicheId);
      setPosts(p=>[{id:r.id,hook:ct.hook,niche:nicheObj.label,ts:Date.now()},...p.slice(0,29)]);
      setStatus("done");
      setTimeout(()=>setStatus("idle"),4000);
    }catch(e){addLog(`❌ ${e.message}`,"error");setStatus("error");}
  },[creds,nicheId,generateContent,recordVideo,uploadVideo,postToIG,addLog]);

  // ── SETUP WIZARD ──────────────────────────────────────────────────────────
  if(!setupDone){
    const steps=[
      {
        title:"Connect Instagram",icon:"📱",
        valid:!!creds.igId&&!!creds.igToken,
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <p style={{fontSize:13,color:"#666",lineHeight:1.7,margin:0}}>Paste your credentials below.</p>
            <label style={{display:"flex",flexDirection:"column",gap:5}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>INSTAGRAM ACCOUNT ID</span>
              <input type="text" placeholder="17841402485577171" value={creds.igId} onChange={e=>setCreds(p=>({...p,igId:e.target.value}))} style={inp}/>
            </label>
            <label style={{display:"flex",flexDirection:"column",gap:5}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>ACCESS TOKEN (60-DAY)</span>
              <input type="password" placeholder="EAAyKCIs…" value={creds.igToken} onChange={e=>setCreds(p=>({...p,igToken:e.target.value}))} style={inp}/>
            </label>
            <div style={{background:"rgba(34,211,238,.06)",border:"1px solid rgba(34,211,238,.15)",borderRadius:8,padding:12,fontSize:11,color:"#888",lineHeight:1.8}}>
              <strong style={{color:"#22d3ee"}}>Your credentials:</strong><br/>
              Account ID: 17841402485577171<br/>
              Token: your EAAyKCIs… 60-day token
            </div>
          </div>
        ),
      },
      {
        title:"Connect Cloudinary",icon:"☁️",
        valid:!!creds.cloud&&!!creds.preset,
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <label style={{display:"flex",flexDirection:"column",gap:5}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>CLOUDINARY CLOUD NAME</span>
              <input type="text" placeholder="my-cloud-name" value={creds.cloud} onChange={e=>setCreds(p=>({...p,cloud:e.target.value}))} style={inp}/>
            </label>
            <label style={{display:"flex",flexDirection:"column",gap:5}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>UNSIGNED UPLOAD PRESET</span>
              <input type="text" placeholder="instagram_reels" value={creds.preset} onChange={e=>setCreds(p=>({...p,preset:e.target.value}))} style={inp}/>
            </label>
          </div>
        ),
      },
      {
        title:"Pick Niche & Schedule",icon:"🎯",
        valid:!!nicheId,
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:18}}>
            <div>
              <div style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1,marginBottom:10}}>CONTENT NICHE</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                {NICHES.map(n=>(
                  <button key={n.id} onClick={()=>setNicheId(n.id)}
                    style={{background:nicheId===n.id?`rgba(${n.rgb},.12)`:"#060610",border:`1px solid ${nicheId===n.id?n.color:"rgba(255,255,255,.07)"}`,borderRadius:10,padding:"12px 8px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:6}}>
                    <span style={{fontSize:22}}>{n.emoji}</span>
                    <span style={{fontSize:11,color:nicheId===n.id?n.color:"#555"}}>{n.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1,marginBottom:8}}>SCHEDULE</div>
              {SCHEDULES.map((s,i)=>(
                <button key={i} onClick={()=>setSchedIdx(i)}
                  style={{background:schedIdx===i?"rgba(34,211,238,.08)":"#060610",border:`1px solid ${schedIdx===i?"rgba(34,211,238,.4)":"rgba(255,255,255,.07)"}`,borderRadius:8,padding:"10px 14px",cursor:"pointer",display:"flex",justifyContent:"space-between",width:"100%",marginBottom:6}}>
                  <span style={{fontSize:13,color:schedIdx===i?"#22d3ee":"#777"}}>{s.label}</span>
                  <span style={{fontSize:11,fontFamily:"monospace",color:schedIdx===i?"#22d3ee":"#444"}}>{s.times.join(" · ")}</span>
                </button>
              ))}
            </div>
          </div>
        ),
      },
    ];
    const step=steps[setupStep], isLast=setupStep===steps.length-1;
    return(
      <div style={{minHeight:"100vh",background:"#03030b",display:"flex",alignItems:"center",justifyContent:"center",padding:20,fontFamily:"monospace"}}>
        <div style={{width:"100%",maxWidth:520}}>
          <div style={{textAlign:"center",marginBottom:28}}>
            <div style={{fontSize:26,fontWeight:900,letterSpacing:3,background:"linear-gradient(135deg,#22d3ee,#a78bfa,#f472b6)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",marginBottom:4}}>INSTAUTO</div>
            <div style={{fontSize:11,color:"#444",letterSpacing:2}}>STORYTELLING REEL AUTOMATION</div>
          </div>
          <div style={{display:"flex",gap:6,marginBottom:24}}>
            {steps.map((_,i)=>(
              <div key={i} style={{height:3,flex:1,borderRadius:2,background:i<=setupStep?"#22d3ee":"rgba(255,255,255,.08)"}}/>
            ))}
          </div>
          <div style={{background:"#070712",border:"1px solid rgba(255,255,255,.07)",borderRadius:16,padding:"24px 24px 20px",marginBottom:12}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:20}}>
              <div style={{width:34,height:34,background:"rgba(34,211,238,.1)",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:17}}>{step.icon}</div>
              <div>
                <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:2}}>STEP {setupStep+1} OF {steps.length}</div>
                <div style={{fontSize:14,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif"}}>{step.title}</div>
              </div>
            </div>
            {step.content}
          </div>
          <div style={{display:"flex",gap:10}}>
            {setupStep>0&&<button onClick={()=>setSetupStep(p=>p-1)} style={{...btn,background:"rgba(255,255,255,.05)",color:"#666",border:"1px solid rgba(255,255,255,.08)",width:44}}>←</button>}
            <button disabled={!step.valid} onClick={()=>{if(isLast){store.set("done",true);setSetupDone(true);}else setSetupStep(p=>p+1);}}
              style={{...btn,flex:1,background:step.valid?"#22d3ee":"rgba(255,255,255,.05)",color:step.valid?"#000":"#333",cursor:step.valid?"pointer":"not-allowed"}}>
              {isLast?"🚀 Launch Storyteller":"Continue →"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── DASHBOARD ─────────────────────────────────────────────────────────────
  const statusInfo={
    idle:{label:"Standing by",color:"#444",dot:"#333"},
    generating:{label:"Writing story…",color:"#a78bfa",dot:"#a78bfa"},
    recording:{label:`Recording… ${Math.round(recPct)}%`,color:"#fb923c",dot:"#fb923c"},
    uploading:{label:"Uploading…",color:"#22d3ee",dot:"#22d3ee"},
    posting:{label:"Posting to Instagram…",color:"#22d3ee",dot:"#22d3ee"},
    done:{label:"✓ Posted!",color:"#4ade80",dot:"#4ade80"},
    error:{label:"Error — check log",color:"#f87171",dot:"#f87171"},
  }[status]||{label:"—",color:"#444",dot:"#333"};

  return(
    <div style={{minHeight:"100vh",background:"#03030b",color:"#d0d0e0",fontFamily:"monospace",display:"flex",flexDirection:"column"}}>
      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}*{box-sizing:border-box}::-webkit-scrollbar{width:3px}::-webkit-scrollbar-thumb{background:#111;border-radius:2px}input:focus{outline:none;border-color:rgba(34,211,238,.4)!important}input::placeholder{color:#1e1e2e}button:disabled{opacity:.4;cursor:not-allowed!important}`}</style>

      {/* Header */}
      <div style={{background:"#050510",borderBottom:"1px solid rgba(255,255,255,.05)",padding:"12px 20px",display:"flex",alignItems:"center",gap:14,position:"sticky",top:0,zIndex:100}}>
        <div style={{fontSize:15,fontWeight:900,letterSpacing:3,background:"linear-gradient(135deg,#22d3ee,#a78bfa)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>INSTAUTO</div>
        <div style={{fontSize:10,color:"#333",letterSpacing:1}}>STORYTELLER</div>
        <div style={{fontSize:11,color:niche?.color||"#444",background:`rgba(${niche?.rgb||"100,100,100"},.1)`,border:`1px solid rgba(${niche?.rgb||"100,100,100"},.2)`,padding:"3px 10px",borderRadius:20}}>
          {niche?.emoji} {niche?.label}
        </div>
        <div style={{display:"flex",alignItems:"center",gap:6,marginLeft:"auto"}}>
          <div style={{width:6,height:6,borderRadius:"50%",background:statusInfo.dot,boxShadow:`0 0 8px ${statusInfo.dot}`,animation:status!=="idle"&&status!=="done"?"pulse 1s infinite":"none"}}/>
          <span style={{fontSize:11,color:statusInfo.color}}>{statusInfo.label}</span>
        </div>
        <button onClick={()=>{setSetupDone(false);setSetupStep(0);store.set("done",false);}}
          style={{...btn,padding:"4px 10px",fontSize:10,color:"#333",background:"none",border:"1px solid rgba(255,255,255,.06)"}}>⚙ Setup</button>
      </div>

      <div style={{flex:1,display:"grid",gridTemplateColumns:"1fr 300px",overflow:"hidden"}}>
        {/* Left */}
        <div style={{padding:18,overflowY:"auto",borderRight:"1px solid rgba(255,255,255,.04)"}}>

          {/* Toggle */}
          <div style={{background:"#070712",border:`1px solid ${running?"rgba(34,211,238,.25)":"rgba(255,255,255,.07)"}`,borderRadius:14,padding:20,marginBottom:14}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:running?14:0}}>
              <div>
                <div style={{fontSize:14,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif",marginBottom:3}}>
                  {running?"Storyteller is running":"Storyteller is paused"}
                </div>
                <div style={{fontSize:11,color:"#444"}}>
                  {running?`Next post in ${nextPost||"…"}`:`${SCHEDULES[schedIdx].label} · ${schedule.join(" · ")}`}
                </div>
              </div>
              <button onClick={()=>setRunning(p=>!p)}
                style={{width:58,height:32,borderRadius:16,background:running?"#22d3ee":"rgba(255,255,255,.06)",border:`1px solid ${running?"#22d3ee":"rgba(255,255,255,.1)"}`,cursor:"pointer",position:"relative",flexShrink:0}}>
                <div style={{position:"absolute",top:3,left:running?27:3,width:24,height:24,background:running?"#000":"#333",borderRadius:"50%",transition:"left .2s"}}/>
              </button>
            </div>
            {running&&(
              <div style={{display:"flex",gap:8,alignItems:"center",paddingTop:14,borderTop:"1px solid rgba(255,255,255,.05)"}}>
                <div style={{flex:1,height:3,background:"rgba(255,255,255,.05)",borderRadius:2,overflow:"hidden"}}>
                  {status==="recording"&&<div style={{height:"100%",width:`${recPct}%`,background:"linear-gradient(90deg,#22d3ee,#a78bfa)",borderRadius:2,transition:"width .2s"}}/>}
                </div>
                <button onClick={pipeline} disabled={status!=="idle"&&status!=="done"&&status!=="error"}
                  style={{...btn,padding:"5px 12px",fontSize:11,background:"rgba(34,211,238,.1)",color:"#22d3ee",border:"1px solid rgba(34,211,238,.2)"}}>
                  ▶ Post Now
                </button>
              </div>
            )}
          </div>

          {/* Voice toggle */}
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 14px",background:"#070712",border:"1px solid rgba(255,255,255,.06)",borderRadius:10,marginBottom:14}}>
            <div>
              <div style={{fontSize:12,color:"#c0c0d0",fontWeight:500}}>🎙️ Voiceover preview</div>
              <div style={{fontSize:11,color:"#444"}}>Browser TTS reads the story aloud when generated</div>
            </div>
            <button onClick={()=>setVoiceOn(p=>!p)}
              style={{width:46,height:26,borderRadius:13,background:voiceOn?"#22d3ee":"rgba(255,255,255,.06)",border:`1px solid ${voiceOn?"#22d3ee":"rgba(255,255,255,.1)"}`,cursor:"pointer",position:"relative",flexShrink:0}}>
              <div style={{position:"absolute",top:2,left:voiceOn?21:2,width:20,height:20,background:voiceOn?"#000":"#333",borderRadius:"50%",transition:"left .2s"}}/>
            </button>
          </div>

          {/* Canvas preview */}
          <div style={{marginBottom:14}}>
            <button onClick={()=>setShowCanvas(p=>!p)}
              style={{...btn,width:"100%",justifyContent:"space-between",background:"#070712",border:"1px solid rgba(255,255,255,.06)",color:"#555",fontSize:12,padding:"10px 16px",marginBottom:showCanvas?8:0}}>
              <span>🎬 Story Preview (live)</span>
              <span>{showCanvas?"▲ Hide":"▼ Show"}</span>
            </button>
            <div style={{display:showCanvas?"flex":"none",justifyContent:"center",background:"#000",borderRadius:10,overflow:"hidden",border:"1px solid rgba(255,255,255,.06)"}}>
              <canvas ref={canvasRef} width={CW} height={CH} style={{display:"block",width:"100%",maxWidth:270}}/>
            </div>
            {!showCanvas&&<canvas ref={canvasRef} width={CW} height={CH} style={{display:"none"}}/>}
          </div>

          {/* Story content preview */}
          {content&&(
            <div style={{background:"#070712",border:"1px solid rgba(255,255,255,.06)",borderRadius:12,padding:16,marginBottom:14}}>
              <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:10}}>CURRENT STORY</div>
              <div style={{fontSize:13,color:niche?.color,fontWeight:700,marginBottom:10}}>{content.hook}</div>
              {content.scenes?.map((sc,i)=>(
                <div key={i} style={{display:"flex",gap:8,marginBottom:8,padding:"8px 10px",background:"rgba(255,255,255,.03)",borderRadius:7,border:"1px solid rgba(255,255,255,.05)"}}>
                  <span style={{fontSize:16}}>{"🌅😤💡🎉"[i]}</span>
                  <div>
                    <div style={{fontSize:11,color:"#c0c0d0",fontWeight:500}}>{sc.caption}</div>
                    <div style={{fontSize:11,color:"#555"}}>{sc.bubble}</div>
                  </div>
                </div>
              ))}
              <div style={{display:"flex",gap:8,marginTop:10}}>
                <button onClick={()=>speak(content.voiceover)} style={{...btn,flex:1,background:"rgba(167,139,250,.1)",color:"#a78bfa",border:"1px solid rgba(167,139,250,.2)",fontSize:11}}>
                  🔊 Play Voiceover
                </button>
                <button onClick={()=>{setContent(null);contentRef.current=null;generateContent();}} style={{...btn,flex:1,background:"rgba(255,255,255,.05)",color:"#666",border:"1px solid rgba(255,255,255,.08)",fontSize:11}}>
                  🔄 New Story
                </button>
              </div>
            </div>
          )}

          {/* How it works */}
          <div style={{background:"#070712",border:"1px solid rgba(255,255,255,.06)",borderRadius:12,padding:16}}>
            <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:12}}>THE STORYTELLING FORMAT</div>
            {[
              ["🌅","Scene 1 — The Hook","Character walks in, relatable opening problem"],
              ["😤","Scene 2 — The Struggle","Character frustrated, audience thinks 'that's me!'"],
              ["💡","Scene 3 — The Solution","Discovery moment, builds curiosity"],
              ["🎉","Scene 4 — Celebration","Result + CTA to follow + gift prompt"],
            ].map(([icon,title,desc],i)=>(
              <div key={i} style={{display:"flex",gap:10,marginBottom:i<3?12:0,paddingBottom:i<3?12:0,borderBottom:i<3?"1px solid rgba(255,255,255,.04)":"none"}}>
                <div style={{fontSize:18,flexShrink:0}}>{icon}</div>
                <div>
                  <div style={{fontSize:12,color:"#c0c0d0",fontWeight:600,fontFamily:"sans-serif",marginBottom:2}}>{title}</div>
                  <div style={{fontSize:11,color:"#444",lineHeight:1.6}}>{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right */}
        <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>
          <div style={{padding:"14px 14px 8px",borderBottom:"1px solid rgba(255,255,255,.04)"}}>
            <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:8}}>POSTED ({posts.length})</div>
            {posts.length===0
              ?<div style={{fontSize:11,color:"#222",textAlign:"center",padding:"16px 0"}}>No posts yet</div>
              :<div style={{display:"flex",flexDirection:"column",gap:5,maxHeight:180,overflowY:"auto"}}>
                {posts.map((p,i)=>(
                  <div key={i} style={{display:"flex",gap:7,alignItems:"center",padding:"7px 9px",background:"rgba(74,222,128,.05)",border:"1px solid rgba(74,222,128,.1)",borderRadius:6}}>
                    <div style={{width:5,height:5,borderRadius:"50%",background:"#4ade80",flexShrink:0}}/>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:11,color:"#c0c0d0",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{p.hook}</div>
                      <div style={{fontSize:10,color:"#333"}}>{p.niche} · {fmt(p.ts)}</div>
                    </div>
                  </div>
                ))}
              </div>
            }
          </div>
          <div style={{flex:1,overflow:"hidden",display:"flex",flexDirection:"column",padding:"10px 14px 14px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
              <div style={{fontSize:10,color:"#333",letterSpacing:1}}>LOG</div>
              <button onClick={()=>setLog([])} style={{...btn,padding:"2px 7px",fontSize:10,color:"#333",background:"none",border:"1px solid rgba(255,255,255,.05)"}}>Clear</button>
            </div>
            <div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:3,fontSize:11}}>
              {log.length===0?<span style={{color:"#1e1e2e"}}>Waiting…</span>
                :[...log].reverse().map((l,i)=>(
                  <div key={i} style={{display:"flex",gap:6}}>
                    <span style={{color:"#222",flexShrink:0,fontSize:10}}>{fmt(l.ts)}</span>
                    <span style={{color:l.type==="success"?"#4ade80":l.type==="error"?"#f87171":"#555",lineHeight:1.5}}>{l.msg}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
