import { useState, useEffect, useRef, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────
const NICHES = [
  { id:"tech",       label:"Tech & AI",    emoji:"🤖", color:"#22d3ee", rgb:"34,211,238"   },
  { id:"finance",    label:"Finance Tips", emoji:"💰", color:"#4ade80", rgb:"74,222,128"   },
  { id:"coding",     label:"Coding",       emoji:"💻", color:"#a78bfa", rgb:"167,139,250"  },
  { id:"business",   label:"Business",     emoji:"📈", color:"#fbbf24", rgb:"251,191,36"   },
  { id:"motivation", label:"Motivation",   emoji:"🔥", color:"#fb923c", rgb:"251,146,60"   },
  { id:"lifestyle",  label:"Lifestyle",    emoji:"✨", color:"#f472b6", rgb:"244,114,182"  },
];

const SCHEDULES = [
  { label:"3× Daily (Recommended)", times:["09:00","13:00","19:00"] },
  { label:"2× Daily",               times:["09:00","19:00"]         },
  { label:"Morning Only",           times:["09:00"]                  },
];

const CW = 405, CH = 720, REC_S = 30;

// ─── Canvas renderer ──────────────────────────────────────────────────────────
const easeOut = t => 1 - Math.pow(Math.max(0,1-t),3);

function drawFrame(ctx, t, content, niche) {
  const W=CW, H=CH;
  const col = niche?.color || "#22d3ee";
  const rgb = niche?.rgb   || "34,211,238";
  ctx.clearRect(0,0,W,H);

  // bg
  const bg = ctx.createLinearGradient(0,0,0,H);
  bg.addColorStop(0,`rgba(${rgb},.12)`);
  bg.addColorStop(.5,"#04040e");
  bg.addColorStop(1,"#02020a");
  ctx.fillStyle=bg; ctx.fillRect(0,0,W,H);

  // grid lines
  ctx.save();
  ctx.strokeStyle=`rgba(${rgb},.055)`; ctx.lineWidth=1;
  const s=(t*22)%44;
  for(let i=-H;i<W+H;i+=44){ ctx.beginPath(); ctx.moveTo(i+s,0); ctx.lineTo(i+s+H*.55,H); ctx.stroke(); }
  ctx.restore();

  // niche pill
  const pa=easeOut(Math.max(0,(t-.5)*2));
  if(pa>0){
    ctx.save(); ctx.globalAlpha=pa;
    ctx.fillStyle=`rgba(${rgb},.15)`;
    const pt = `${niche?.emoji||""} ${niche?.label||""}`;
    const pw = ctx.measureText(pt).width+24;
    ctx.beginPath(); ctx.roundRect(W/2-pw/2,18,pw,26,13); ctx.fill();
    ctx.font="500 11px 'Courier New', monospace"; ctx.fillStyle=col;
    ctx.textAlign="center"; ctx.fillText(pt,W/2,35);
    ctx.restore();
  }

  // hook
  if(t>=1&&content?.hook){
    const p=easeOut((t-1)*1.2); const yo=(1-p)*60;
    ctx.save(); ctx.globalAlpha=p; ctx.translate(0,yo);
    ctx.fillStyle=col;
    ctx.beginPath(); ctx.roundRect(W*.06,H*.19,W*.88,4,2); ctx.fill();
    const fs=content.hook.length>30?19:23;
    ctx.font=`900 ${fs}px 'Arial Black',Impact,sans-serif`;
    ctx.fillStyle="#fff"; ctx.textAlign="center";
    ctx.shadowColor="rgba(0,0,0,.8)"; ctx.shadowBlur=10;
    const words=content.hook.toUpperCase().split(" ");
    let line="",y=H*.235;
    for(const w of words){
      const test=line+w+" ";
      if(ctx.measureText(test).width>W*.82&&line){ ctx.fillText(line.trim(),W/2,y); line=w+" "; y+=28; }
      else line=test;
    }
    ctx.fillText(line.trim(),W/2,y);
    ctx.restore();
  }

  // tips
  if(content?.tips){
    content.tips.slice(0,3).forEach((tip,i)=>{
      const st=5+i*5; if(t<st) return;
      const p=easeOut((t-st)*1.4); const xo=(1-p)*-40;
      const by=H*.42+i*82;
      ctx.save(); ctx.globalAlpha=p; ctx.translate(xo,0);
      ctx.fillStyle=col; ctx.fillRect(16,by,3,58);
      ctx.font=`900 38px 'Arial Black',sans-serif`;
      ctx.fillStyle=`rgba(${rgb},.2)`; ctx.textAlign="left";
      ctx.fillText(i+1,26,by+42);
      ctx.font="500 13px 'Courier New',monospace";
      ctx.fillStyle="rgba(255,255,255,.85)";
      const tw=tip; let tl="",ty=by+16;
      for(const w of tw.split(" ")){
        const tt=tl+w+" ";
        if(ctx.measureText(tt).width>W-96&&tl){ ctx.fillText(tl.trim(),70,ty); tl=w+" "; ty+=18; }
        else tl=tt;
      }
      ctx.fillText(tl.trim(),70,ty);
      ctx.restore();
    });
  }

  // cta
  if(t>=20){
    const p=easeOut((t-20)*1.3);
    const bounce=Math.sin((t-20)*4)*Math.max(0,1-(t-20)*.5)*5;
    ctx.save(); ctx.globalAlpha=p;
    ctx.shadowColor=col; ctx.shadowBlur=24;
    ctx.fillStyle=col;
    ctx.beginPath(); ctx.roundRect(W*.08,H*.84+bounce,W*.84,46,23); ctx.fill();
    ctx.shadowBlur=0;
    ctx.font="bold 13px 'Courier New',monospace";
    ctx.fillStyle="#000"; ctx.textAlign="center";
    ctx.fillText("FOLLOW FOR MORE  ★",W/2,H*.84+28+bounce);
    ctx.font="11px 'Courier New',monospace";
    ctx.fillStyle="rgba(255,255,255,.4)"; ctx.shadowBlur=0;
    ctx.fillText("🎁  Send a gift if this helped!",W/2,H*.84+66);
    ctx.restore();
  }

  // watermark
  ctx.globalAlpha=.2; ctx.font="10px monospace";
  ctx.fillStyle=col; ctx.textAlign="right";
  ctx.fillText("auto-posted",W-12,H-12); ctx.globalAlpha=1;
}

// ─── Storage ──────────────────────────────────────────────────────────────────
const store = {
  get: k => { try{ return JSON.parse(localStorage.getItem("ia_"+k)||"null"); }catch{ return null; } },
  set: (k,v) => { try{ localStorage.setItem("ia_"+k,JSON.stringify(v)); }catch{} },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
const pad = n => String(n).padStart(2,"0");
const hhmm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const fmt = d => new Date(d).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});

// ─── App ──────────────────────────────────────────────────────────────────────
export default function InstaAutoV2() {
  // persist setup
  const [creds,  setCreds]  = useState(() => store.get("creds")  || {igId:"",igToken:"",cloud:"",preset:""});
  const [nicheId,setNicheId]= useState(() => store.get("niche")  || null);
  const [schedIdx,setSchedIdx]=useState(()=>store.get("schedIdx")||0);
  const [setupDone, setSetupDone] = useState(() => store.get("done") || false);
  const [setupStep, setSetupStep] = useState(0);

  // runtime
  const [running,  setRunning]  = useState(false);
  const [content,  setContent]  = useState(null);
  const [status,   setStatus]   = useState("idle"); // idle | generating | recording | uploading | posting | done | error
  const [log,      setLog]      = useState([]);
  const [posts,    setPosts]    = useState(() => store.get("posts") || []);
  const [nextPost, setNextPost] = useState(null);
  const [recPct,   setRecPct]   = useState(0);
  const [showCanvas, setShowCanvas] = useState(false);

  const canvasRef  = useRef(null);
  const animRef    = useRef(null);
  const timerRef   = useRef(null);
  const runningRef = useRef(false);
  const contentRef = useRef(null);

  const niche = NICHES.find(n=>n.id===nicheId);
  const schedule = SCHEDULES[schedIdx]?.times || SCHEDULES[0].times;

  const addLog = useCallback((msg, type="info") => {
    const entry = {msg, type, ts: Date.now()};
    setLog(prev => [...prev.slice(-199), entry]);
  }, []);

  // persist
  useEffect(() => { store.set("creds",  creds);    }, [creds]);
  useEffect(() => { store.set("niche",  nicheId);  }, [nicheId]);
  useEffect(() => { store.set("schedIdx",schedIdx);}, [schedIdx]);
  useEffect(() => { store.set("done",   setupDone);}, [setupDone]);
  useEffect(() => { store.set("posts",  posts);    }, [posts]);

  // canvas loop
  useEffect(() => {
    const cvs = canvasRef.current; if(!cvs) return;
    const ctx = cvs.getContext("2d");
    let t0 = Date.now();
    const loop = () => {
      const t = ((Date.now()-t0)/1000)%(REC_S+2);
      drawFrame(ctx, t, contentRef.current, niche);
      animRef.current = requestAnimationFrame(loop);
    };
    animRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animRef.current);
  }, [niche]);

  // next post countdown
  useEffect(() => {
    const iv = setInterval(() => {
      const now = new Date();
      const nowM = now.getHours()*60+now.getMinutes();
      const slots = schedule.map(t => { const [h,m]=t.split(":").map(Number); return h*60+m; });
      const future = slots.filter(m=>m>nowM);
      const nextM = future.length ? future[0] : slots[0]+1440;
      const diff = nextM-nowM;
      const h=Math.floor(diff/60), m=diff%60;
      setNextPost(`${h}h ${m}m`);
    }, 10000);
    return ()=>clearInterval(iv);
  }, [schedule]);

  // scheduler
  useEffect(() => {
    if(!running) return;
    addLog("🤖 Automation started — monitoring schedule");
    const iv = setInterval(async () => {
      if(!runningRef.current) return;
      const now = hhmm(new Date());
      if(schedule.includes(now)) {
        addLog(`⏰ Trigger at ${now}`);
        await pipeline();
      }
    }, 60_000);
    return () => { clearInterval(iv); addLog("⏸ Automation paused"); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, schedule]);

  useEffect(() => { runningRef.current = running; }, [running]);

  // ── Pipeline ────────────────────────────────────────────────────────────────
  const pipeline = useCallback(async () => {
    const igId=creds.igId, token=creds.igToken, cloud=creds.cloud, preset=creds.preset;
    if(!igId||!token||!cloud||!preset||!nicheId){
      addLog("❌ Missing credentials or niche","error"); return;
    }
    const nicheObj = NICHES.find(n=>n.id===nicheId);

    // 1. Generate
    setStatus("generating");
    addLog("✦ Generating script with Claude AI…");
    let ct;
    try{
      const res = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514", max_tokens:800,
          system:"Expert Instagram Reels strategist. Return ONLY valid JSON, no markdown.",
          messages:[{role:"user",content:`Viral reel for "${nicheObj.label}" niche. Return ONLY:
{"hook":"8-word punchy opening","tips":["key point 1 (10 words max)","key point 2","key point 3"],"caption":"250-char Instagram caption with emojis, CTA to follow, CTA for gift","hashtags":"20 hashtags space-separated"}`}]
        })
      });
      const d=await res.json();
      if(d.error) throw new Error(d.error.message);
      const raw=d.content.map(c=>c.text||"").join("").replace(/```json|```/g,"").trim();
      ct=JSON.parse(raw);
      ct.fullCaption=`${ct.caption}\n\n${ct.hashtags}`;
      setContent(ct); contentRef.current=ct;
      addLog(`✓ Script ready — "${ct.hook}"`, "success");
    }catch(e){ addLog(`❌ Script error: ${e.message}`,"error"); setStatus("error"); return; }

    // small pause so canvas picks up new content
    await new Promise(r=>setTimeout(r,1200));

    // 2. Record
    setStatus("recording");
    addLog(`🎥 Recording ${REC_S}s reel…`);
    let blob;
    try{
      blob = await new Promise((resolve,reject)=>{
        const cvs=canvasRef.current;
        if(!cvs) return reject(new Error("Canvas not ready"));
        const stream=cvs.captureStream(30);
        const mime=["video/mp4;codecs=avc1","video/webm;codecs=vp9","video/webm"].find(m=>MediaRecorder.isTypeSupported(m))||"video/webm";
        const rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:2_500_000});
        const chunks=[];
        rec.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data);};
        rec.onstop=()=>resolve(new Blob(chunks,{type:mime}));
        rec.onerror=e=>reject(e.error);
        rec.start(300);
        const t0=Date.now();
        const iv=setInterval(()=>{
          const pct=Math.min(100,((Date.now()-t0)/1000/REC_S)*100);
          setRecPct(pct);
          if(pct>=100){clearInterval(iv);rec.stop();}
        },200);
      });
      addLog(`✓ Reel recorded — ${(blob.size/1024/1024).toFixed(1)}MB`,"success");
    }catch(e){ addLog(`❌ Record error: ${e.message}`,"error"); setStatus("error"); return; }

    // 3. Upload
    setStatus("uploading");
    addLog("☁️ Uploading to Cloudinary…");
    let videoUrl;
    try{
      const fd=new FormData();
      fd.append("file",blob,"reel.webm");
      fd.append("upload_preset",preset);
      fd.append("resource_type","video");
      const ur=await fetch(`https://api.cloudinary.com/v1_1/${cloud}/video/upload`,{method:"POST",body:fd});
      if(!ur.ok) throw new Error(`Cloudinary ${ur.status}`);
      const ud=await ur.json();
      videoUrl=ud.secure_url.replace("/upload/","/upload/f_mp4,vc_h264,ac_aac/");
      addLog(`✓ Video hosted`,"success");
    }catch(e){ addLog(`❌ Upload error: ${e.message}`,"error"); setStatus("error"); return; }

    // 4. Post
    setStatus("posting");
    addLog("📤 Creating Instagram container…");
    try{
      const base=`https://graph.facebook.com/v19.0`;
      const c1=await fetch(`${base}/${igId}/media`,{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({media_type:"REELS",video_url:videoUrl,caption:ct.fullCaption,share_to_feed:true,access_token:token})});
      const r1=await c1.json();
      if(r1.error) throw new Error(r1.error.message);
      addLog(`📦 Container: ${r1.id} — waiting for processing…`);
      for(let i=0;i<24;i++){
        await new Promise(r=>setTimeout(r,5000));
        const sr=await fetch(`${base}/${r1.id}?fields=status_code&access_token=${token}`);
        const sd=await sr.json();
        addLog(`   status: ${sd.status_code}`);
        if(sd.status_code==="FINISHED") break;
        if(sd.status_code==="ERROR") throw new Error("IG processing error");
      }
      const c3=await fetch(`${base}/${igId}/media_publish`,{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({creation_id:r1.id,access_token:token})});
      const r3=await c3.json();
      if(r3.error) throw new Error(r3.error.message);
      addLog(`🎉 REEL POSTED! ID: ${r3.id}`,"success");
      const record={id:r3.id,hook:ct.hook,niche:nicheObj.label,ts:Date.now()};
      setPosts(p=>[record,...p.slice(0,29)]);
      setStatus("done");
      setTimeout(()=>setStatus("idle"),4000);
    }catch(e){ addLog(`❌ Post error: ${e.message}`,"error"); setStatus("error"); }
  }, [creds, nicheId, addLog]);

  // ── Manual trigger ──────────────────────────────────────────────────────────
  const manualTrigger = useCallback(async () => {
    await pipeline();
  }, [pipeline]);

  // ─── SETUP WIZARD ───────────────────────────────────────────────────────────
  if(!setupDone){
    const steps = [
      {
        title:"Connect Instagram",
        icon:"📱",
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <p style={{fontSize:13,color:"#666",lineHeight:1.7,margin:0}}>
              You need an <strong style={{color:"#e0e0e0"}}>Instagram Business or Creator account</strong> linked to a Facebook Page,
              plus an access token from the Meta developer portal.
            </p>
            <div style={{display:"grid",gridTemplateColumns:"1fr",gap:12}}>
              <label style={{display:"flex",flexDirection:"column",gap:6}}>
                <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>INSTAGRAM ACCOUNT ID</span>
                <input type="text" placeholder="17841400000000000"
                  value={creds.igId}
                  onChange={e=>setCreds(p=>({...p,igId:e.target.value}))}
                  style={inp}/>
                <span style={{fontSize:11,color:"#444"}}>Settings → Account → Instagram Account ID</span>
              </label>
              <label style={{display:"flex",flexDirection:"column",gap:6}}>
                <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>LONG-LIVED ACCESS TOKEN</span>
                <input type="password" placeholder="EAAxxxxx…"
                  value={creds.igToken}
                  onChange={e=>setCreds(p=>({...p,igToken:e.target.value}))}
                  style={inp}/>
                <span style={{fontSize:11,color:"#444"}}>developers.facebook.com → Graph API Explorer → Generate Token</span>
              </label>
            </div>
            <div style={{background:"rgba(34,211,238,.06)",border:"1px solid rgba(34,211,238,.15)",borderRadius:8,padding:12,fontSize:11,color:"#888",lineHeight:1.8}}>
              <strong style={{color:"#22d3ee"}}>Required token scopes:</strong>{" "}
              instagram_basic, instagram_content_publish, pages_read_engagement
            </div>
          </div>
        ),
        valid: !!creds.igId && !!creds.igToken,
      },
      {
        title:"Connect Video Hosting",
        icon:"☁️",
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <p style={{fontSize:13,color:"#666",lineHeight:1.7,margin:0}}>
              Instagram's API can't accept a file directly — it needs a <strong style={{color:"#e0e0e0"}}>public HTTPS video URL</strong>.
              Cloudinary is free and handles this automatically.
            </p>
            <div style={{display:"grid",gridTemplateColumns:"1fr",gap:12}}>
              <label style={{display:"flex",flexDirection:"column",gap:6}}>
                <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>CLOUDINARY CLOUD NAME</span>
                <input type="text" placeholder="my-cloudinary-name"
                  value={creds.cloud}
                  onChange={e=>setCreds(p=>({...p,cloud:e.target.value}))}
                  style={inp}/>
                <span style={{fontSize:11,color:"#444"}}>cloudinary.com → Dashboard (shown at top)</span>
              </label>
              <label style={{display:"flex",flexDirection:"column",gap:6}}>
                <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>UNSIGNED UPLOAD PRESET</span>
                <input type="text" placeholder="instagram_reels"
                  value={creds.preset}
                  onChange={e=>setCreds(p=>({...p,preset:e.target.value}))}
                  style={inp}/>
                <span style={{fontSize:11,color:"#444"}}>Settings → Upload → Upload Presets → Add Unsigned Preset</span>
              </label>
            </div>
            <div style={{background:"rgba(74,222,128,.06)",border:"1px solid rgba(74,222,128,.15)",borderRadius:8,padding:12,fontSize:11,color:"#888",lineHeight:1.8}}>
              <strong style={{color:"#4ade80"}}>Free plan:</strong> 25GB storage + 25GB bandwidth/month. Enough for ~500 reels.
              Sign up free at cloudinary.com — no credit card needed.
            </div>
          </div>
        ),
        valid: !!creds.cloud && !!creds.preset,
      },
      {
        title:"Pick Your Niche & Schedule",
        icon:"🎯",
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:20}}>
            <div>
              <div style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1,marginBottom:10}}>CONTENT NICHE</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                {NICHES.map(n=>(
                  <button key={n.id}
                    onClick={()=>setNicheId(n.id)}
                    style={{background:nicheId===n.id?`rgba(${n.rgb},.12)`:"#060610",border:`1px solid ${nicheId===n.id?n.color:"rgba(255,255,255,.07)"}`,borderRadius:10,padding:"12px 8px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:6,transition:"all .15s"}}>
                    <span style={{fontSize:22}}>{n.emoji}</span>
                    <span style={{fontSize:11,color:nicheId===n.id?n.color:"#555"}}>{n.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1,marginBottom:10}}>POSTING SCHEDULE</div>
              <div style={{display:"flex",flexDirection:"column",gap:6}}>
                {SCHEDULES.map((s,i)=>(
                  <button key={i}
                    onClick={()=>setSchedIdx(i)}
                    style={{background:schedIdx===i?"rgba(34,211,238,.08)":"#060610",border:`1px solid ${schedIdx===i?"rgba(34,211,238,.4)":"rgba(255,255,255,.07)"}`,borderRadius:8,padding:"11px 14px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",transition:"all .15s"}}>
                    <span style={{fontSize:13,color:schedIdx===i?"#22d3ee":"#777"}}>{s.label}</span>
                    <span style={{fontSize:11,fontFamily:"monospace",color:schedIdx===i?"#22d3ee":"#444"}}>{s.times.join(" · ")}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ),
        valid: !!nicheId,
      },
    ];

    const step = steps[setupStep];
    const isLast = setupStep === steps.length-1;

    return (
      <>
        <style>{baseStyles}</style>
        <div style={{minHeight:"100vh",background:"#03030b",display:"flex",alignItems:"center",justifyContent:"center",padding:20,fontFamily:"'Courier New',monospace"}}>
          <div style={{width:"100%",maxWidth:520}}>
            {/* Logo */}
            <div style={{textAlign:"center",marginBottom:32}}>
              <div style={{fontSize:28,fontWeight:900,letterSpacing:3,background:"linear-gradient(135deg,#22d3ee,#a78bfa,#f472b6)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",marginBottom:4}}>
                INSTAUTO
              </div>
              <div style={{fontSize:11,color:"#333",letterSpacing:2}}>AI REELS AUTOMATION</div>
            </div>

            {/* Progress */}
            <div style={{display:"flex",gap:6,marginBottom:28,justifyContent:"center"}}>
              {steps.map((_,i)=>(
                <div key={i} style={{height:3,flex:1,borderRadius:2,background:i<=setupStep?"#22d3ee":"rgba(255,255,255,.08)",transition:"background .3s"}}/>
              ))}
            </div>

            {/* Card */}
            <div style={{background:"#070712",border:"1px solid rgba(255,255,255,.07)",borderRadius:16,padding:"28px 28px 24px",marginBottom:14}}>
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:22}}>
                <div style={{width:36,height:36,background:"rgba(34,211,238,.1)",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>{step.icon}</div>
                <div>
                  <div style={{fontSize:11,color:"#333",letterSpacing:1,marginBottom:2}}>STEP {setupStep+1} OF {steps.length}</div>
                  <div style={{fontSize:15,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif"}}>{step.title}</div>
                </div>
              </div>
              {step.content}
            </div>

            <div style={{display:"flex",gap:10}}>
              {setupStep>0 && (
                <button onClick={()=>setSetupStep(p=>p-1)} style={{...btn, background:"rgba(255,255,255,.05)",color:"#666",border:"1px solid rgba(255,255,255,.08)",flex:"0 0 auto",width:44}}>←</button>
              )}
              <button
                disabled={!step.valid}
                onClick={()=>{
                  if(isLast){ store.set("done",true); setSetupDone(true); }
                  else setSetupStep(p=>p+1);
                }}
                style={{...btn,flex:1,background:step.valid?"#22d3ee":"rgba(255,255,255,.05)",color:step.valid?"#000":"#333",cursor:step.valid?"pointer":"not-allowed"}}>
                {isLast ? "🚀 Launch Automation" : "Continue →"}
              </button>
            </div>
            <div style={{textAlign:"center",marginTop:14,fontSize:11,color:"#222"}}>Your credentials are saved locally in this browser only</div>
          </div>
        </div>
      </>
    );
  }

  // ─── MAIN DASHBOARD ──────────────────────────────────────────────────────────
  const statusInfo = {
    idle:       {label:"Standing by",         color:"#444",  dot:"#333"  },
    generating: {label:"Generating script…",  color:"#a78bfa",dot:"#a78bfa"},
    recording:  {label:`Recording reel… ${Math.round(recPct)}%`, color:"#fb923c",dot:"#fb923c"},
    uploading:  {label:"Uploading video…",    color:"#22d3ee",dot:"#22d3ee"},
    posting:    {label:"Posting to Instagram…",color:"#22d3ee",dot:"#22d3ee"},
    done:       {label:"✓ Posted!",           color:"#4ade80",dot:"#4ade80"},
    error:      {label:"Error — check log",   color:"#f87171",dot:"#f87171"},
  }[status] || {label:"—",color:"#444",dot:"#333"};

  return (
    <>
      <style>{baseStyles}</style>
      <div style={{minHeight:"100vh",background:"#03030b",color:"#d0d0e0",fontFamily:"'Courier New',monospace",display:"flex",flexDirection:"column"}}>

        {/* Header */}
        <div style={{background:"#050510",borderBottom:"1px solid rgba(255,255,255,.05)",padding:"14px 20px",display:"flex",alignItems:"center",gap:16,position:"sticky",top:0,zIndex:100}}>
          <div style={{fontSize:16,fontWeight:900,letterSpacing:3,background:"linear-gradient(135deg,#22d3ee,#a78bfa)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>INSTAUTO</div>
          <div style={{fontSize:11,color:niche?.color||"#444",background:`rgba(${niche?.rgb||"100,100,100"},.1)`,border:`1px solid rgba(${niche?.rgb||"100,100,100"},.2)`,padding:"3px 10px",borderRadius:20}}>
            {niche?.emoji} {niche?.label}
          </div>

          {/* status */}
          <div style={{display:"flex",alignItems:"center",gap:7,marginLeft:"auto"}}>
            <div style={{width:7,height:7,borderRadius:"50%",background:statusInfo.dot,boxShadow:`0 0 8px ${statusInfo.dot}`,animation:status!=="idle"&&status!=="done"?"pulse 1s infinite":"none"}}/>
            <span style={{fontSize:12,color:statusInfo.color}}>{statusInfo.label}</span>
          </div>

          {/* settings reset */}
          <button onClick={()=>{setSetupDone(false);setSetupStep(0);store.set("done",false);}}
            style={{...btn,padding:"5px 10px",fontSize:11,color:"#333",background:"none",border:"1px solid rgba(255,255,255,.06)"}}>
            ⚙ Setup
          </button>
        </div>

        {/* Body */}
        <div style={{flex:1,display:"grid",gridTemplateColumns:"1fr 320px",gap:0,overflow:"hidden"}}>

          {/* LEFT: Main control */}
          <div style={{padding:20,overflowY:"auto",borderRight:"1px solid rgba(255,255,255,.04)"}}>

            {/* Big toggle */}
            <div style={{background:"#070712",border:`1px solid ${running?"rgba(34,211,238,.25)":"rgba(255,255,255,.07)"}`,borderRadius:16,padding:24,marginBottom:16,transition:"border-color .3s"}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:running?16:0}}>
                <div>
                  <div style={{fontSize:15,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif",marginBottom:4}}>
                    {running?"Automation is running":"Automation is paused"}
                  </div>
                  <div style={{fontSize:12,color:"#444"}}>
                    {running?`Next post in ${nextPost||"calculating…"}`:`${SCHEDULES[schedIdx].label} · ${schedule.join(" · ")}`}
                  </div>
                </div>
                {/* big toggle button */}
                <button
                  onClick={()=>setRunning(p=>!p)}
                  style={{width:64,height:34,borderRadius:17,background:running?"#22d3ee":"rgba(255,255,255,.06)",border:`1px solid ${running?"#22d3ee":"rgba(255,255,255,.1)"}`,cursor:"pointer",position:"relative",transition:"all .25s",flexShrink:0}}>
                  <div style={{position:"absolute",top:3,left:running?31:3,width:26,height:26,background:running?"#000":"#333",borderRadius:"50%",transition:"left .25s,background .25s"}}/>
                </button>
              </div>

              {running && (
                <div style={{display:"flex",gap:8,alignItems:"center",paddingTop:16,borderTop:"1px solid rgba(255,255,255,.05)"}}>
                  <div style={{flex:1,height:4,background:"rgba(255,255,255,.05)",borderRadius:2,overflow:"hidden"}}>
                    {status==="recording"&&(
                      <div style={{height:"100%",width:`${recPct}%`,background:"linear-gradient(90deg,#22d3ee,#a78bfa)",borderRadius:2,transition:"width .2s"}}/>
                    )}
                  </div>
                  <button onClick={manualTrigger} disabled={status!=="idle"&&status!=="done"&&status!=="error"}
                    style={{...btn,padding:"6px 14px",fontSize:11,background:"rgba(34,211,238,.1)",color:"#22d3ee",border:"1px solid rgba(34,211,238,.2)"}}>
                    ▶ Post Now
                  </button>
                </div>
              )}
            </div>

            {/* Canvas preview toggle */}
            <div style={{marginBottom:16}}>
              <button onClick={()=>setShowCanvas(p=>!p)}
                style={{...btn,width:"100%",justifyContent:"space-between",background:"#070712",border:"1px solid rgba(255,255,255,.06)",color:"#555",fontSize:12,padding:"10px 16px"}}>
                <span>🎬 Reel Preview (live animation)</span>
                <span>{showCanvas?"▲ Hide":"▼ Show"}</span>
              </button>
              {showCanvas&&(
                <div style={{marginTop:10,display:"flex",justifyContent:"center",background:"#000",borderRadius:10,overflow:"hidden",border:"1px solid rgba(255,255,255,.06)"}}>
                  <canvas ref={canvasRef} width={CW} height={CH} style={{display:"block",width:"100%",maxWidth:280}}/>
                </div>
              )}
              {!showCanvas&&<canvas ref={canvasRef} width={CW} height={CH} style={{display:"none"}}/>}
            </div>

            {/* What it's doing box */}
            <div style={{background:"#070712",border:"1px solid rgba(255,255,255,.06)",borderRadius:12,padding:18,marginBottom:16}}>
              <div style={{fontSize:11,color:"#333",letterSpacing:1,marginBottom:12}}>HOW IT WORKS — ONE-TIME SETUP, THEN HANDS-OFF</div>
              {[
                ["🤖","Claude AI writes the script","Fresh hook, 3 key points, caption, 20 hashtags — unique every time"],
                ["🎬","Canvas records the video","30-second animated reel is created automatically from the script"],
                ["☁️","Cloudinary hosts it","Video uploaded and transcoded to MP4 with a public URL"],
                ["📤","Instagram API posts it","Published directly to your account as a Reel with caption"],
                ["⏰","Runs on your schedule",`Posts automatically at ${schedule.join(", ")} — no action needed`],
              ].map(([icon,title,desc],i)=>(
                <div key={i} style={{display:"flex",gap:12,marginBottom:i<4?14:0,paddingBottom:i<4?14:0,borderBottom:i<4?"1px solid rgba(255,255,255,.04)":"none"}}>
                  <div style={{fontSize:18,flexShrink:0,marginTop:1}}>{icon}</div>
                  <div>
                    <div style={{fontSize:12,color:"#c0c0d0",fontWeight:600,fontFamily:"sans-serif",marginBottom:2}}>{title}</div>
                    <div style={{fontSize:11,color:"#444",lineHeight:1.6}}>{desc}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Keep tab open note */}
            <div style={{background:"rgba(251,191,36,.05)",border:"1px solid rgba(251,191,36,.15)",borderRadius:8,padding:12,fontSize:11,color:"#876",lineHeight:1.7}}>
              <strong style={{color:"#fbbf24"}}>Keep this browser tab open</strong> for the scheduler to run.
              For 24/7 posting without a browser, you'd deploy this to a server (Vercel + cron job).
              If you close the tab, the next scheduled post will be skipped.
            </div>
          </div>

          {/* RIGHT: Posts + Log */}
          <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>

            {/* Posted reels */}
            <div style={{padding:"16px 16px 8px",borderBottom:"1px solid rgba(255,255,255,.04)",flex:"0 0 auto"}}>
              <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:10}}>POSTED REELS ({posts.length})</div>
              {posts.length===0?(
                <div style={{fontSize:12,color:"#222",textAlign:"center",padding:"20px 0"}}>No posts yet — start automation to post</div>
              ):(
                <div style={{display:"flex",flexDirection:"column",gap:6,maxHeight:200,overflowY:"auto"}}>
                  {posts.map((p,i)=>(
                    <div key={i} style={{display:"flex",gap:8,alignItems:"center",padding:"8px 10px",background:"rgba(74,222,128,.05)",border:"1px solid rgba(74,222,128,.1)",borderRadius:7}}>
                      <div style={{width:6,height:6,borderRadius:"50%",background:"#4ade80",flexShrink:0}}/>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontSize:11,color:"#c0c0d0",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{p.hook}</div>
                        <div style={{fontSize:10,color:"#333"}}>{p.niche} · {fmt(p.ts)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Log */}
            <div style={{flex:1,overflow:"hidden",display:"flex",flexDirection:"column",padding:"12px 16px 16px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <div style={{fontSize:10,color:"#333",letterSpacing:1}}>ACTIVITY LOG</div>
                <button onClick={()=>setLog([])} style={{...btn,padding:"2px 8px",fontSize:10,color:"#333",background:"none",border:"1px solid rgba(255,255,255,.05)"}}>Clear</button>
              </div>
              <div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:3,fontSize:11}}>
                {log.length===0?<span style={{color:"#222"}}>Waiting for activity…</span>
                  :[...log].reverse().map((l,i)=>(
                    <div key={i} style={{display:"flex",gap:7,alignItems:"flex-start"}}>
                      <span style={{color:"#222",flexShrink:0,fontSize:10}}>{fmt(l.ts)}</span>
                      <span style={{color:l.type==="success"?"#4ade80":l.type==="error"?"#f87171":"#555",lineHeight:1.5}}>{l.msg}</span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// ─── Shared styles ────────────────────────────────────────────────────────────
const inp = {
  background:"#030309",
  border:"1px solid rgba(255,255,255,.08)",
  borderRadius:6,
  padding:"10px 12px",
  fontFamily:"'Courier New',monospace",
  fontSize:12,
  color:"#d0d0e0",
  outline:"none",
  width:"100%",
};

const btn = {
  border:"none",
  borderRadius:8,
  fontFamily:"'Courier New',monospace",
  fontSize:12,
  padding:"10px 18px",
  cursor:"pointer",
  transition:"all .15s",
  display:"inline-flex",
  alignItems:"center",
  justifyContent:"center",
  gap:6,
};

const baseStyles = `
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#03030b}
  ::-webkit-scrollbar{width:3px}
  ::-webkit-scrollbar-thumb{background:#111;border-radius:2px}
  input:focus{outline:none;border-color:rgba(34,211,238,.4)!important}
  input::placeholder{color:#1e1e2e}
  button:disabled{opacity:.4;cursor:not-allowed!important}
`;
