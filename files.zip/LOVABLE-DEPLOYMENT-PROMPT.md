# INSTAUTO CINEMA — Lovable Deployment Prompt

## Copy this entire prompt and paste it into Lovable chat:

---

I need you to completely replace my App.jsx with new code I will paste below.

Please do the following exactly:

1. Delete everything currently in src/App.jsx
2. Paste the new code I provide as the entire contents of src/App.jsx
3. Do not rename any functions or change any logic
4. Do not add any new files or components — it is all self-contained in one file
5. Make sure the app runs and shows the INSTAUTO CINEMA dashboard

Here is the complete new App.jsx code:

[PASTE THE FULL InstaAutoCinema-v2.jsx CODE HERE]

---

## After Lovable deploys — checklist before hitting Post Now:

STEP 1 — Open the app and go through the 3-step setup wizard:
  - Step 1: Paste Instagram Account ID: 17841402485577171
  - Step 1: Paste your 60-day Access Token (EAAyKCIs…)
  - Step 2: Paste Cloudinary Cloud Name (from your Cloudinary dashboard)
  - Step 2: Paste Upload Preset name (the unsigned preset you created)
  - Step 3: Pick your niche — recommend Business/Freelance for your content
  - Step 3: Pick schedule — 3× Daily recommended (9AM, 1PM, 7PM)

STEP 2 — Click "Launch Cinema Automation"

STEP 3 — Flip the toggle ON

STEP 4 — Click "▶ Post Now" to test your first post immediately

---

## What was fixed in this version:

FIX 1 — Pollinations images (scenes 2,3,4 were failing with 504 error)
  OLD: All 4 images loaded in parallel simultaneously → rate limited → 504
  NEW: Images load one at a time sequentially with 2s gap between each
       + 3 automatic retries with different seeds if one fails
       + Always proceeds to record even if some images fail (canvas fallback)

FIX 2 — Audio in video (one faulty sound instead of proper music)
  OLD: Web Speech API (speechSynthesis) used → cannot be captured by MediaRecorder
       → bypasses the recording entirely → only artefact sound recorded
  NEW: Web Audio API used instead → generates a proper cinematic score
       (deep bass drone + harmonics + LFO breathing, tuned per niche)
       → directly connected to MediaRecorder stream → fully captured in video
       → fades in over 3 seconds, fades out at the end cleanly

FIX 3 — Instagram rejecting the video (IG processing ERROR)
  OLD: Cloudinary URL built with .replace() — fragile, sometimes malformed
       + No wait for Cloudinary to transcode before handing URL to Instagram
  NEW: URL built properly using public_id + 8 second transcode wait
       + Explicit Instagram-safe flags: f_mp4, vc_h264, ac_aac, br_2m, q_auto:good
       + Logs the actual IG error detail + video URL if it fails again

FIX 4 — Captions on screen
  The typewriter word-by-word caption was already rendering correctly on canvas.
  It was being hidden by the faulty audio making the video unplayable.
  With audio fixed, captions will display properly — words appear one by one
  synced to scene timing, with the latest word highlighted in niche color.

---

## Token renewal reminder:
Your access token expires 27 June 2026.
To renew, run this URL in your browser (same process as before):
https://graph.facebook.com/oauth/access_token?grant_type=fb_exchange_token&client_id=3529469017193871&client_secret=62da2c62052012dd7788add9462e6c33&fb_exchange_token=YOUR_NEW_SHORT_TOKEN
