import { useState, useEffect, useRef, useCallback } from "react";

const NICHES = [
  { id:"tech",       label:"Tech & AI",    emoji:"🤖", color:"#22d3ee", rgb:"34,211,238"   },
  { id:"finance",    label:"Finance Tips", emoji:"💰", color:"#4ade80", rgb:"74,222,128"   },
  { id:"coding",     label:"Coding",       emoji:"💻", color:"#a78bfa", rgb:"167,139,250"  },
  { id:"business",   label:"Business",     emoji:"📈", color:"#fbbf24", rgb:"251,191,36"   },
  { id:"motivation", label:"Motivation",   emoji:"🔥", color:"#fb923c", rgb:"251,146,60"   },
  { id:"lifestyle",  label:"Lifestyle",    emoji:"✨", color:"#f472b6", rgb:"244,114,182"  },
];

const SCHEDULES = [
  { label:"3× Daily (Recommended)", times:["09:00","13:00","19:00"] },
  { label:"2× Daily",               times:["09:00","19:00"]         },
  { label:"Morning Only",           times:["09:00"]                  },
];

const CW = 405, CH = 720, REC_S = 30;

const easeOut  = t => 1 - Math.pow(Math.max(0,1-t),3);
const easeInOut= t => t<.5 ? 2*t*t : -1+(4-2*t)*t;
const clamp    = (v,a,b) => Math.min(b,Math.max(a,v));

/* ── Particle system ── */
const PARTICLES = Array.from({length:28},(_,i)=>({
  x: Math.random(), y: Math.random()+.1,
  r: .5+Math.random()*2.5,
  sp: .004+Math.random()*.012,
  ph: Math.random()*Math.PI*2,
  drift: (Math.random()-.5)*.3,
}));

function drawParticles(ctx,t,col,rgb){
  ctx.save();
  PARTICLES.forEach(p=>{
    const y = ((p.y - p.sp*t*60*.016)%1+1)%1;
    const x = p.x + Math.sin(t*.4+p.ph)*p.drift*.04;
    const pulse = .3+Math.sin(t*1.2+p.ph)*.2;
    ctx.beginPath();
    ctx.arc(x*CW, y*CH, p.r, 0, Math.PI*2);
    ctx.fillStyle=`rgba(${rgb},${pulse})`;
    ctx.fill();
  });
  ctx.restore();
}

function drawBg(ctx,t,col,rgb){
  const W=CW,H=CH;
  // Deep multi-stop background
  const bg=ctx.createRadialGradient(W*.5,H*.15,0,W*.5,H*.65,H*.9);
  bg.addColorStop(0,   `rgba(${rgb},.22)`);
  bg.addColorStop(.35, `rgba(${rgb},.06)`);
  bg.addColorStop(.7,  "#060610");
  bg.addColorStop(1,   "#020208");
  ctx.fillStyle=bg; ctx.fillRect(0,0,W,H);

  // Animated vignette overlay
  const vig=ctx.createRadialGradient(W/2,H/2,H*.2,W/2,H/2,H*.9);
  vig.addColorStop(0,"rgba(0,0,0,0)");
  vig.addColorStop(1,"rgba(0,0,0,.72)");
  ctx.fillStyle=vig; ctx.fillRect(0,0,W,H);

  // Top light leak
  const leak=ctx.createRadialGradient(W*.5,0,0,W*.5,0,W*.8);
  leak.addColorStop(0,`rgba(${rgb},.18)`);
  leak.addColorStop(1,"rgba(0,0,0,0)");
  ctx.fillStyle=leak; ctx.fillRect(0,0,W,H*.45);

  // Subtle horizontal scan line
  const scanY = ((t*38)%H);
  const scan=ctx.createLinearGradient(0,scanY-6,0,scanY+6);
  scan.addColorStop(0,"rgba(255,255,255,0)");
  scan.addColorStop(.5,`rgba(${rgb},.04)`);
  scan.addColorStop(1,"rgba(255,255,255,0)");
  ctx.fillStyle=scan; ctx.fillRect(0,scanY-6,W,12);

  // Grid dots
  ctx.fillStyle=`rgba(${rgb},.07)`;
  const gs=36;
  for(let gx=0;gx<W;gx+=gs) for(let gy=0;gy<H;gy+=gs){
    ctx.beginPath(); ctx.arc(gx,gy,1,0,Math.PI*2); ctx.fill();
  }
}

function wrapLines(ctx,text,maxW){
  const words=text.split(" "); const lines=[]; let cur="";
  for(const w of words){
    const test=cur+(cur?" ":"")+w;
    if(ctx.measureText(test).width>maxW&&cur){ lines.push(cur); cur=w; }
    else cur=test;
  }
  if(cur) lines.push(cur);
  return lines;
}

function drawGlowText(ctx,text,x,y,col,size,weight="900"){
  ctx.save();
  ctx.font=`${weight} ${size}px 'Arial Black',Impact,sans-serif`;
  ctx.textAlign="center";
  // outer glow
  ctx.shadowColor=col; ctx.shadowBlur=32; ctx.fillStyle=col;
  ctx.fillText(text,x,y);
  // mid
  ctx.shadowBlur=12; ctx.fillStyle="#fff"; ctx.fillText(text,x,y);
  // crisp
  ctx.shadowBlur=0; ctx.fillStyle="#fff"; ctx.fillText(text,x,y);
  ctx.restore();
}

function drawFrame(ctx, t, content, niche) {
  const W=CW, H=CH;
  const col = niche?.color || "#22d3ee";
  const rgb = niche?.rgb   || "34,211,238";

  ctx.clearRect(0,0,W,H);

  // ── Background layers ──────────────────────────────────────
  drawBg(ctx,t,col,rgb);
  drawParticles(ctx,t,col,rgb);

  // ── Niche badge (top center) ───────────────────────────────
  const ba = easeOut(clamp((t-.3)*3,0,1));
  if(ba>0){
    ctx.save(); ctx.globalAlpha=ba;
    const badge=`${niche?.emoji||""}  ${(niche?.label||"").toUpperCase()}`;
    ctx.font="600 11px 'Arial',sans-serif";
    const bw=ctx.measureText(badge).width+28;
    // pill bg
    ctx.fillStyle=`rgba(${rgb},.15)`;
    ctx.strokeStyle=`rgba(${rgb},.4)`; ctx.lineWidth=1;
    ctx.beginPath(); ctx.roundRect(W/2-bw/2,14,bw,28,14);
    ctx.fill(); ctx.stroke();
    ctx.fillStyle=col; ctx.textAlign="center";
    ctx.fillText(badge,W/2,33);
    ctx.restore();
  }

  // ── Animated accent line ──────────────────────────────────
  if(t>=.8){
    const lp=easeOut(clamp((t-.8)*2.5,0,1));
    ctx.save(); ctx.globalAlpha=lp;
    const lw=W*.76*lp;
    const grad=ctx.createLinearGradient(W/2-lw/2,0,W/2+lw/2,0);
    grad.addColorStop(0,"transparent");
    grad.addColorStop(.5,col);
    grad.addColorStop(1,"transparent");
    ctx.strokeStyle=grad; ctx.lineWidth=2;
    ctx.shadowColor=col; ctx.shadowBlur=14;
    ctx.beginPath();
    ctx.moveTo(W/2-lw/2, H*.21);
    ctx.lineTo(W/2+lw/2, H*.21);
    ctx.stroke();
    ctx.restore();
  }

  // ── Hook text ─────────────────────────────────────────────
  if(t>=1&&content?.hook){
    const p=easeOut(clamp((t-1)*1.4,0,1));
    const yo=(1-p)*50;
    ctx.save(); ctx.globalAlpha=p; ctx.translate(0,yo);
    ctx.font=`900 ${content.hook.length>32?20:content.hook.length>22?24:28}px 'Arial Black',Impact,sans-serif`;
    ctx.textAlign="center";
    const lines=wrapLines(ctx,content.hook.toUpperCase(),W*.82);
    const lh=36; const startY=H*.255 - ((lines.length-1)*lh)/2;
    lines.forEach((ln,i)=>{
      // shadow pass
      ctx.shadowColor="rgba(0,0,0,.95)"; ctx.shadowBlur=20;
      ctx.fillStyle="rgba(0,0,0,.6)"; ctx.fillText(ln,W/2,startY+i*lh+2);
      // glow pass
      ctx.shadowColor=col; ctx.shadowBlur=28;
      ctx.fillStyle="#fff"; ctx.fillText(ln,W/2,startY+i*lh);
      ctx.shadowBlur=0; ctx.fillText(ln,W/2,startY+i*lh);
    });
    ctx.restore();
  }

  // ── Divider dots ──────────────────────────────────────────
  if(t>=4){
    const dp=easeOut(clamp((t-4)*2,0,1));
    ctx.save(); ctx.globalAlpha=dp*.5;
    [-.06,0,.06].forEach(offset=>{
      ctx.beginPath();
      ctx.arc(W/2+offset*W, H*.39, 2.5, 0, Math.PI*2);
      ctx.fillStyle=col; ctx.fill();
    });
    ctx.restore();
  }

  // ── Tips (staggered fly-in) ───────────────────────────────
  if(content?.tips){
    content.tips.slice(0,3).forEach((tip,i)=>{
      const st=5+i*5.5; if(t<st) return;
      const p=easeOut(clamp((t-st)*1.6,0,1));
      const xo=(1-p)*-55;
      const by=H*.415+i*86;
      ctx.save(); ctx.globalAlpha=p; ctx.translate(xo,0);

      // card background
      ctx.fillStyle=`rgba(${rgb},.055)`;
      ctx.strokeStyle=`rgba(${rgb},.18)`; ctx.lineWidth=1;
      ctx.beginPath(); ctx.roundRect(14,by,W-28,72,10);
      ctx.fill(); ctx.stroke();

      // number badge
      const nbg=ctx.createRadialGradient(44,by+36,0,44,by+36,22);
      nbg.addColorStop(0,`rgba(${rgb},.35)`);
      nbg.addColorStop(1,`rgba(${rgb},.08)`);
      ctx.fillStyle=nbg;
      ctx.beginPath(); ctx.roundRect(22,by+14,44,44,8); ctx.fill();
      ctx.font=`900 22px 'Arial Black',sans-serif`;
      ctx.fillStyle=col; ctx.textAlign="center";
      ctx.shadowColor=col; ctx.shadowBlur=12;
      ctx.fillText(i+1,44,by+43);
      ctx.shadowBlur=0;

      // tip text
      ctx.font="500 13px 'Arial',sans-serif";
      ctx.fillStyle="rgba(255,255,255,.9)";
      ctx.textAlign="left";
      const tlines=wrapLines(ctx,tip,W-100);
      tlines.slice(0,3).forEach((tl,ti)=>{
        ctx.shadowColor="rgba(0,0,0,.8)"; ctx.shadowBlur=8;
        ctx.fillText(tl,76,by+26+ti*20);
        ctx.shadowBlur=0;
      });

      // left accent bar with gradient
      const barG=ctx.createLinearGradient(0,by+14,0,by+58);
      barG.addColorStop(0,col);
      barG.addColorStop(1,`rgba(${rgb},0)`);
      ctx.fillStyle=barG;
      ctx.fillRect(14,by+14,3,44);

      ctx.restore();
    });
  }

  // ── CTA button (premium animated) ────────────────────────
  if(t>=21){
    const p=easeOut(clamp((t-21)*1.4,0,1));
    const bounce=Math.sin((t-21)*5)*Math.max(0,1-(t-21)*.35)*6;
    const pulse=1+Math.sin(t*3)*.03;
    ctx.save(); ctx.globalAlpha=p;
    ctx.translate(W/2, H*.855+bounce);
    ctx.scale(pulse,pulse);

    // glow shadow
    ctx.shadowColor=col; ctx.shadowBlur=30;
    const btnW=W*.78, btnH=50;
    // gradient fill
    const btnG=ctx.createLinearGradient(-btnW/2,0,btnW/2,0);
    btnG.addColorStop(0,`rgba(${rgb},.7)`);
    btnG.addColorStop(.5,col);
    btnG.addColorStop(1,`rgba(${rgb},.7)`);
    ctx.fillStyle=btnG;
    ctx.beginPath(); ctx.roundRect(-btnW/2,-btnH/2,btnW,btnH,btnH/2); ctx.fill();
    ctx.shadowBlur=0;

    // shimmer sweep
    const shimX=((t-21)*80%btnW)-btnW/2;
    const shim=ctx.createLinearGradient(shimX-30,0,shimX+30,0);
    shim.addColorStop(0,"rgba(255,255,255,0)");
    shim.addColorStop(.5,"rgba(255,255,255,.2)");
    shim.addColorStop(1,"rgba(255,255,255,0)");
    ctx.fillStyle=shim;
    ctx.beginPath(); ctx.roundRect(-btnW/2,-btnH/2,btnW,btnH,btnH/2); ctx.fill();

    // button text
    ctx.font="bold 14px 'Arial Black',sans-serif";
    ctx.fillStyle="#000"; ctx.textAlign="center";
    ctx.fillText("FOLLOW FOR MORE  ★",0,5);
    ctx.restore();

    // gift sub-line
    ctx.save(); ctx.globalAlpha=p*.7;
    ctx.font="12px 'Arial',sans-serif";
    ctx.fillStyle="rgba(255,255,255,.55)"; ctx.textAlign="center";
    ctx.fillText("🎁  Send a gift if this helped you!",W/2, H*.855+bounce+38);
    ctx.restore();
  }

  // ── Progress bar (bottom) ─────────────────────────────────
  ctx.save(); ctx.globalAlpha=.35;
  ctx.fillStyle=`rgba(${rgb},.2)`;
  ctx.fillRect(0,H-3,W,3);
  ctx.fillStyle=col;
  ctx.fillRect(0,H-3,(t/REC_S)*W,3);
  ctx.restore();

  // ── Handle notch (top) ───────────────────────────────────
  ctx.save(); ctx.globalAlpha=.25;
  ctx.fillStyle="rgba(255,255,255,.15)";
  ctx.beginPath(); ctx.roundRect(W/2-22,8,44,4,2); ctx.fill();
  ctx.restore();
}

const store = {
  get: k => { try{ return JSON.parse(localStorage.getItem("ia_"+k)||"null"); }catch{ return null; } },
  set: (k,v) => { try{ localStorage.setItem("ia_"+k,JSON.stringify(v)); }catch{} },
};

const pad = n => String(n).padStart(2,"0");
const hhmm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const fmt = d => new Date(d).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});

const inp = {
  background:"#030309",
  border:"1px solid rgba(255,255,255,.08)",
  borderRadius:6,
  padding:"10px 12px",
  fontFamily:"monospace",
  fontSize:12,
  color:"#d0d0e0",
  outline:"none",
  width:"100%",
};

const btn = {
  border:"none",
  borderRadius:8,
  fontFamily:"monospace",
  fontSize:12,
  padding:"10px 18px",
  cursor:"pointer",
  transition:"all .15s",
  display:"inline-flex",
  alignItems:"center",
  justifyContent:"center",
  gap:6,
};

export default function InstaAuto() {
  const [creds,  setCreds]  = useState(() => store.get("creds")  || {igId:"",igToken:"",cloud:"",preset:""});
  const [nicheId,setNicheId]= useState(() => store.get("niche")  || null);
  const [schedIdx,setSchedIdx]=useState(()=>store.get("schedIdx")||0);
  const [setupDone, setSetupDone] = useState(() => store.get("done") || false);
  const [setupStep, setSetupStep] = useState(0);
  const [running,  setRunning]  = useState(false);
  const [content,  setContent]  = useState(null);
  const [status,   setStatus]   = useState("idle");
  const [log,      setLog]      = useState([]);
  const [posts,    setPosts]    = useState(() => store.get("posts") || []);
  const [nextPost, setNextPost] = useState(null);
  const [recPct,   setRecPct]   = useState(0);
  const [showCanvas, setShowCanvas] = useState(false);

  const canvasRef  = useRef(null);
  const animRef    = useRef(null);
  const runningRef = useRef(false);
  const contentRef = useRef(null);

  const niche = NICHES.find(n=>n.id===nicheId);
  const schedule = SCHEDULES[schedIdx]?.times || SCHEDULES[0].times;

  const addLog = useCallback((msg, type="info") => {
    const entry = {msg, type, ts: Date.now()};
    setLog(prev => [...prev.slice(-199), entry]);
  }, []);

  useEffect(() => { store.set("creds",  creds);    }, [creds]);
  useEffect(() => { store.set("niche",  nicheId);  }, [nicheId]);
  useEffect(() => { store.set("schedIdx",schedIdx);}, [schedIdx]);
  useEffect(() => { store.set("done",   setupDone);}, [setupDone]);
  useEffect(() => { store.set("posts",  posts);    }, [posts]);

  useEffect(() => {
    const cvs = canvasRef.current; if(!cvs) return;
    const ctx = cvs.getContext("2d");
    let t0 = Date.now();
    const loop = () => {
      const t = ((Date.now()-t0)/1000)%(REC_S+2);
      drawFrame(ctx, t, contentRef.current, niche);
      animRef.current = requestAnimationFrame(loop);
    };
    animRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animRef.current);
  }, [niche]);

  useEffect(() => {
    const iv = setInterval(() => {
      const now = new Date();
      const nowM = now.getHours()*60+now.getMinutes();
      const slots = schedule.map(t => { const [h,m]=t.split(":").map(Number); return h*60+m; });
      const future = slots.filter(m=>m>nowM);
      const nextM = future.length ? future[0] : slots[0]+1440;
      const diff = nextM-nowM;
      const h=Math.floor(diff/60), m=diff%60;
      setNextPost(`${h}h ${m}m`);
    }, 10000);
    return ()=>clearInterval(iv);
  }, [schedule]);

  useEffect(() => {
    if(!running) return;
    addLog("🤖 Automation started");
    const iv = setInterval(async () => {
      if(!runningRef.current) return;
      const now = hhmm(new Date());
      if(schedule.includes(now)) {
        addLog(`⏰ Trigger at ${now}`);
        await pipeline();
      }
    }, 60_000);
    return () => { clearInterval(iv); addLog("⏸ Paused"); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [running, schedule]);

  useEffect(() => { runningRef.current = running; }, [running]);

  const pipeline = useCallback(async () => {
    const {igId,igToken,cloud,preset} = creds;
    if(!igId||!igToken||!cloud||!preset||!nicheId){
      addLog("❌ Missing credentials","error"); return;
    }
    const nicheObj = NICHES.find(n=>n.id===nicheId);
    setStatus("generating");
    addLog("✦ Generating script…");
    let ct;
    try{
      const res = await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514", max_tokens:800,
          system:"Expert Instagram Reels strategist. Return ONLY valid JSON, no markdown.",
          messages:[{role:"user",content:`Viral reel for "${nicheObj.label}" niche. Return ONLY:
{"hook":"8-word punchy opening","tips":["key point 1 (10 words max)","key point 2","key point 3"],"caption":"250-char Instagram caption with emojis, CTA to follow, CTA for gift","hashtags":"20 hashtags space-separated"}`}]
        })
      });
      const d=await res.json();
      if(d.error) throw new Error(d.error.message);
      const raw=d.content.map(c=>c.text||"").join("").replace(/```json|```/g,"").trim();
      ct=JSON.parse(raw);
      ct.fullCaption=`${ct.caption}\n\n${ct.hashtags}`;
      setContent(ct); contentRef.current=ct;
      addLog(`✓ Script: "${ct.hook}"`, "success");
    }catch(e){ addLog(`❌ Script error: ${e.message}`,"error"); setStatus("error"); return; }

    await new Promise(r=>setTimeout(r,1200));
    setStatus("recording");
    addLog(`🎥 Recording ${REC_S}s…`);
    let blob;
    try{
      blob = await new Promise((resolve,reject)=>{
        const cvs=canvasRef.current;
        if(!cvs) return reject(new Error("Canvas not ready"));
        const stream=cvs.captureStream(30);
        const mime=["video/mp4;codecs=avc1","video/webm;codecs=vp9","video/webm"].find(m=>MediaRecorder.isTypeSupported(m))||"video/webm";
        const rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:2_500_000});
        const chunks=[];
        rec.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data);};
        rec.onstop=()=>resolve(new Blob(chunks,{type:mime}));
        rec.onerror=e=>reject(e.error);
        rec.start(300);
        const t0=Date.now();
        const iv=setInterval(()=>{
          const pct=Math.min(100,((Date.now()-t0)/1000/REC_S)*100);
          setRecPct(pct);
          if(pct>=100){clearInterval(iv);rec.stop();}
        },200);
      });
      addLog(`✓ Recorded ${(blob.size/1024/1024).toFixed(1)}MB`,"success");
    }catch(e){ addLog(`❌ Record error: ${e.message}`,"error"); setStatus("error"); return; }

    setStatus("uploading");
    addLog("☁️ Uploading…");
    let videoUrl;
    try{
      const fd=new FormData();
      fd.append("file",blob,"reel.webm");
      fd.append("upload_preset",preset);
      fd.append("resource_type","video");
      const ur=await fetch(`https://api.cloudinary.com/v1_1/${cloud}/video/upload`,{method:"POST",body:fd});
      if(!ur.ok) throw new Error(`Cloudinary ${ur.status}`);
      const ud=await ur.json();
      videoUrl=ud.secure_url.replace("/upload/","/upload/f_mp4,vc_h264,ac_aac/");
      addLog(`✓ Hosted`,"success");
    }catch(e){ addLog(`❌ Upload error: ${e.message}`,"error"); setStatus("error"); return; }

    setStatus("posting");
    addLog("📤 Posting to Instagram…");
    try{
      const base=`https://graph.facebook.com/v19.0`;
      const c1=await fetch(`${base}/${igId}/media`,{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({media_type:"REELS",video_url:videoUrl,caption:ct.fullCaption,share_to_feed:true,access_token:igToken})});
      const r1=await c1.json();
      if(r1.error) throw new Error(r1.error.message);
      addLog(`📦 Container created — waiting…`);
      for(let i=0;i<24;i++){
        await new Promise(r=>setTimeout(r,5000));
        const sr=await fetch(`${base}/${r1.id}?fields=status_code&access_token=${igToken}`);
        const sd=await sr.json();
        addLog(`   status: ${sd.status_code}`);
        if(sd.status_code==="FINISHED") break;
        if(sd.status_code==="ERROR") throw new Error("IG processing error");
      }
      const c3=await fetch(`${base}/${igId}/media_publish`,{method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({creation_id:r1.id,access_token:igToken})});
      const r3=await c3.json();
      if(r3.error) throw new Error(r3.error.message);
      addLog(`🎉 POSTED! ID: ${r3.id}`,"success");
      setPosts(p=>[{id:r3.id,hook:ct.hook,niche:nicheObj.label,ts:Date.now()},...p.slice(0,29)]);
      setStatus("done");
      setTimeout(()=>setStatus("idle"),4000);
    }catch(e){ addLog(`❌ Post error: ${e.message}`,"error"); setStatus("error"); }
  }, [creds, nicheId, addLog]);

  if(!setupDone){
    const steps = [
      {
        title:"Connect Instagram",
        icon:"📱",
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <p style={{fontSize:13,color:"#666",lineHeight:1.7,margin:0}}>
              Paste your <strong style={{color:"#e0e0e0"}}>Instagram Account ID</strong> and <strong style={{color:"#e0e0e0"}}>Access Token</strong> below.
            </p>
            <label style={{display:"flex",flexDirection:"column",gap:6}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>INSTAGRAM ACCOUNT ID</span>
              <input type="text" placeholder="4260135897573500"
                value={creds.igId}
                onChange={e=>setCreds(p=>({...p,igId:e.target.value}))}
                style={inp}/>
            </label>
            <label style={{display:"flex",flexDirection:"column",gap:6}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>ACCESS TOKEN (60-DAY)</span>
              <input type="password" placeholder="EAAyKCIs…"
                value={creds.igToken}
                onChange={e=>setCreds(p=>({...p,igToken:e.target.value}))}
                style={inp}/>
            </label>
            <div style={{background:"rgba(34,211,238,.06)",border:"1px solid rgba(34,211,238,.15)",borderRadius:8,padding:12,fontSize:11,color:"#888",lineHeight:1.8}}>
              <strong style={{color:"#22d3ee"}}>Your credentials:</strong><br/>
              Account ID: 4260135897573500<br/>
              Token: paste your EAAyKCIs… token
            </div>
          </div>
        ),
        valid: !!creds.igId && !!creds.igToken,
      },
      {
        title:"Connect Cloudinary",
        icon:"☁️",
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            <p style={{fontSize:13,color:"#666",lineHeight:1.7,margin:0}}>
              Paste your <strong style={{color:"#e0e0e0"}}>Cloudinary Cloud Name</strong> and <strong style={{color:"#e0e0e0"}}>Upload Preset</strong>.
            </p>
            <label style={{display:"flex",flexDirection:"column",gap:6}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>CLOUDINARY CLOUD NAME</span>
              <input type="text" placeholder="my-cloud-name"
                value={creds.cloud}
                onChange={e=>setCreds(p=>({...p,cloud:e.target.value}))}
                style={inp}/>
              <span style={{fontSize:11,color:"#444"}}>Found on your Cloudinary dashboard homepage</span>
            </label>
            <label style={{display:"flex",flexDirection:"column",gap:6}}>
              <span style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1}}>UNSIGNED UPLOAD PRESET</span>
              <input type="text" placeholder="instagram_reels"
                value={creds.preset}
                onChange={e=>setCreds(p=>({...p,preset:e.target.value}))}
                style={inp}/>
              <span style={{fontSize:11,color:"#444"}}>Settings → Upload → Upload Presets → your preset name</span>
            </label>
          </div>
        ),
        valid: !!creds.cloud && !!creds.preset,
      },
      {
        title:"Pick Niche & Schedule",
        icon:"🎯",
        content:(
          <div style={{display:"flex",flexDirection:"column",gap:20}}>
            <div>
              <div style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1,marginBottom:10}}>YOUR CONTENT NICHE</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                {NICHES.map(n=>(
                  <button key={n.id} onClick={()=>setNicheId(n.id)}
                    style={{background:nicheId===n.id?`rgba(${n.rgb},.12)`:"#060610",border:`1px solid ${nicheId===n.id?n.color:"rgba(255,255,255,.07)"}`,borderRadius:10,padding:"12px 8px",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:6,transition:"all .15s"}}>
                    <span style={{fontSize:22}}>{n.emoji}</span>
                    <span style={{fontSize:11,color:nicheId===n.id?n.color:"#555"}}>{n.label}</span>
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div style={{fontSize:11,fontFamily:"monospace",color:"#555",letterSpacing:1,marginBottom:10}}>POSTING SCHEDULE</div>
              <div style={{display:"flex",flexDirection:"column",gap:6}}>
                {SCHEDULES.map((s,i)=>(
                  <button key={i} onClick={()=>setSchedIdx(i)}
                    style={{background:schedIdx===i?"rgba(34,211,238,.08)":"#060610",border:`1px solid ${schedIdx===i?"rgba(34,211,238,.4)":"rgba(255,255,255,.07)"}`,borderRadius:8,padding:"11px 14px",cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center",transition:"all .15s"}}>
                    <span style={{fontSize:13,color:schedIdx===i?"#22d3ee":"#777"}}>{s.label}</span>
                    <span style={{fontSize:11,fontFamily:"monospace",color:schedIdx===i?"#22d3ee":"#444"}}>{s.times.join(" · ")}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        ),
        valid: !!nicheId,
      },
    ];

    const step = steps[setupStep];
    const isLast = setupStep === steps.length-1;

    return (
      <div style={{minHeight:"100vh",background:"#03030b",display:"flex",alignItems:"center",justifyContent:"center",padding:20,fontFamily:"monospace"}}>
        <div style={{width:"100%",maxWidth:520}}>
          <div style={{textAlign:"center",marginBottom:32}}>
            <div style={{fontSize:28,fontWeight:900,letterSpacing:3,background:"linear-gradient(135deg,#22d3ee,#a78bfa,#f472b6)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",marginBottom:4}}>INSTAUTO</div>
            <div style={{fontSize:11,color:"#333",letterSpacing:2}}>AI REELS AUTOMATION</div>
          </div>
          <div style={{display:"flex",gap:6,marginBottom:28,justifyContent:"center"}}>
            {steps.map((_,i)=>(
              <div key={i} style={{height:3,flex:1,borderRadius:2,background:i<=setupStep?"#22d3ee":"rgba(255,255,255,.08)",transition:"background .3s"}}/>
            ))}
          </div>
          <div style={{background:"#070712",border:"1px solid rgba(255,255,255,.07)",borderRadius:16,padding:"28px 28px 24px",marginBottom:14}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:22}}>
              <div style={{width:36,height:36,background:"rgba(34,211,238,.1)",borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>{step.icon}</div>
              <div>
                <div style={{fontSize:11,color:"#333",letterSpacing:1,marginBottom:2}}>STEP {setupStep+1} OF {steps.length}</div>
                <div style={{fontSize:15,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif"}}>{step.title}</div>
              </div>
            </div>
            {step.content}
          </div>
          <div style={{display:"flex",gap:10}}>
            {setupStep>0 && (
              <button onClick={()=>setSetupStep(p=>p-1)} style={{...btn,background:"rgba(255,255,255,.05)",color:"#666",border:"1px solid rgba(255,255,255,.08)",flex:"0 0 auto",width:44}}>←</button>
            )}
            <button disabled={!step.valid}
              onClick={()=>{ if(isLast){ store.set("done",true); setSetupDone(true); } else setSetupStep(p=>p+1); }}
              style={{...btn,flex:1,background:step.valid?"#22d3ee":"rgba(255,255,255,.05)",color:step.valid?"#000":"#333",cursor:step.valid?"pointer":"not-allowed"}}>
              {isLast ? "🚀 Launch Automation" : "Continue →"}
            </button>
          </div>
          <div style={{textAlign:"center",marginTop:14,fontSize:11,color:"#222"}}>Credentials saved locally in your browser only</div>
        </div>
      </div>
    );
  }

  const statusInfo = {
    idle:       {label:"Standing by",           color:"#444",   dot:"#333"   },
    generating: {label:"Generating script…",    color:"#a78bfa",dot:"#a78bfa"},
    recording:  {label:`Recording… ${Math.round(recPct)}%`, color:"#fb923c",dot:"#fb923c"},
    uploading:  {label:"Uploading video…",      color:"#22d3ee",dot:"#22d3ee"},
    posting:    {label:"Posting to Instagram…", color:"#22d3ee",dot:"#22d3ee"},
    done:       {label:"✓ Posted!",             color:"#4ade80",dot:"#4ade80"},
    error:      {label:"Error — check log",     color:"#f87171",dot:"#f87171"},
  }[status] || {label:"—",color:"#444",dot:"#333"};

  return (
    <div style={{minHeight:"100vh",background:"#03030b",color:"#d0d0e0",fontFamily:"monospace",display:"flex",flexDirection:"column"}}>
      <style>{`
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:#111;border-radius:2px}
        input:focus{outline:none;border-color:rgba(34,211,238,.4)!important}
        input::placeholder{color:#1e1e2e}
        button:disabled{opacity:.4;cursor:not-allowed!important}
      `}</style>

      <div style={{background:"#050510",borderBottom:"1px solid rgba(255,255,255,.05)",padding:"14px 20px",display:"flex",alignItems:"center",gap:16,position:"sticky",top:0,zIndex:100}}>
        <div style={{fontSize:16,fontWeight:900,letterSpacing:3,background:"linear-gradient(135deg,#22d3ee,#a78bfa)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>INSTAUTO</div>
        <div style={{fontSize:11,color:niche?.color||"#444",background:`rgba(${niche?.rgb||"100,100,100"},.1)`,border:`1px solid rgba(${niche?.rgb||"100,100,100"},.2)`,padding:"3px 10px",borderRadius:20}}>
          {niche?.emoji} {niche?.label}
        </div>
        <div style={{display:"flex",alignItems:"center",gap:7,marginLeft:"auto"}}>
          <div style={{width:7,height:7,borderRadius:"50%",background:statusInfo.dot,boxShadow:`0 0 8px ${statusInfo.dot}`,animation:status!=="idle"&&status!=="done"?"pulse 1s infinite":"none"}}/>
          <span style={{fontSize:12,color:statusInfo.color}}>{statusInfo.label}</span>
        </div>
        <button onClick={()=>{setSetupDone(false);setSetupStep(0);store.set("done",false);}}
          style={{...btn,padding:"5px 10px",fontSize:11,color:"#333",background:"none",border:"1px solid rgba(255,255,255,.06)"}}>
          ⚙ Setup
        </button>
      </div>

      <div style={{flex:1,display:"grid",gridTemplateColumns:"1fr 300px",gap:0,overflow:"hidden"}}>
        <div style={{padding:20,overflowY:"auto",borderRight:"1px solid rgba(255,255,255,.04)"}}>

          <div style={{background:"#070712",border:`1px solid ${running?"rgba(34,211,238,.25)":"rgba(255,255,255,.07)"}`,borderRadius:16,padding:24,marginBottom:16,transition:"border-color .3s"}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:running?16:0}}>
              <div>
                <div style={{fontSize:15,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif",marginBottom:4}}>
                  {running?"Automation is running":"Automation is paused"}
                </div>
                <div style={{fontSize:12,color:"#444"}}>
                  {running?`Next post in ${nextPost||"calculating…"}`:`${SCHEDULES[schedIdx].label} · ${schedule.join(" · ")}`}
                </div>
              </div>
              <button onClick={()=>setRunning(p=>!p)}
                style={{width:64,height:34,borderRadius:17,background:running?"#22d3ee":"rgba(255,255,255,.06)",border:`1px solid ${running?"#22d3ee":"rgba(255,255,255,.1)"}`,cursor:"pointer",position:"relative",transition:"all .25s",flexShrink:0}}>
                <div style={{position:"absolute",top:3,left:running?31:3,width:26,height:26,background:running?"#000":"#333",borderRadius:"50%",transition:"left .25s,background .25s"}}/>
              </button>
            </div>
            {running && (
              <div style={{display:"flex",gap:8,alignItems:"center",paddingTop:16,borderTop:"1px solid rgba(255,255,255,.05)"}}>
                <div style={{flex:1,height:4,background:"rgba(255,255,255,.05)",borderRadius:2,overflow:"hidden"}}>
                  {status==="recording"&&(
                    <div style={{height:"100%",width:`${recPct}%`,background:"linear-gradient(90deg,#22d3ee,#a78bfa)",borderRadius:2,transition:"width .2s"}}/>
                  )}
                </div>
                <button onClick={pipeline} disabled={status!=="idle"&&status!=="done"&&status!=="error"}
                  style={{...btn,padding:"6px 14px",fontSize:11,background:"rgba(34,211,238,.1)",color:"#22d3ee",border:"1px solid rgba(34,211,238,.2)"}}>
                  ▶ Post Now
                </button>
              </div>
            )}
          </div>

          <div style={{marginBottom:16}}>
            <button onClick={()=>setShowCanvas(p=>!p)}
              style={{...btn,width:"100%",justifyContent:"space-between",background:"#070712",border:"1px solid rgba(255,255,255,.06)",color:"#555",fontSize:12,padding:"10px 16px"}}>
              <span>🎬 Live Reel Preview</span>
              <span>{showCanvas?"▲ Hide":"▼ Show"}</span>
            </button>
            {showCanvas&&(
              <div style={{marginTop:10,display:"flex",justifyContent:"center",background:"#000",borderRadius:10,overflow:"hidden",border:"1px solid rgba(255,255,255,.06)"}}>
                <canvas ref={canvasRef} width={CW} height={CH} style={{display:"block",width:"100%",maxWidth:260}}/>
              </div>
            )}
            {!showCanvas&&<canvas ref={canvasRef} width={CW} height={CH} style={{display:"none"}}/>}
          </div>

          <div style={{background:"#070712",border:"1px solid rgba(255,255,255,.06)",borderRadius:12,padding:18}}>
            <div style={{fontSize:11,color:"#333",letterSpacing:1,marginBottom:12}}>HOW IT WORKS</div>
            {[
              ["🤖","Claude AI writes script","Fresh hook, tips, caption, hashtags — unique every time"],
              ["🎬","Canvas records video","30s animated reel created from the script automatically"],
              ["☁️","Cloudinary hosts it","Uploaded and transcoded to MP4 with a public URL"],
              ["📤","Instagram API posts it","Published as a Reel with caption to your account"],
              ["⏰","Runs on schedule",`Posts at ${schedule.join(", ")} — no action needed`],
            ].map(([icon,title,desc],i)=>(
              <div key={i} style={{display:"flex",gap:12,marginBottom:i<4?14:0,paddingBottom:i<4?14:0,borderBottom:i<4?"1px solid rgba(255,255,255,.04)":"none"}}>
                <div style={{fontSize:18,flexShrink:0,marginTop:1}}>{icon}</div>
                <div>
                  <div style={{fontSize:12,color:"#c0c0d0",fontWeight:600,fontFamily:"sans-serif",marginBottom:2}}>{title}</div>
                  <div style={{fontSize:11,color:"#444",lineHeight:1.6}}>{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>
          <div style={{padding:"16px 16px 8px",borderBottom:"1px solid rgba(255,255,255,.04)"}}>
            <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:10}}>POSTED REELS ({posts.length})</div>
            {posts.length===0?(
              <div style={{fontSize:12,color:"#222",textAlign:"center",padding:"20px 0"}}>No posts yet</div>
            ):(
              <div style={{display:"flex",flexDirection:"column",gap:6,maxHeight:180,overflowY:"auto"}}>
                {posts.map((p,i)=>(
                  <div key={i} style={{display:"flex",gap:8,alignItems:"center",padding:"8px 10px",background:"rgba(74,222,128,.05)",border:"1px solid rgba(74,222,128,.1)",borderRadius:7}}>
                    <div style={{width:6,height:6,borderRadius:"50%",background:"#4ade80",flexShrink:0}}/>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:11,color:"#c0c0d0",whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{p.hook}</div>
                      <div style={{fontSize:10,color:"#333"}}>{p.niche} · {fmt(p.ts)}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div style={{flex:1,overflow:"hidden",display:"flex",flexDirection:"column",padding:"12px 16px 16px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div style={{fontSize:10,color:"#333",letterSpacing:1}}>ACTIVITY LOG</div>
              <button onClick={()=>setLog([])} style={{...btn,padding:"2px 8px",fontSize:10,color:"#333",background:"none",border:"1px solid rgba(255,255,255,.05)"}}>Clear</button>
            </div>
            <div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:3,fontSize:11}}>
              {log.length===0?<span style={{color:"#222"}}>Waiting…</span>
                :[...log].reverse().map((l,i)=>(
                  <div key={i} style={{display:"flex",gap:7}}>
                    <span style={{color:"#222",flexShrink:0,fontSize:10}}>{fmt(l.ts)}</span>
                    <span style={{color:l.type==="success"?"#4ade80":l.type==="error"?"#f87171":"#555",lineHeight:1.5}}>{l.msg}</span>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
