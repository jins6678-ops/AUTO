import { useState, useEffect, useRef, useCallback } from "react";

/* ═══════════════════════════════════════════════════════════
   INSTAUTO CINEMA — Pollinations.AI + Ken Burns Edition
   Claude → FLUX images → Cinematic animation → Instagram
═══════════════════════════════════════════════════════════ */

const CW = 405, CH = 720, REC_S = 32;
const SCENE_DUR = 8; // seconds per scene
const N_SCENES  = 4;

const NICHES = [
  { id:"brain",      label:"Psychology",   emoji:"🧠", col:"#7c3aed", rgb:"124,58,237",  bg:"#0a0212" },
  { id:"finance",    label:"Finance",      emoji:"💰", col:"#d97706", rgb:"217,119,6",   bg:"#0d0a00" },
  { id:"tech",       label:"AI & Tech",    emoji:"🤖", col:"#0891b2", rgb:"8,145,178",   bg:"#00080d" },
  { id:"motivation", label:"Mindset",      emoji:"🔥", col:"#dc2626", rgb:"220,38,38",   bg:"#0d0000" },
  { id:"business",   label:"Business",     emoji:"📈", col:"#059669", rgb:"5,150,105",   bg:"#000d06" },
  { id:"science",    label:"Science",      emoji:"⚛️",  col:"#6366f1", rgb:"99,102,241",  bg:"#02020d" },
];

const SCHEDULES = [
  { label:"3× Daily (Recommended)", times:["09:00","13:00","19:00"] },
  { label:"2× Daily",               times:["09:00","19:00"]         },
  { label:"Morning Only",           times:["09:00"]                  },
];

// Ken Burns motion per scene
const KB = [
  { s0:1.00, s1:1.18, x0:0.00,  y0:0.00,  x1:0.05,  y1:0.02  }, // slow zoom in + drift
  { s0:1.20, s1:1.00, x0:0.08,  y0:0.04,  x1:0.00,  y1:0.00  }, // zoom out reveal
  { s0:1.05, s1:1.15, x0:-0.05, y0:0.03,  x1:0.00,  y1:-0.02 }, // drift left + rise
  { s0:1.00, s1:1.22, x0:0.00,  y0:-0.05, x1:0.06,  y1:0.00  }, // dramatic push in
];

/* ── Math ── */
const lerp    = (a,b,t) => a+(b-a)*t;
const clamp   = (v,a,b) => Math.min(b,Math.max(a,v));
const easeIO  = t => t<.5?2*t*t:-1+(4-2*t)*t;
const easeOut = t => 1-Math.pow(clamp(1-t,0,1),3);

/* ── Film grain (pre-generated frames) ── */
const GRAIN_FRAMES = [];
function buildGrain(){
  for(let f=0;f<6;f++){
    const c=document.createElement("canvas");
    c.width=CW; c.height=CH;
    const ctx=c.getContext("2d");
    const d=ctx.createImageData(CW,CH);
    for(let i=0;i<d.data.length;i+=4){
      const v=Math.random()*255|0;
      d.data[i]=v; d.data[i+1]=v; d.data[i+2]=v;
      d.data[i+3]=Math.random()*22|0;
    }
    ctx.putImageData(d,0,0);
    GRAIN_FRAMES.push(c);
  }
}

/* ── Canvas cinematic renderer ── */
function drawCinema(ctx, t, imgs, content, niche, grainFrame){
  const W=CW,H=CH;
  const scene   = Math.min(Math.floor(t/SCENE_DUR), N_SCENES-1);
  const sceneT  = t - scene*SCENE_DUR;
  const sceneP  = clamp(sceneT/SCENE_DUR, 0, 1);

  ctx.clearRect(0,0,W,H);

  /* ── 1. BG fallback ── */
  ctx.fillStyle = niche?.bg || "#000";
  ctx.fillRect(0,0,W,H);

  /* ── 2. Ken Burns image ── */
  const img = imgs?.[scene];
  if(img?.complete && img.naturalWidth>0){
    const kb = KB[scene];
    const scale = lerp(kb.s0, kb.s1, easeIO(sceneP));
    const offX  = lerp(kb.x0, kb.x1, easeIO(sceneP))*W;
    const offY  = lerp(kb.y0, kb.y1, easeIO(sceneP))*H;
    const sw    = W/scale, sh=H/scale;
    const sx    = clamp((W-sw)/2-offX, 0, img.naturalWidth-sw  > 0 ? img.naturalWidth-sw  : 0);
    const sy    = clamp((H-sh)/2-offY, 0, img.naturalHeight-sh > 0 ? img.naturalHeight-sh : 0);
    ctx.drawImage(img, sx, sy, sw, sh, 0, 0, W, H);
  } else {
    /* Cinematic loading bg */
    const grd=ctx.createRadialGradient(W/2,H*.3,0,W/2,H/2,H*.8);
    grd.addColorStop(0,`rgba(${niche?.rgb||"50,50,50"},.35)`);
    grd.addColorStop(1,"#000");
    ctx.fillStyle=grd; ctx.fillRect(0,0,W,H);
    // Loading pulse ring
    ctx.save();
    ctx.globalAlpha=0.3+Math.sin(t*3)*0.2;
    ctx.strokeStyle=niche?.col||"#fff";
    ctx.lineWidth=1.5;
    ctx.beginPath();
    ctx.arc(W/2,H*.42,40+Math.sin(t*2)*8,0,Math.PI*2);
    ctx.stroke();
    ctx.restore();
  }

  /* ── 3. Cinematic vignette ── */
  const vig=ctx.createRadialGradient(W/2,H/2,H*.15,W/2,H/2,H*.85);
  vig.addColorStop(0,"rgba(0,0,0,0)");
  vig.addColorStop(.65,"rgba(0,0,0,.35)");
  vig.addColorStop(1,"rgba(0,0,0,.88)");
  ctx.fillStyle=vig; ctx.fillRect(0,0,W,H);

  /* ── 4. Colored tint overlay ── */
  ctx.fillStyle=`rgba(${niche?.rgb||"50,50,50"},.08)`;
  ctx.fillRect(0,0,W,H);

  /* ── 5. Scene transition flash ── */
  if(scene>0 && sceneT<0.35){
    const fa=Math.max(0,0.7-(sceneT/0.35)*0.7);
    ctx.fillStyle=`rgba(255,255,255,${fa})`;
    ctx.fillRect(0,0,W,H);
  }

  /* ── 6. Film grain ── */
  if(grainFrame){
    ctx.save();
    ctx.globalAlpha=0.045;
    ctx.globalCompositeOperation="screen";
    ctx.drawImage(grainFrame,0,0,W,H);
    ctx.restore();
  }

  /* ── 7. Cinematic letterbox bars ── */
  const barH = H*0.065;
  ctx.fillStyle="#000";
  ctx.fillRect(0,0,W,barH);
  ctx.fillRect(0,H-barH,W,barH);

  /* ── 8. Niche tag (top bar) ── */
  ctx.save();
  ctx.font=`500 11px 'Courier New',monospace`;
  ctx.fillStyle="rgba(255,255,255,0.55)";
  ctx.textAlign="left";
  ctx.fillText(`${niche?.emoji||""} ${(niche?.label||"").toUpperCase()}`, 16, barH*.65);
  // scene indicator
  ctx.textAlign="right";
  ctx.fillText(`${scene+1} / ${N_SCENES}`, W-16, barH*.65);
  ctx.restore();

  /* ── 9. Hook text (scene 0 only) ── */
  if(scene===0 && content?.hook && sceneT>1.2){
    const p = easeOut(clamp((sceneT-1.2)*1.5,0,1));
    const yo = (1-p)*30;
    ctx.save(); ctx.globalAlpha=p; ctx.translate(0,yo);
    const hook = content.hook.toUpperCase();
    const fs   = hook.length>30?20:hook.length>22?24:28;
    ctx.font=`900 ${fs}px 'Arial Black',Impact,sans-serif`;
    ctx.textAlign="center";
    // measure for bg
    const words=hook.split(" ");
    const lines=[]; let cur="";
    for(const w of words){
      const t2=cur+(cur?" ":"")+w;
      if(ctx.measureText(t2).width>W*.82&&cur){lines.push(cur);cur=w;}else cur=t2;
    }
    lines.push(cur);
    const lh=fs*1.25, totalH=lines.length*lh+24;
    const ty=H*.22;
    // frosted bg
    ctx.fillStyle="rgba(0,0,0,.72)";
    ctx.beginPath(); ctx.roundRect(W*.06,ty-lh,W*.88,totalH,8); ctx.fill();
    // accent top bar
    ctx.fillStyle=niche?.col||"#fff";
    ctx.fillRect(W*.06,ty-lh,W*.88,3);
    // text glow
    ctx.shadowColor=niche?.col||"#fff"; ctx.shadowBlur=20;
    ctx.fillStyle="#fff";
    lines.forEach((ln,i)=>ctx.fillText(ln,W/2,ty+i*lh));
    ctx.restore();
  }

  /* ── 10. Bottom subtitle bar ── */
  if(content?.scenes){
    const sc=content.scenes[Math.min(scene,content.scenes.length-1)];
    const subP=easeOut(clamp(sceneT*2,0,1));
    if(sc && subP>0){
      ctx.save(); ctx.globalAlpha=subP;
      const sbY=H-barH-100;
      // sub bg gradient
      const sbg=ctx.createLinearGradient(0,sbY-20,0,H-barH);
      sbg.addColorStop(0,"rgba(0,0,0,0)");
      sbg.addColorStop(.4,"rgba(0,0,0,.92)");
      sbg.addColorStop(1,"rgba(0,0,0,.98)");
      ctx.fillStyle=sbg; ctx.fillRect(0,sbY-20,W,120);
      // title line
      ctx.font=`900 17px 'Arial Black',sans-serif`;
      ctx.textAlign="center";
      ctx.shadowColor=niche?.col||"#fff"; ctx.shadowBlur=16;
      ctx.fillStyle="#fff";
      ctx.fillText(sc.title?.toUpperCase()||"",W/2,H-barH-72);
      // body line
      ctx.shadowBlur=0;
      ctx.font=`400 13px 'Arial',sans-serif`;
      ctx.fillStyle="rgba(255,255,255,.8)";
      ctx.fillText(sc.sub||"",W/2,H-barH-48);
      // accent dot row
      ctx.fillStyle=niche?.col||"#fff";
      for(let d=0;d<N_SCENES;d++){
        ctx.globalAlpha=d===scene?subP:subP*0.3;
        ctx.beginPath();
        ctx.arc(W/2+(d-1.5)*13,H-barH-20,d===scene?4:2.5,0,Math.PI*2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  /* ── 11. CTA (last scene) ── */
  if(scene===N_SCENES-1 && sceneT>2){
    const p=easeOut(clamp((sceneT-2)*1.2,0,1));
    const pulse=1+Math.sin(t*4)*.025;
    ctx.save(); ctx.globalAlpha=p;
    ctx.translate(W/2,H-barH-135);
    ctx.scale(pulse,pulse);
    const bw=W*.75,bh=44;
    ctx.shadowColor=niche?.col||"#fff"; ctx.shadowBlur=28;
    const bg=ctx.createLinearGradient(-bw/2,0,bw/2,0);
    bg.addColorStop(0,`rgba(${niche?.rgb||"99,99,99"},.7)`);
    bg.addColorStop(.5,niche?.col||"#fff");
    bg.addColorStop(1,`rgba(${niche?.rgb||"99,99,99"},.7)`);
    ctx.fillStyle=bg;
    ctx.beginPath(); ctx.roundRect(-bw/2,-bh/2,bw,bh,bh/2); ctx.fill();
    ctx.shadowBlur=0;
    ctx.font=`bold 13px 'Arial Black',sans-serif`;
    ctx.fillStyle="#000"; ctx.textAlign="center";
    ctx.fillText("FOLLOW FOR MORE  ✦",0,5);
    ctx.restore();
    ctx.save(); ctx.globalAlpha=p*.65;
    ctx.font=`12px 'Arial',sans-serif`;
    ctx.fillStyle="rgba(255,255,255,.55)"; ctx.textAlign="center";
    ctx.fillText("🎁 Send a gift if this helped you!",W/2,H-barH-95);
    ctx.restore();
  }

  /* ── 12. Progress bar (inside top bar) ── */
  const totalP=t/(REC_S);
  ctx.fillStyle=`rgba(255,255,255,.12)`; ctx.fillRect(0,barH-2,W,2);
  const pg=ctx.createLinearGradient(0,0,totalP*W,0);
  pg.addColorStop(0,niche?.col||"#fff"); pg.addColorStop(1,"#fff");
  ctx.fillStyle=pg; ctx.fillRect(0,barH-2,totalP*W,2);
}

/* ── Ambient cinematic audio ── */
function createAmbientAudio(niche){
  try{
    const actx = new (window.AudioContext||window.webkitAudioContext)();
    const master = actx.createGain();
    master.gain.value = 0.18;
    const dest = actx.createMediaStreamDestination();
    master.connect(dest);

    // Deep bass drone
    const bass=actx.createOscillator();
    bass.type="sine"; bass.frequency.value=55;
    const bassG=actx.createGain(); bassG.gain.value=0.6;
    bass.connect(bassG); bassG.connect(master);

    // Mid harmonic
    const mid=actx.createOscillator();
    mid.type="triangle"; mid.frequency.value=110;
    const midG=actx.createGain(); midG.gain.value=0.25;
    mid.connect(midG); midG.connect(master);

    // High shimmer
    const hi=actx.createOscillator();
    hi.type="sine"; hi.frequency.value=330;
    const hiG=actx.createGain(); hiG.gain.value=0.08;
    hi.connect(hiG); hiG.connect(master);

    // LFO on bass
    const lfo=actx.createOscillator();
    lfo.type="sine"; lfo.frequency.value=0.15;
    const lfoG=actx.createGain(); lfoG.gain.value=4;
    lfo.connect(lfoG); lfoG.connect(bass.frequency);

    // Fade in
    master.gain.setValueAtTime(0,actx.currentTime);
    master.gain.linearRampToValueAtTime(0.18,actx.currentTime+2);

    bass.start(); mid.start(); hi.start(); lfo.start();

    return { actx, dest, stop:()=>{ try{ bass.stop();mid.stop();hi.stop();lfo.stop();actx.close(); }catch{} } };
  }catch{ return null; }
}

/* ── Pollinations image URL builder ── */
function pollinationsUrl(prompt, scene, seed){
  const p = encodeURIComponent(prompt);
  return `https://image.pollinations.ai/prompt/${p}?width=${CW}&height=${CH}&model=flux&nologo=true&enhance=true&seed=${seed+scene*7}&private=false`;
}

/* ── Load image with timeout ── */
function loadImage(url){
  return new Promise((res,rej)=>{
    const img=new Image();
    img.crossOrigin="anonymous";
    const to=setTimeout(()=>rej(new Error("timeout")),25000);
    img.onload=()=>{ clearTimeout(to); res(img); };
    img.onerror=()=>{ clearTimeout(to); rej(new Error("load fail")); };
    img.src=url;
  });
}

/* ── Storage ── */
const S={
  get:k=>{try{return JSON.parse(localStorage.getItem("ic_"+k)||"null")}catch{return null}},
  set:(k,v)=>{try{localStorage.setItem("ic_"+k,JSON.stringify(v))}catch{}}
};
const pad=n=>String(n).padStart(2,"0");
const hhmm=d=>`${pad(d.getHours())}:${pad(d.getMinutes())}`;
const fmt=d=>new Date(d).toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});

/* ══════════════════════════════════════════════════════════
   MAIN APP
══════════════════════════════════════════════════════════ */
export default function InstaAutoCinema(){
  const [creds,     setCreds]    = useState(()=>S.get("creds")||{igId:"",igToken:"",cloud:"",preset:""});
  const [nicheId,   setNicheId]  = useState(()=>S.get("niche")||null);
  const [schedIdx,  setSchedIdx] = useState(()=>S.get("si")||0);
  const [setupDone, setSetupDone]= useState(()=>S.get("done")||false);
  const [setupStep, setSetupStep]= useState(0);

  const [running,   setRunning]  = useState(false);
  const [status,    setStatus]   = useState("idle");
  const [log,       setLog]      = useState([]);
  const [posts,     setPosts]    = useState(()=>S.get("posts")||[]);
  const [nextPost,  setNextPost] = useState(null);
  const [recPct,    setRecPct]   = useState(0);
  const [content,   setContent]  = useState(null);
  const [imgs,      setImgs]     = useState([]);
  const [imgStatus, setImgStatus]= useState([]); // "loading"|"ready"|"error" per scene
  const [showPrev,  setShowPrev] = useState(true);

  const canvasRef  = useRef(null);
  const animRef    = useRef(null);
  const runRef     = useRef(false);
  const contentRef = useRef(null);
  const imgsRef    = useRef([]);
  const grainRef   = useRef([]);

  const niche    = NICHES.find(n=>n.id===nicheId);
  const schedule = SCHEDULES[schedIdx]?.times||SCHEDULES[0].times;

  const addLog=useCallback((msg,type="info")=>{
    setLog(p=>[...p.slice(-299),{msg,type,ts:Date.now()}]);
  },[]);

  // Persist
  useEffect(()=>{S.set("creds",creds)},[creds]);
  useEffect(()=>{S.set("niche",nicheId)},[nicheId]);
  useEffect(()=>{S.set("si",schedIdx)},[schedIdx]);
  useEffect(()=>{S.set("done",setupDone)},[setupDone]);
  useEffect(()=>{S.set("posts",posts)},[posts]);

  // Build grain on mount
  useEffect(()=>{ if(GRAIN_FRAMES.length===0) buildGrain(); grainRef.current=GRAIN_FRAMES; },[]);

  // Canvas animation loop
  useEffect(()=>{
    const cvs=canvasRef.current; if(!cvs)return;
    const ctx=cvs.getContext("2d");
    let t0=Date.now(), frame=0;
    const loop=()=>{
      const t=((Date.now()-t0)/1000)%(REC_S+1);
      const gf=grainRef.current[frame%grainRef.current.length]||null;
      frame++;
      drawCinema(ctx,t,imgsRef.current,contentRef.current,niche,gf);
      animRef.current=requestAnimationFrame(loop);
    };
    animRef.current=requestAnimationFrame(loop);
    return()=>cancelAnimationFrame(animRef.current);
  },[niche]);

  // Sync refs
  useEffect(()=>{ imgsRef.current=imgs; },[imgs]);

  // Next post countdown
  useEffect(()=>{
    const iv=setInterval(()=>{
      const now=new Date(), nowM=now.getHours()*60+now.getMinutes();
      const slots=schedule.map(t=>{const[h,m]=t.split(":").map(Number);return h*60+m;});
      const future=slots.filter(m=>m>nowM);
      const nextM=future.length?future[0]:slots[0]+1440;
      const diff=nextM-nowM;
      setNextPost(`${Math.floor(diff/60)}h ${diff%60}m`);
    },15000);
    return()=>clearInterval(iv);
  },[schedule]);

  // Scheduler
  useEffect(()=>{
    if(!running)return;
    addLog("🎬 Cinema automation started");
    const iv=setInterval(async()=>{
      if(!runRef.current)return;
      if(schedule.includes(hhmm(new Date()))){
        addLog(`⏰ Scheduled trigger`);
        await pipeline();
      }
    },60_000);
    return()=>{clearInterval(iv);addLog("⏸ Paused")};
  // eslint-disable-next-line
  },[running,schedule]);
  useEffect(()=>{runRef.current=running},[running]);

  /* ── Generate content via Claude ──────────────────────── */
  const generateContent=useCallback(async()=>{
    if(!nicheId)return null;
    const n=NICHES.find(x=>x.id===nicheId);
    setStatus("generating"); setContent(null); contentRef.current=null;
    setImgs([]); imgsRef.current=[]; setImgStatus([]);
    addLog("✦ Claude writing cinematic story…");
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          model:"claude-sonnet-4-20250514",max_tokens:1200,
          system:`You are an expert viral content strategist and cinematic storyteller. 
You create content for the "${n.label}" niche that makes people STOP scrolling.
Return ONLY valid JSON — no markdown, no extra text, no code fences.`,
          messages:[{role:"user",content:`Create a cinematic viral Instagram Reel story for the "${n.label}" niche.
The story must have a clear emotional arc: Curiosity → Tension → Revelation → Transformation.
Each scene needs a cinematic FLUX AI image prompt that creates stunning visuals.

Return ONLY this exact JSON:
{
  "hook": "Most compelling 8-word hook question or statement that stops scrolling",
  "voiceover": "Full 28-second spoken script. Dramatic. Emotional. First person. About 75 words. Written to be spoken aloud with pauses.",
  "scenes": [
    {
      "id": 0,
      "title": "3-4 word scene title ALL CAPS",
      "sub": "One compelling sentence that creates curiosity (max 10 words)",
      "imagePrompt": "Cinematic ultra-detailed FLUX prompt: glowing holographic [subject], dramatic lighting, deep dark background, neon [color] energy, 8K quality, photorealistic, cinematic composition, volumetric light, particle effects"
    },
    {
      "id": 1,
      "title": "3-4 word scene title ALL CAPS",
      "sub": "One sentence that deepens the tension or problem (max 10 words)",
      "imagePrompt": "Cinematic ultra-detailed FLUX prompt: [different angle/subject], dramatic shadows, atmospheric depth, [color palette], hyperrealistic, film grain aesthetic, professional photography"
    },
    {
      "id": 2,
      "title": "3-4 word scene title ALL CAPS",
      "sub": "The revelation or insight (max 10 words)",
      "imagePrompt": "Cinematic ultra-detailed FLUX prompt: [revelation visual], bright discovery energy, [niche colors], epic scale, ultra detailed, award winning photography, god rays, ethereal"
    },
    {
      "id": 3,
      "title": "3-4 word scene title ALL CAPS",
      "sub": "The transformation or result (max 10 words)",
      "imagePrompt": "Cinematic ultra-detailed FLUX prompt: [transformation visual], triumphant lighting, [niche colors], cinematic golden hour, photorealistic, stunning composition, inspirational"
    }
  ],
  "caption": "Full Instagram caption. Emotional opener. 3 value bullets. Question CTA. Gift CTA. 250 chars max.",
  "hashtags": "25 strategic hashtags — mix viral + niche + mid-tier. Space separated."
}`}]
        })
      });
      const d=await res.json();
      if(d.error)throw new Error(d.error.message);
      const raw=d.content.map(c=>c.text||"").join("").replace(/```json|```/g,"").trim();
      const ct=JSON.parse(raw);
      ct.fullCaption=`${ct.caption}\n\n${ct.hashtags}`;
      setContent(ct); contentRef.current=ct;
      addLog(`✓ Story: "${ct.hook}"`,"success");
      // Speak voiceover preview
      if(ct.voiceover && window.speechSynthesis){
        setTimeout(()=>{
          window.speechSynthesis.cancel();
          const u=new SpeechSynthesisUtterance(ct.voiceover);
          u.rate=0.92; u.pitch=1.02; u.volume=0.8;
          const vs=window.speechSynthesis.getVoices();
          const v=vs.find(x=>x.name.includes("Google")&&x.lang.startsWith("en"))||vs.find(x=>x.lang.startsWith("en"));
          if(v)u.voice=v;
          window.speechSynthesis.speak(u);
        },600);
      }
      return ct;
    }catch(e){
      addLog(`❌ Story failed: ${e.message}`,"error");
      setStatus("error"); return null;
    }
  },[nicheId,addLog]);

  /* ── Load Pollinations images — sequential + 3-attempt retry ── */
  const loadImages=useCallback(async(ct)=>{
    if(!ct?.scenes)return false;
    setStatus("imaging");
    addLog("🎨 Generating cinematic images via Pollinations.AI…");
    const seed=Date.now()%99999;
    const newImgs=new Array(N_SCENES).fill(null);
    const newStatus=new Array(N_SCENES).fill("loading");
    setImgStatus([...newStatus]);
    setImgs([...newImgs]); imgsRef.current=[...newImgs];

    // Sequential (not parallel) — prevents 504 rate-limit errors
    for(let i=0;i<Math.min(ct.scenes.length,N_SCENES);i++){
      const sc=ct.scenes[i];
      addLog(`  🖼 Scene ${i+1}: requesting from Pollinations…`);
      let loaded=false;
      for(let attempt=0;attempt<3&&!loaded;attempt++){
        try{
          if(attempt>0){
            addLog(`  ↻ Scene ${i+1} retry ${attempt}/2…`);
            await new Promise(r=>setTimeout(r,4000*attempt));
          }
          const url=pollinationsUrl(sc.imagePrompt,i,seed+attempt*777);
          const img=await loadImage(url);
          newImgs[i]=img; imgsRef.current=[...newImgs];
          newStatus[i]="ready"; loaded=true;
          setImgs([...newImgs]);
          setImgStatus([...newStatus]);
          addLog(`  ✓ Scene ${i+1} image ready`,"success");
        }catch(e){
          if(attempt===2){
            newStatus[i]="error";
            setImgs([...newImgs]);
            setImgStatus([...newStatus]);
            addLog(`  ⚠ Scene ${i+1} failed — cinematic fallback active`,"error");
          }
        }
      }
      // Breathing room between requests
      if(i<ct.scenes.length-1) await new Promise(r=>setTimeout(r,2000));
    }

    const readyCount=newImgs.filter(Boolean).length;
    addLog(`✓ ${readyCount}/${N_SCENES} images ready — proceeding to record`,"success");
    return true; // always proceed — canvas renders fallback for missing images
  },[addLog]);

  /* ── Record video — video-only stream (Instagram requires H.264/AAC; browser Opus audio causes IG ERROR status) ── */
  const recordVideo=useCallback(()=>new Promise((resolve,reject)=>{
    const cvs=canvasRef.current; if(!cvs)return reject(new Error("no canvas"));
    window.speechSynthesis?.cancel();
    setStatus("recording"); setRecPct(0);

    // Video-only stream — Cloudinary will add silent AAC audio track
    // DO NOT mix browser audio (Opus codec) — Instagram Graph API rejects it
    const canvasStream=cvs.captureStream(30);
    const videoOnlyStream=new MediaStream(canvasStream.getVideoTracks());

    const mime=["video/webm;codecs=vp9","video/webm;codecs=vp8","video/webm"].find(m=>MediaRecorder.isTypeSupported(m))||"video/webm";
    addLog(`🎥 Recording ${REC_S}s — codec: ${mime.split(";")[0]}…`);

    const recorder=new MediaRecorder(videoOnlyStream,{mimeType:mime,videoBitsPerSecond:3_500_000});
    const chunks=[];
    recorder.ondataavailable=e=>{if(e.data.size>0)chunks.push(e.data);};
    recorder.onstop=()=>resolve(new Blob(chunks,{type:mime}));
    recorder.onerror=e=>reject(e.error||new Error("recorder error"));
    recorder.start(300);

    const t0=Date.now();
    const iv=setInterval(()=>{
      const pct=Math.min(100,((Date.now()-t0)/1000/REC_S)*100);
      setRecPct(pct);
      if(pct>=100){clearInterval(iv);recorder.stop();}
    },200);
  }),[addLog]);

  /* ── Upload to Cloudinary — IG-safe MP4 transformation ── */
  const uploadVideo=useCallback(async(blob)=>{
    setStatus("uploading");
    addLog(`☁️ Uploading ${(blob.size/1024/1024).toFixed(1)}MB to Cloudinary…`);
    const fd=new FormData();
    fd.append("file",blob,"cinema.webm");
    fd.append("upload_preset",creds.preset);
    fd.append("resource_type","video");
    const r=await fetch(`https://api.cloudinary.com/v1_1/${creds.cloud}/video/upload`,{method:"POST",body:fd});
    if(!r.ok)throw new Error(`Cloudinary upload failed: ${r.status} — check your preset is "Unsigned"`);
    const d=await r.json();
    if(d.error)throw new Error(`Cloudinary: ${d.error.message}`);

    // Instagram-safe transformation:
    // f_mp4         → MP4 container
    // vc_h264       → H.264 video codec (required by IG)
    // ac_aac        → AAC audio codec (required by IG)
    // br_2m         → 2Mbps bitrate (IG sweet spot — not too large)
    // q_auto:good   → quality optimized
    const publicId=d.public_id;
    const cloudName=creds.cloud;
    const transform="f_mp4,vc_h264,ac_aac,br_2m,q_auto:good";
    const mp4Url=`https://res.cloudinary.com/${cloudName}/video/upload/${transform}/${publicId}.mp4`;

    addLog(`✓ Cloudinary ready — verifying MP4 URL…`);
    // Give Cloudinary 8s to transcode before handing URL to Instagram
    await new Promise(r=>setTimeout(r,8000));
    addLog(`✓ Video hosted: ${mp4Url.slice(0,55)}…`,"success");
    return mp4Url;
  },[creds,addLog]);

  /* ── Post to Instagram — with detailed status logging ── */
  const postToIG=useCallback(async(videoUrl,caption)=>{
    setStatus("posting");
    addLog("📤 Creating Instagram media container…");
    const base="https://graph.facebook.com/v19.0";
    const {igId,igToken}=creds;

    const r1=await(await fetch(`${base}/${igId}/media`,{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        media_type:"REELS",
        video_url:videoUrl,
        caption,
        share_to_feed:true,
        access_token:igToken
      })
    })).json();
    if(r1.error)throw new Error(`IG container error: ${r1.error.message} (code ${r1.error.code})`);
    addLog(`📦 Container ${r1.id} created — IG processing video…`);

    // Poll every 8s (not 5s) — gives IG more breathing room
    for(let i=0;i<30;i++){
      await new Promise(r=>setTimeout(r,8000));
      const sd=await(await fetch(
        `${base}/${r1.id}?fields=status_code,status&access_token=${igToken}`
      )).json();
      const code=sd.status_code||"UNKNOWN";
      addLog(`   [${i+1}/30] IG status: ${code}`);

      if(code==="FINISHED") break;

      if(code==="ERROR"||code==="EXPIRED"){
        // Log full status object for diagnosis
        addLog(`❌ IG rejected video. Status detail: ${JSON.stringify(sd.status||{})}`, "error");
        addLog(`   Common causes: video codec not H.264, file >100MB, duration <3s or >90s`, "error");
        addLog(`   Video URL sent: ${videoUrl}`, "error");
        throw new Error(`IG processing ${code} — see log for details`);
      }
    }

    addLog("🚀 Publishing reel to Instagram…");
    const r3=await(await fetch(`${base}/${igId}/media_publish`,{
      method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({creation_id:r1.id,access_token:igToken})
    })).json();
    if(r3.error)throw new Error(`IG publish error: ${r3.error.message}`);
    addLog(`🎉 REEL IS LIVE! Post ID: ${r3.id}`,"success");
    return r3;
  },[creds,addLog]);

  /* ── Full pipeline ──────────────────────────────────── */
  const pipeline=useCallback(async()=>{
    if(!creds.igId||!creds.igToken||!creds.cloud||!creds.preset||!nicheId){
      addLog("❌ Missing credentials or niche","error"); return;
    }
    try{
      const ct=await generateContent(); if(!ct)return;
      await loadImages(ct);
      await new Promise(r=>setTimeout(r,800)); // let canvas settle
      const blob=await recordVideo(); if(!blob)return;
      addLog(`✓ Recorded ${(blob.size/1024/1024).toFixed(1)}MB`,"success");
      const url=await uploadVideo(blob);
      const r=await postToIG(url,ct.fullCaption);
      const n=NICHES.find(x=>x.id===nicheId);
      setPosts(p=>[{id:r.id,hook:ct.hook,niche:n.label,ts:Date.now()},...p.slice(0,49)]);
      setStatus("done");
      setTimeout(()=>setStatus("idle"),5000);
    }catch(e){
      addLog(`❌ Pipeline error: ${e.message}`,"error");
      setStatus("error");
    }
  },[creds,nicheId,generateContent,loadImages,recordVideo,uploadVideo,postToIG,addLog]);

  /* ══ SETUP WIZARD ════════════════════════════════════ */
  if(!setupDone){
    const steps=[
      {
        title:"Instagram Account",icon:"📱",valid:!!creds.igId&&!!creds.igToken,
        content:(
          <div style={col(14)}>
            <p style={{fontSize:13,color:"#888",lineHeight:1.7,margin:0}}>
              Your credentials from the setup process.
            </p>
            <label style={fieldWrap}>
              <span style={fieldLabel}>INSTAGRAM ACCOUNT ID</span>
              <input type="text" value={creds.igId}
                onChange={e=>setCreds(p=>({...p,igId:e.target.value}))}
                placeholder="17841402485577171" style={inputStyle}/>
            </label>
            <label style={fieldWrap}>
              <span style={fieldLabel}>60-DAY ACCESS TOKEN</span>
              <input type="password" value={creds.igToken}
                onChange={e=>setCreds(p=>({...p,igToken:e.target.value}))}
                placeholder="EAAyKCIs…" style={inputStyle}/>
            </label>
            <div style={infoBox("#e8d5a0")}>
              <strong style={{color:"#e8d5a0"}}>Your credentials:</strong><br/>
              ID: 17841402485577171<br/>
              Token: your EAAyKCIs… 60-day token
            </div>
          </div>
        )
      },
      {
        title:"Video Hosting",icon:"☁️",valid:!!creds.cloud&&!!creds.preset,
        content:(
          <div style={col(14)}>
            <label style={fieldWrap}>
              <span style={fieldLabel}>CLOUDINARY CLOUD NAME</span>
              <input type="text" value={creds.cloud}
                onChange={e=>setCreds(p=>({...p,cloud:e.target.value}))}
                placeholder="my-cloud-name" style={inputStyle}/>
            </label>
            <label style={fieldWrap}>
              <span style={fieldLabel}>UNSIGNED UPLOAD PRESET</span>
              <input type="text" value={creds.preset}
                onChange={e=>setCreds(p=>({...p,preset:e.target.value}))}
                placeholder="instagram_reels" style={inputStyle}/>
            </label>
          </div>
        )
      },
      {
        title:"Niche & Schedule",icon:"🎯",valid:!!nicheId,
        content:(
          <div style={col(18)}>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
              {NICHES.map(n=>(
                <button key={n.id} onClick={()=>setNicheId(n.id)}
                  style={{background:nicheId===n.id?`rgba(${n.rgb},.15)`:"#080810",
                    border:`1px solid ${nicheId===n.id?n.col:"rgba(255,255,255,.08)"}`,
                    borderRadius:10,padding:"14px 8px",cursor:"pointer",
                    display:"flex",flexDirection:"column",alignItems:"center",gap:6,transition:"all .2s"}}>
                  <span style={{fontSize:24}}>{n.emoji}</span>
                  <span style={{fontSize:11,color:nicheId===n.id?n.col:"#555",fontFamily:"monospace"}}>{n.label}</span>
                </button>
              ))}
            </div>
            <div style={col(6)}>
              {SCHEDULES.map((s,i)=>(
                <button key={i} onClick={()=>setSchedIdx(i)}
                  style={{background:schedIdx===i?"rgba(232,213,160,.08)":"#080810",
                    border:`1px solid ${schedIdx===i?"rgba(232,213,160,.35)":"rgba(255,255,255,.07)"}`,
                    borderRadius:8,padding:"11px 14px",cursor:"pointer",width:"100%",
                    display:"flex",justifyContent:"space-between",alignItems:"center",transition:"all .2s"}}>
                  <span style={{fontSize:13,color:schedIdx===i?"#e8d5a0":"#666",fontFamily:"sans-serif"}}>{s.label}</span>
                  <span style={{fontSize:11,color:schedIdx===i?"#e8d5a0":"#333",fontFamily:"monospace"}}>{s.times.join(" · ")}</span>
                </button>
              ))}
            </div>
          </div>
        )
      }
    ];
    const step=steps[setupStep], isLast=setupStep===steps.length-1;
    return(
      <div style={{minHeight:"100vh",background:"#030308",display:"flex",alignItems:"center",justifyContent:"center",padding:20,fontFamily:"monospace"}}>
        <style>{fonts+baseCSS}</style>
        <div style={{width:"100%",maxWidth:520}}>
          <div style={{textAlign:"center",marginBottom:32}}>
            <div style={logoStyle}>INSTAUTO CINEMA</div>
            <div style={{fontSize:10,color:"#333",letterSpacing:4}}>POLLINATIONS.AI × CLAUDE × INSTAGRAM</div>
          </div>
          <div style={{display:"flex",gap:6,marginBottom:24}}>
            {steps.map((_,i)=>(
              <div key={i} style={{height:2,flex:1,borderRadius:1,
                background:i<=setupStep?"#e8d5a0":"rgba(255,255,255,.08)",transition:"background .3s"}}/>
            ))}
          </div>
          <div style={cardStyle}>
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:22}}>
              <div style={{width:38,height:38,background:"rgba(232,213,160,.08)",border:"1px solid rgba(232,213,160,.2)",
                borderRadius:10,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18}}>{step.icon}</div>
              <div>
                <div style={{fontSize:10,color:"#444",letterSpacing:2,marginBottom:3}}>STEP {setupStep+1} OF {steps.length}</div>
                <div style={{fontSize:15,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif"}}>{step.title}</div>
              </div>
            </div>
            {step.content}
          </div>
          <div style={{display:"flex",gap:10}}>
            {setupStep>0&&(
              <button onClick={()=>setSetupStep(p=>p-1)}
                style={{...btnBase,background:"rgba(255,255,255,.04)",color:"#555",border:"1px solid rgba(255,255,255,.08)",width:44}}>
                ←
              </button>
            )}
            <button disabled={!step.valid}
              onClick={()=>{if(isLast){S.set("done",true);setSetupDone(true);}else setSetupStep(p=>p+1);}}
              style={{...btnBase,flex:1,background:step.valid?"#e8d5a0":"rgba(255,255,255,.04)",
                color:step.valid?"#000":"#2a2a2a",cursor:step.valid?"pointer":"not-allowed"}}>
              {isLast?"🎬 Launch Cinema Automation":"Continue →"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ══ MAIN DASHBOARD ══════════════════════════════════ */
  const statusInfo={
    idle:      {label:"Standing by",              col:"#444",   dot:"#222"  },
    generating:{label:"Claude writing story…",    col:"#e8d5a0",dot:"#e8d5a0"},
    imaging:   {label:"Pollinations generating…", col:niche?.col||"#e8d5a0",dot:niche?.col||"#e8d5a0"},
    recording: {label:`Recording… ${Math.round(recPct)}%`,col:"#dc2626",dot:"#dc2626"},
    uploading: {label:"Uploading to Cloudinary…", col:"#0891b2",dot:"#0891b2"},
    posting:   {label:"Posting to Instagram…",    col:"#059669",dot:"#059669"},
    done:      {label:"✓ Reel Posted!",           col:"#4ade80",dot:"#4ade80"},
    error:     {label:"Error — check log",        col:"#f87171",dot:"#f87171"},
  }[status]||{label:"—",col:"#444",dot:"#222"};

  const busy = !["idle","done","error"].includes(status);

  return(
    <div style={{minHeight:"100vh",background:"#030308",color:"#c0c0cc",fontFamily:"monospace",display:"flex",flexDirection:"column"}}>
      <style>{fonts+baseCSS}</style>

      {/* ── Header ── */}
      <div style={{background:"#060610",borderBottom:"1px solid rgba(232,213,160,.1)",
        padding:"12px 20px",display:"flex",alignItems:"center",gap:14,position:"sticky",top:0,zIndex:100}}>
        <div style={logoStyle}>INSTAUTO CINEMA</div>
        {niche&&(
          <div style={{fontSize:11,color:niche.col,background:`rgba(${niche.rgb},.1)`,
            border:`1px solid rgba(${niche.rgb},.25)`,padding:"3px 11px",borderRadius:20}}>
            {niche.emoji} {niche.label}
          </div>
        )}
        <div style={{display:"flex",alignItems:"center",gap:7,marginLeft:"auto"}}>
          <div style={{width:7,height:7,borderRadius:"50%",background:statusInfo.dot,
            boxShadow:`0 0 10px ${statusInfo.dot}`,
            animation:status!=="idle"&&status!=="done"?"pulse 1s infinite":"none"}}/>
          <span style={{fontSize:11,color:statusInfo.col}}>{statusInfo.label}</span>
        </div>
        <button onClick={()=>{setSetupDone(false);setSetupStep(0);S.set("done",false);}}
          style={{...btnBase,padding:"4px 10px",fontSize:10,color:"#333",background:"none",
            border:"1px solid rgba(255,255,255,.06)"}}>⚙ Setup</button>
      </div>

      <div style={{flex:1,display:"grid",gridTemplateColumns:"1fr 290px",overflow:"hidden"}}>
        {/* ── Left panel ── */}
        <div style={{padding:18,overflowY:"auto",borderRight:"1px solid rgba(255,255,255,.04)"}}>

          {/* Automation toggle */}
          <div style={{...cardStyle,marginBottom:14,border:`1px solid ${running?"rgba(232,213,160,.2)":"rgba(255,255,255,.06)"}`}}>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:running?14:0}}>
              <div>
                <div style={{fontSize:14,color:"#e0e0e0",fontWeight:600,fontFamily:"sans-serif",marginBottom:3}}>
                  {running?"Cinema automation running":"Cinema automation paused"}
                </div>
                <div style={{fontSize:11,color:"#444"}}>
                  {running?`Next post in ${nextPost||"…"}`:`${SCHEDULES[schedIdx].label} · ${schedule.join(" · ")}`}
                </div>
              </div>
              <button onClick={()=>setRunning(p=>!p)}
                style={{width:58,height:30,borderRadius:15,background:running?"#e8d5a0":"rgba(255,255,255,.05)",
                  border:`1px solid ${running?"#e8d5a0":"rgba(255,255,255,.1)"}`,
                  cursor:"pointer",position:"relative",flexShrink:0,transition:"all .25s"}}>
                <div style={{position:"absolute",top:3,left:running?29:3,width:22,height:22,
                  background:running?"#000":"#2a2a2a",borderRadius:"50%",transition:"left .22s"}}/>
              </button>
            </div>
            {running&&(
              <div style={{display:"flex",gap:8,alignItems:"center",paddingTop:14,borderTop:"1px solid rgba(255,255,255,.05)"}}>
                <div style={{flex:1,height:3,background:"rgba(255,255,255,.05)",borderRadius:1.5,overflow:"hidden"}}>
                  {status==="recording"&&(
                    <div style={{height:"100%",width:`${recPct}%`,background:`linear-gradient(90deg,${niche?.col||"#e8d5a0"},#fff)`,
                      borderRadius:1.5,transition:"width .25s"}}/>
                  )}
                </div>
                <button onClick={pipeline} disabled={busy}
                  style={{...btnBase,padding:"5px 14px",fontSize:11,
                    background:`rgba(${niche?.rgb||"232,213,160"},.1)`,
                    color:niche?.col||"#e8d5a0",
                    border:`1px solid rgba(${niche?.rgb||"232,213,160"},.25)`}}>
                  ▶ Post Now
                </button>
              </div>
            )}
          </div>

          {/* Canvas preview */}
          <div style={{marginBottom:14}}>
            <button onClick={()=>setShowPrev(p=>!p)}
              style={{...btnBase,width:"100%",justifyContent:"space-between",
                background:"#060610",border:"1px solid rgba(255,255,255,.06)",color:"#444",padding:"10px 16px",marginBottom:showPrev?8:0}}>
              <span>🎬 Cinematic Preview</span>
              <span style={{fontSize:10}}>{showPrev?"▲ HIDE":"▼ SHOW"}</span>
            </button>
            {showPrev&&(
              <div style={{display:"flex",justifyContent:"center",background:"#000",borderRadius:10,
                overflow:"hidden",border:"1px solid rgba(255,255,255,.07)"}}>
                <canvas ref={canvasRef} width={CW} height={CH} style={{display:"block",width:"100%",maxWidth:240}}/>
              </div>
            )}
            {!showPrev&&<canvas ref={canvasRef} width={CW} height={CH} style={{display:"none"}}/>}
          </div>

          {/* Image status grid */}
          {imgStatus.length>0&&(
            <div style={{...cardStyle,marginBottom:14}}>
              <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:10}}>POLLINATIONS.AI — SCENE IMAGES</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
                {Array.from({length:4}).map((_,i)=>{
                  const st=imgStatus[i]||"waiting";
                  const img=imgs[i];
                  return(
                    <div key={i} style={{aspectRatio:"9/16",background:"#000",borderRadius:6,
                      border:`1px solid ${st==="ready"?"rgba(74,222,128,.3)":st==="error"?"rgba(248,113,113,.3)":"rgba(255,255,255,.07)"}`,
                      overflow:"hidden",position:"relative",display:"flex",alignItems:"center",justifyContent:"center"}}>
                      {img&&img.complete&&img.naturalWidth>0
                        ?<img src={img.src} alt={`Scene ${i+1}`} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                        :<div style={{fontSize:16,opacity:.3}}>
                          {st==="loading"?"⏳":st==="error"?"❌":"⬜"}
                        </div>
                      }
                      <div style={{position:"absolute",bottom:3,left:0,right:0,textAlign:"center",
                        fontSize:9,color:"rgba(255,255,255,.5)",fontFamily:"monospace"}}>
                        {st==="ready"?"✓":st==="error"?"✗":st==="loading"?"…":""} S{i+1}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Current story */}
          {content&&(
            <div style={{...cardStyle,marginBottom:14}}>
              <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:10}}>CURRENT STORY</div>
              <div style={{fontSize:14,color:niche?.col||"#e8d5a0",fontWeight:700,
                lineHeight:1.4,marginBottom:12}}>{content.hook}</div>
              <div style={{display:"flex",flexDirection:"column",gap:6}}>
                {content.scenes?.map((sc,i)=>(
                  <div key={i} style={{display:"flex",gap:10,padding:"8px 10px",
                    background:"rgba(255,255,255,.025)",borderRadius:7,
                    border:"1px solid rgba(255,255,255,.05)"}}>
                    <span style={{fontSize:14,flexShrink:0}}>{"🌑🌒🌓🌕"[i]}</span>
                    <div style={{minWidth:0}}>
                      <div style={{fontSize:11,color:niche?.col||"#e8d5a0",fontWeight:600,marginBottom:2}}>{sc.title}</div>
                      <div style={{fontSize:11,color:"#555",lineHeight:1.5,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{sc.sub}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div style={{display:"flex",gap:8,marginTop:12}}>
                <button onClick={()=>{window.speechSynthesis?.cancel();
                  const u=new SpeechSynthesisUtterance(content.voiceover||"");
                  u.rate=0.92;window.speechSynthesis?.speak(u);}}
                  style={{...btnBase,flex:1,fontSize:11,
                    background:`rgba(${niche?.rgb||"232,213,160"},.08)`,
                    color:niche?.col||"#e8d5a0",
                    border:`1px solid rgba(${niche?.rgb||"232,213,160"},.2)`}}>
                  🔊 Preview Voice
                </button>
                <button disabled={busy} onClick={()=>{setContent(null);contentRef.current=null;pipeline();}}
                  style={{...btnBase,flex:1,fontSize:11,background:"rgba(255,255,255,.04)",color:"#555",border:"1px solid rgba(255,255,255,.07)"}}>
                  🔄 Regenerate
                </button>
              </div>
            </div>
          )}

          {/* How it works */}
          <div style={cardStyle}>
            <div style={{fontSize:10,color:"#333",letterSpacing:1,marginBottom:14}}>THE CINEMATIC PIPELINE</div>
            {[
              ["✦","Claude writes the story","Hook → 4-scene arc → voiceover → cinematic image prompts"],
              ["🎨","Pollinations.AI generates 4 FLUX images","Free, no API key — cinematic quality matching professional accounts"],
              ["🎬","Ken Burns animation brings images to life","Slow zoom + pan + film grain + letterbox = cinematic look"],
              ["🎵","Ambient audio recorded into video","Cinematic drone generated live via Web Audio API"],
              ["☁️","Cloudinary transcodes + hosts","Public MP4 URL for Instagram API"],
              ["📤","Instagram posts automatically","Published on your exact schedule — zero effort"],
            ].map(([icon,title,desc],i,arr)=>(
              <div key={i} style={{display:"flex",gap:12,marginBottom:i<arr.length-1?14:0,
                paddingBottom:i<arr.length-1?14:0,borderBottom:i<arr.length-1?"1px solid rgba(255,255,255,.04)":"none"}}>
                <div style={{fontSize:16,flexShrink:0,marginTop:1}}>{icon}</div>
                <div>
                  <div style={{fontSize:12,color:"#c0c0cc",fontWeight:600,fontFamily:"sans-serif",marginBottom:2}}>{title}</div>
                  <div style={{fontSize:11,color:"#3a3a50",lineHeight:1.6}}>{desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Right panel ── */}
        <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>
          <div style={{padding:"14px 14px 10px",borderBottom:"1px solid rgba(255,255,255,.04)",flexShrink:0}}>
            <div style={{fontSize:10,color:"#2a2a3a",letterSpacing:1,marginBottom:8}}>POSTED REELS ({posts.length})</div>
            <div style={{display:"flex",flexDirection:"column",gap:5,maxHeight:200,overflowY:"auto"}}>
              {posts.length===0
                ?<div style={{fontSize:11,color:"#1a1a28",textAlign:"center",padding:"16px 0"}}>No posts yet — flip the toggle</div>
                :posts.map((p,i)=>(
                  <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start",padding:"8px 10px",
                    background:"rgba(74,222,128,.04)",border:"1px solid rgba(74,222,128,.1)",borderRadius:7}}>
                    <div style={{width:5,height:5,borderRadius:"50%",background:"#4ade80",flexShrink:0,marginTop:4}}/>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:11,color:"#c0c0cc",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.hook}</div>
                      <div style={{fontSize:10,color:"#2a2a3a",marginTop:1}}>{p.niche} · {fmt(p.ts)}</div>
                    </div>
                  </div>
                ))
              }
            </div>
          </div>

          <div style={{flex:1,overflow:"hidden",display:"flex",flexDirection:"column",padding:"10px 14px 14px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
              <div style={{fontSize:10,color:"#2a2a3a",letterSpacing:1}}>PIPELINE LOG</div>
              <button onClick={()=>setLog([])}
                style={{...btnBase,padding:"2px 7px",fontSize:9,color:"#2a2a3a",
                  background:"none",border:"1px solid rgba(255,255,255,.05)"}}>CLEAR</button>
            </div>
            <div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:3,fontSize:10}}>
              {log.length===0
                ?<span style={{color:"#111118"}}>Waiting for activity…</span>
                :[...log].reverse().map((l,i)=>(
                  <div key={i} style={{display:"flex",gap:6,alignItems:"flex-start"}}>
                    <span style={{color:"#1a1a28",flexShrink:0}}>{fmt(l.ts)}</span>
                    <span style={{color:l.type==="success"?"#4ade80":l.type==="error"?"#f87171":"#3a3a55",lineHeight:1.5,wordBreak:"break-all"}}>{l.msg}</span>
                  </div>
                ))
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Shared styles ── */
const col=gap=>({display:"flex",flexDirection:"column",gap});
const fieldWrap={display:"flex",flexDirection:"column",gap:5};
const fieldLabel={fontSize:10,fontFamily:"monospace",color:"#444",letterSpacing:1,textTransform:"uppercase"};
const inputStyle={background:"#02020a",border:"1px solid rgba(255,255,255,.08)",borderRadius:6,
  padding:"10px 12px",fontFamily:"monospace",fontSize:12,color:"#d0d0e0",outline:"none",width:"100%"};
const cardStyle={background:"#060612",border:"1px solid rgba(255,255,255,.06)",borderRadius:12,padding:18,marginBottom:0};
const btnBase={border:"none",borderRadius:8,fontFamily:"monospace",fontSize:12,padding:"10px 16px",
  cursor:"pointer",transition:"all .15s",display:"inline-flex",alignItems:"center",justifyContent:"center",gap:6};
const logoStyle={fontSize:15,fontWeight:900,letterSpacing:3,
  background:"linear-gradient(120deg,#e8d5a0,#c8a96e,#e8d5a0)",
  WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",fontFamily:"monospace"};
const infoBox=(col)=>({background:`rgba(${col==="#e8d5a0"?"232,213,160":"99,102,241"},.06)`,
  border:`1px solid rgba(${col==="#e8d5a0"?"232,213,160":"99,102,241"},.18)`,
  borderRadius:8,padding:"10px 14px",fontSize:11,color:"#666",lineHeight:1.8});

const fonts=`@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Space+Mono:wght@400;700&display=swap');`;
const baseCSS=`
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.2}}
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#030308}
  ::-webkit-scrollbar{width:3px}
  ::-webkit-scrollbar-thumb{background:#111128;border-radius:2px}
  input:focus{border-color:rgba(232,213,160,.35)!important;outline:none}
  input::placeholder{color:#111118}
  button:disabled{opacity:.35;cursor:not-allowed!important}
`;
