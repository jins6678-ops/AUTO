import { useState, useEffect, useRef, useCallback } from "react";

// ─── Constants ────────────────────────────────────────────────────────────────

const NICHES = [
  { id: "tech", label: "Tech & AI", emoji: "🤖", color: "#00d4ff", dark: "#001a22" },
  { id: "motivation", label: "Motivation", emoji: "🔥", color: "#ff6b35", dark: "#220d05" },
  { id: "finance", label: "Finance", emoji: "💰", color: "#00e676", dark: "#001a0d" },
  { id: "coding", label: "Coding", emoji: "💻", color: "#a78bfa", dark: "#110d22" },
  { id: "business", label: "Business", emoji: "📈", color: "#ffd54f", dark: "#221b00" },
  { id: "lifestyle", label: "Lifestyle", emoji: "✨", color: "#ff6fd8", dark: "#220011" },
];

const SLOTS = [
  { id: "morning", label: "Morning", time: "09:00", hour: 9, emoji: "🌅", accent: "#fbbf24" },
  { id: "afternoon", label: "Afternoon", time: "13:00", hour: 13, emoji: "⚡", accent: "#f87171" },
  { id: "evening", label: "Evening", time: "19:00", hour: 19, emoji: "🌙", accent: "#a78bfa" },
];

// ─── Canvas Video Renderer ────────────────────────────────────────────────────

function hexToRgb(hex) {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? { r: parseInt(r[1], 16), g: parseInt(r[2], 16), b: parseInt(r[3], 16) } : { r: 100, g: 100, b: 200 };
}

function easeOut(t) { return 1 - Math.pow(1 - Math.min(1, Math.max(0, t)), 3); }

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawWrappedText(ctx, text, cx, cy, maxW, lineH, maxLines = 3) {
  const words = text.split(" ");
  const lines = [];
  let cur = "";
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(test).width > maxW && cur) { lines.push(cur); cur = w; }
    else cur = test;
  }
  if (cur) lines.push(cur);
  const used = lines.slice(0, maxLines);
  const totalH = (used.length - 1) * lineH;
  used.forEach((l, i) => ctx.fillText(l, cx, cy - totalH / 2 + i * lineH));
}

async function createReelVideo(content, nicheColor, handle, onProgress) {
  const W = 540, H = 960, FPS = 30, DURATION = 27;
  const total = FPS * DURATION;
  const canvas = document.createElement("canvas");
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext("2d");
  const rgb = hexToRgb(nicheColor);

  const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
    ? "video/webm;codecs=vp9" : "video/webm";
  const chunks = [];
  const stream = canvas.captureStream(FPS);
  const recorder = new MediaRecorder(stream, { mimeType, videoBitsPerSecond: 2800000 });
  recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };

  return new Promise((resolve, reject) => {
    recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType }));
    recorder.onerror = reject;
    recorder.start(200);

    let frame = 0;
    const tips = content.tips || ["Tip one goes here", "Tip two goes here", "Tip three goes here"];

    function drawBg(t) {
      const g = ctx.createLinearGradient(0, 0, W * 0.5, H);
      const alpha = 0.18;
      g.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},${alpha})`);
      g.addColorStop(0.6, "#04040f");
      g.addColorStop(1, "#020208");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);

      // Animated glow blob
      const bx = W * 0.5 + Math.sin(t * 0.4) * 100;
      const by = H * 0.38 + Math.cos(t * 0.3) * 80;
      const bg2 = ctx.createRadialGradient(bx, by, 0, bx, by, 280);
      bg2.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},0.12)`);
      bg2.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = bg2;
      ctx.fillRect(0, 0, W, H);

      // Grid lines
      ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.04)`;
      ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 54) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      }
      for (let y = 0; y < H; y += 96) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      }
    }

    function drawTopHUD() {
      // Sound badge
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      roundRect(ctx, 16, 18, 148, 34, 17); ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.font = "13px Arial"; ctx.textAlign = "left";
      ctx.fillText("🔊 Turn sound on", 30, 39);

      // Handle
      if (handle) {
        ctx.font = "bold 13px Arial";
        const tw = ctx.measureText(`@${handle}`).width;
        ctx.fillStyle = "rgba(0,0,0,0.55)";
        roundRect(ctx, W - tw - 38, 18, tw + 24, 34, 17); ctx.fill();
        ctx.fillStyle = nicheColor;
        ctx.textAlign = "right";
        ctx.fillText(`@${handle}`, W - 18, 39);
      }
    }

    function drawProgressBar(t) {
      ctx.fillStyle = "rgba(255,255,255,0.08)";
      ctx.fillRect(0, H - 5, W, 5);
      ctx.fillStyle = nicheColor;
      ctx.fillRect(0, H - 5, W * (t / DURATION), 5);
    }

    function drawHookPhase(localT) {
      const fade = easeOut(localT / 1.2);
      ctx.globalAlpha = fade;

      // Eyebrow
      ctx.font = "bold 15px Arial";
      ctx.fillStyle = nicheColor;
      ctx.textAlign = "center";
      ctx.fillText("⚠️  STOP SCROLLING  ⚠️", W / 2, H * 0.32);

      // Main hook
      ctx.font = `bold ${W < 400 ? 32 : 38}px Arial Black, Arial`;
      ctx.fillStyle = "#ffffff";
      ctx.shadowColor = `rgba(${rgb.r},${rgb.g},${rgb.b},0.6)`;
      ctx.shadowBlur = 24;
      drawWrappedText(ctx, content.hook || "This changes everything", W / 2, H * 0.47, W - 70, 48, 3);
      ctx.shadowBlur = 0;

      // Accent bar
      ctx.fillStyle = nicheColor;
      ctx.fillRect(W / 2 - 50, H * 0.635, 100, 3);

      // Swipe hint
      ctx.font = "16px Arial";
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.fillText("👇 Keep watching", W / 2, H * 0.70);

      ctx.globalAlpha = 1;
    }

    function drawTipPhase(tipText, num, localT, slotSecs) {
      const slideIn = easeOut(Math.min(1, localT / 0.9));
      const ox = (1 - slideIn) * 220;

      // Big number bg
      ctx.globalAlpha = 0.12;
      ctx.font = "bold 200px Arial Black";
      ctx.fillStyle = nicheColor;
      ctx.textAlign = "center";
      ctx.fillText(`${num}`, W / 2 + ox, H * 0.56);
      ctx.globalAlpha = 1;

      // Card
      const cardY = H * 0.32;
      const cardH = H * 0.34;
      ctx.fillStyle = "rgba(255,255,255,0.04)";
      ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.35)`;
      ctx.lineWidth = 1.5;
      roundRect(ctx, 28 + ox, cardY, W - 56, cardH, 22);
      ctx.fill(); ctx.stroke();

      // Accent line left
      ctx.fillStyle = nicheColor;
      ctx.fillRect(28 + ox, cardY + 20, 4, cardH - 40);

      // Tip label
      ctx.font = "bold 12px Arial";
      ctx.fillStyle = nicheColor;
      ctx.textAlign = "left";
      ctx.fillText(`TIP ${num} OF 3`, 48 + ox, cardY + 36);

      // Tip text
      ctx.font = "bold 27px Arial Black, Arial";
      ctx.fillStyle = "#ffffff";
      ctx.textAlign = "center";
      drawWrappedText(ctx, tipText, W / 2 + ox, H * 0.515, W - 90, 35, 3);

      // Progress dots
      for (let d = 0; d < 3; d++) {
        ctx.beginPath();
        ctx.arc(W / 2 + ox + (d - 1) * 22, cardY + cardH - 24, d === num - 1 ? 6 : 4, 0, Math.PI * 2);
        ctx.fillStyle = d === num - 1 ? nicheColor : "rgba(255,255,255,0.2)";
        ctx.fill();
      }
    }

    function drawCTAPhase(localT) {
      const fade = easeOut(localT / 0.6);
      ctx.globalAlpha = fade;

      // Gradient overlay
      const ctaG = ctx.createLinearGradient(0, H * 0.25, 0, H);
      ctaG.addColorStop(0, "rgba(0,0,0,0)");
      ctaG.addColorStop(0.5, `rgba(${rgb.r},${rgb.g},${rgb.b},0.15)`);
      ctaG.addColorStop(1, `rgba(${rgb.r},${rgb.g},${rgb.b},0.25)`);
      ctx.fillStyle = ctaG; ctx.fillRect(0, H * 0.25, W, H * 0.75);

      ctx.textAlign = "center";

      ctx.font = "bold 19px Arial";
      ctx.fillStyle = "rgba(255,255,255,0.7)";
      ctx.fillText("Found this useful?", W / 2, H * 0.44);

      ctx.font = "bold 44px Arial Black";
      ctx.fillStyle = "#ffffff";
      ctx.shadowColor = `rgba(${rgb.r},${rgb.g},${rgb.b},0.8)`;
      ctx.shadowBlur = 30;
      ctx.fillText("FOLLOW", W / 2, H * 0.52);
      ctx.shadowBlur = 0;

      if (handle) {
        ctx.font = "bold 26px Arial";
        ctx.fillStyle = nicheColor;
        ctx.fillText(`@${handle}`, W / 2, H * 0.59);
      }

      ctx.font = "bold 20px Arial";
      ctx.fillStyle = "#fbbf24";
      ctx.fillText("🌹  Send a gift if this helped!", W / 2, H * 0.68);

      ctx.font = "16px Arial";
      ctx.fillStyle = "rgba(255,255,255,0.45)";
      ctx.fillText("Like · Comment · Share", W / 2, H * 0.75);

      ctx.globalAlpha = 1;
    }

    const interval = setInterval(() => {
      const t = frame / FPS;
      ctx.clearRect(0, 0, W, H);
      drawBg(t);
      drawTopHUD();

      if (t < 6) drawHookPhase(t);
      else if (t < 13) drawTipPhase(tips[0], 1, t - 6, 7);
      else if (t < 20) drawTipPhase(tips[1], 2, t - 13, 7);
      else if (t < 24) drawTipPhase(tips[2], 3, t - 20, 4);
      else drawCTAPhase(t - 24);

      drawProgressBar(t);

      frame++;
      onProgress?.(frame / total);
      if (frame >= total) { clearInterval(interval); recorder.stop(); }
    }, 1000 / FPS);
  });
}

// ─── Claude AI Content Generation ────────────────────────────────────────────

async function generateContent(nicheId, slotLabel) {
  const niche = NICHES.find(n => n.id === nicheId);
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 800,
      system: "You are a viral Instagram Reels strategist. Output ONLY raw JSON, no markdown, no extra text.",
      messages: [{
        role: "user",
        content: `Create a viral Instagram Reel for the "${niche.label}" niche — ${slotLabel} posting slot.
Return ONLY this JSON:
{
  "hook": "Punchy 7-10 word hook that stops scrolling",
  "tips": ["Actionable tip 1 in 12-18 words", "Actionable tip 2 in 12-18 words", "Actionable tip 3 in 12-18 words"],
  "caption": "Engaging 150-char caption with emojis + CTA to follow + save",
  "hashtags": "#reel1 #reel2 ... 20 space-separated hashtags mixing viral+niche",
  "contentType": "Tutorial|Storytime|POV|Listicle"
}`
      }]
    })
  });
  const d = await res.json();
  if (d.error) throw new Error(d.error.message);
  const txt = d.content.map(c => c.text || "").join("").replace(/```json|```/g, "").trim();
  return JSON.parse(txt);
}

// ─── Instagram Graph API ──────────────────────────────────────────────────────

async function postToInstagram(videoBlob, caption, hashtags, token, userId, onLog) {
  onLog("🚀 Initializing upload session...");

  // Step 1: Get upload session
  const initRes = await fetch(
    `https://graph.facebook.com/v20.0/${userId}/media?media_type=REELS&upload_type=resumable&access_token=${token}`,
    { method: "POST" }
  );
  const { video_id, upload_url, error: e1 } = await initRes.json();
  if (e1) throw new Error(e1.message);
  onLog(`✅ Session ready — video_id: ${video_id.slice(0, 12)}...`);

  // Step 2: Upload bytes
  onLog(`📤 Uploading ${(videoBlob.size / 1048576).toFixed(1)} MB...`);
  const upRes = await fetch(upload_url, {
    method: "POST",
    headers: {
      Authorization: `OAuth ${token}`,
      offset: "0",
      file_size: String(videoBlob.size),
    },
    body: videoBlob,
  });
  const upData = await upRes.json();
  if (!upData.success && !upData.h) throw new Error("Byte upload failed — check token permissions");
  onLog("✅ Video bytes uploaded");

  // Step 3: Create media container
  onLog("📦 Creating media container...");
  const form = new FormData();
  form.append("media_type", "REELS");
  form.append("video_id", video_id);
  form.append("caption", `${caption}\n\n${hashtags}`);
  form.append("share_to_feed", "true");
  form.append("access_token", token);

  const cRes = await fetch(`https://graph.facebook.com/v20.0/${userId}/media`, {
    method: "POST", body: form,
  });
  const { id: containerId, error: e2 } = await cRes.json();
  if (e2) throw new Error(e2.message);
  onLog(`✅ Container: ${containerId}`);

  // Step 4: Poll until FINISHED
  onLog("⏳ Instagram processing video (30–90s)...");
  for (let i = 0; i < 30; i++) {
    await new Promise(r => setTimeout(r, 6000));
    const sRes = await fetch(
      `https://graph.facebook.com/v20.0/${containerId}?fields=status_code&access_token=${token}`
    );
    const { status_code } = await sRes.json();
    onLog(`   › ${status_code}`);
    if (status_code === "FINISHED") break;
    if (status_code === "ERROR") throw new Error("Instagram rejected video (format/duration issue)");
  }

  // Step 5: Publish
  onLog("📱 Publishing Reel...");
  const pubForm = new FormData();
  pubForm.append("creation_id", containerId);
  pubForm.append("access_token", token);
  const pRes = await fetch(`https://graph.facebook.com/v20.0/${userId}/media_publish`, {
    method: "POST", body: pubForm,
  });
  const { id: mediaId, error: e3 } = await pRes.json();
  if (e3) throw new Error(e3.message);
  onLog(`🎉 LIVE! Media ID: ${mediaId}`);
  return mediaId;
}

// ─── UI Components ────────────────────────────────────────────────────────────

const css = `
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap');
* { box-sizing: border-box; margin: 0; padding: 0; }
html,body { background: #030309; }
.app { font-family: 'Outfit', sans-serif; background: #030309; min-height: 100vh; color: #e4e4f0; }

/* ─ Header ─ */
.header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 24px;
  background: rgba(255,255,255,0.02);
  border-bottom: 1px solid rgba(255,255,255,0.06);
  position: sticky; top: 0; z-index: 50; backdrop-filter: blur(12px);
}
.logo { display: flex; align-items: center; gap: 10px; }
.logo-icon {
  width: 34px; height: 34px; border-radius: 9px;
  background: linear-gradient(135deg,#f09433,#e6683c,#dc2743,#bc1888);
  display: flex; align-items: center; justify-content: center; font-size: 16px;
}
.logo-name { font-family: 'Bebas Neue', sans-serif; font-size: 20px; letter-spacing: 1.5px; color: #fff; }
.logo-sub { font-size: 10px; color: #555; font-weight: 500; letter-spacing: 1px; text-transform: uppercase; }
.header-right { display: flex; align-items: center; gap: 10px; }
.dot-badge {
  display: flex; align-items: center; gap: 6px;
  font-size: 11px; padding: 5px 12px; border-radius: 20px; font-weight: 500;
}
.dot-badge.connected { background: rgba(0,230,118,0.1); color: #00e676; border: 1px solid rgba(0,230,118,0.2); }
.dot-badge.offline { background: rgba(255,107,53,0.1); color: #ff6b35; border: 1px solid rgba(255,107,53,0.2); }
.pulse { width: 6px; height: 6px; border-radius: 50%; animation: blink 2s infinite; }
.pulse.on { background: #00e676; }
.pulse.off { background: #ff6b35; }
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.3} }
.settings-btn {
  background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1);
  color: #888; font-size: 16px; width: 34px; height: 34px; border-radius: 8px;
  cursor: pointer; display: flex; align-items: center; justify-content: center;
  transition: all 0.2s;
}
.settings-btn:hover { background: rgba(255,255,255,0.1); color: #e4e4f0; }

/* ─ Setup Screen ─ */
.setup-wrap {
  min-height: 100vh; display: flex; align-items: center; justify-content: center;
  padding: 24px;
  background: radial-gradient(ellipse 60% 50% at 50% 0%, rgba(188,24,136,0.12) 0%, transparent 70%);
}
.setup-card {
  width: 100%; max-width: 560px;
  background: #0b0b18; border: 1px solid rgba(255,255,255,0.08);
  border-radius: 20px; padding: 36px;
}
.setup-title { font-family: 'Bebas Neue', sans-serif; font-size: 36px; letter-spacing: 2px; color: #fff; margin-bottom: 4px; }
.setup-sub { font-size: 13px; color: #555; margin-bottom: 32px; line-height: 1.6; }
.setup-section { margin-bottom: 28px; }
.setup-label { font-size: 11px; font-weight: 700; color: #666; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 10px; display: flex; align-items: center; gap: 6px; }
.setup-input {
  width: 100%; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1);
  color: #e4e4f0; font-family: 'Outfit', sans-serif; font-size: 14px;
  padding: 11px 14px; border-radius: 10px; outline: none; transition: border-color 0.2s;
}
.setup-input:focus { border-color: rgba(188,24,136,0.5); }
.setup-input::placeholder { color: #333; }
.setup-hint { font-size: 11px; color: #444; margin-top: 6px; line-height: 1.5; }
.setup-hint a { color: #bc1888; text-decoration: none; }
.niche-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
.niche-opt {
  background: rgba(255,255,255,0.03); border: 1.5px solid rgba(255,255,255,0.07);
  border-radius: 12px; padding: 14px 8px; cursor: pointer; transition: all 0.2s;
  display: flex; flex-direction: column; align-items: center; gap: 5px; text-align: center;
}
.niche-opt:hover { border-color: rgba(255,255,255,0.15); }
.niche-opt.sel { border-color: var(--nc); background: rgba(0,0,0,0.3); }
.niche-emoji { font-size: 24px; }
.niche-lbl { font-size: 11px; font-weight: 600; color: #666; }
.niche-opt.sel .niche-lbl { color: var(--nc); }
.token-steps { margin-top: 14px; }
.token-step { display: flex; gap: 10px; margin-bottom: 8px; align-items: flex-start; }
.step-n {
  min-width: 20px; height: 20px; border-radius: 50%;
  background: linear-gradient(135deg, #dc2743, #bc1888);
  font-size: 10px; font-weight: 700; display: flex; align-items: center; justify-content: center;
}
.step-t { font-size: 12px; color: #777; line-height: 1.5; }
.step-t b { color: #aaa; }
.start-btn {
  width: 100%; background: linear-gradient(135deg,#f09433,#dc2743,#bc1888);
  border: none; color: #fff; font-family: 'Bebas Neue', sans-serif;
  font-size: 18px; letter-spacing: 2px; padding: 14px; border-radius: 12px;
  cursor: pointer; transition: opacity 0.2s; margin-top: 8px;
}
.start-btn:hover { opacity: 0.88; }
.start-btn:disabled { opacity: 0.35; cursor: not-allowed; }

/* ─ Dashboard ─ */
.dash { padding: 20px 20px 100px; max-width: 1100px; margin: 0 auto; }
.auto-bar {
  display: flex; align-items: center; justify-content: space-between;
  background: #0b0b18; border: 1px solid rgba(255,255,255,0.07);
  border-radius: 14px; padding: 14px 20px; margin-bottom: 20px;
}
.auto-info {}
.auto-title { font-weight: 700; font-size: 15px; margin-bottom: 2px; }
.auto-sub { font-size: 12px; color: #555; }
.auto-times { display: flex; gap: 10px; margin-top: 6px; }
.auto-time-badge { font-size: 11px; color: #888; background: rgba(255,255,255,0.05); border-radius: 6px; padding: 3px 10px; }
.auto-time-badge.active { color: #00e676; background: rgba(0,230,118,0.08); border: 1px solid rgba(0,230,118,0.2); }
.toggle-wrap { display: flex; align-items: center; gap: 10px; }
.toggle-label { font-size: 12px; color: #666; }
.toggle {
  width: 46px; height: 26px; border-radius: 13px; border: none; cursor: pointer;
  position: relative; transition: background 0.3s;
}
.toggle.on { background: linear-gradient(135deg,#dc2743,#bc1888); }
.toggle.off { background: rgba(255,255,255,0.1); }
.toggle-knob {
  width: 20px; height: 20px; background: #fff; border-radius: 50%;
  position: absolute; top: 3px; transition: left 0.3s;
}
.toggle.on .toggle-knob { left: 23px; }
.toggle.off .toggle-knob { left: 3px; }
.slots-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 14px; margin-bottom: 20px; }
.slot-card {
  background: #0b0b18; border: 1px solid rgba(255,255,255,0.07);
  border-radius: 16px; padding: 18px; display: flex; flex-direction: column; gap: 12px;
  min-height: 320px; position: relative; overflow: hidden;
}
.slot-card::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px;
  background: var(--sa, #555);
}
.slot-head { display: flex; align-items: center; justify-content: space-between; }
.slot-name { font-family: 'Bebas Neue', sans-serif; font-size: 18px; letter-spacing: 1px; color: var(--sa); }
.slot-time { font-size: 12px; color: #555; }
.slot-status { display: flex; align-items: center; gap: 5px; font-size: 11px; font-weight: 600; }
.slot-hook { font-size: 13px; color: #aaa; font-style: italic; background: rgba(255,255,255,0.03); padding: 8px 10px; border-radius: 8px; border-left: 2px solid var(--sa); line-height: 1.5; }
.slot-tips { display: flex; flex-direction: column; gap: 5px; }
.slot-tip { font-size: 11px; color: #666; display: flex; gap: 6px; align-items: flex-start; }
.slot-tip span { color: var(--sa); font-size: 10px; font-weight: 700; }
.video-preview {
  border-radius: 8px; overflow: hidden; aspect-ratio: 9/16;
  background: #000; width: 100%; max-height: 160px; object-fit: cover;
}
.progress-bar-wrap { display: flex; align-items: center; gap: 8px; }
.progress-track { flex: 1; height: 4px; background: rgba(255,255,255,0.08); border-radius: 2px; overflow: hidden; }
.progress-fill { height: 100%; background: var(--sa); border-radius: 2px; transition: width 0.1s linear; }
.progress-pct { font-size: 11px; color: #555; min-width: 32px; text-align: right; }
.slot-actions { margin-top: auto; display: flex; flex-direction: column; gap: 6px; }
.act-btn {
  width: 100%; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.09);
  color: #aaa; font-family: 'Outfit', sans-serif; font-size: 12px; font-weight: 600;
  padding: 8px; border-radius: 9px; cursor: pointer; transition: all 0.15s; text-align: center;
}
.act-btn:hover { background: rgba(255,255,255,0.09); color: #e4e4f0; }
.act-btn.primary {
  background: linear-gradient(135deg, rgba(220,39,67,0.25), rgba(188,24,136,0.25));
  border-color: rgba(188,24,136,0.35); color: #ff88cc;
}
.act-btn.primary:hover { background: linear-gradient(135deg, rgba(220,39,67,0.4), rgba(188,24,136,0.4)); }
.act-btn.dl { border-color: rgba(0,212,255,0.2); color: #00d4ff; background: rgba(0,212,255,0.06); }
.act-btn:disabled { opacity: 0.3; cursor: not-allowed; }
.idle-state { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; color: #333; }
.idle-icon { font-size: 36px; opacity: 0.3; }
.idle-text { font-size: 12px; }

/* ─ Log Panel ─ */
.log-panel { background: #0b0b18; border: 1px solid rgba(255,255,255,0.07); border-radius: 14px; overflow: hidden; }
.log-header { padding: 12px 18px; border-bottom: 1px solid rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: space-between; }
.log-title { font-size: 12px; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 1px; }
.log-count { font-size: 11px; color: #444; }
.log-body { height: 160px; overflow-y: auto; padding: 10px 18px; display: flex; flex-direction: column; gap: 4px; }
.log-body::-webkit-scrollbar { width: 3px; }
.log-body::-webkit-scrollbar-thumb { background: #222; border-radius: 2px; }
.log-line { display: flex; gap: 10px; font-size: 11px; }
.log-time { color: #333; min-width: 52px; }
.log-msg { color: #777; }
.log-msg.ok { color: #00e676; }
.log-msg.err { color: #f87171; }
.log-msg.info { color: #00d4ff; }

/* ─ Status colors ─ */
.s-idle { color: #333; }
.s-generating { color: #fbbf24; }
.s-rendering { color: #00d4ff; }
.s-posting { color: #a78bfa; }
.s-ready { color: #00e676; }
.s-posted { color: #00e676; }
.s-error { color: #f87171; }

@media(max-width:700px) {
  .slots-grid { grid-template-columns: 1fr; }
  .niche-grid { grid-template-columns: repeat(2,1fr); }
  .setup-card { padding: 24px; }
}
`;

// ─── Setup Screen ──────────────────────────────────────────────────────────

function SetupScreen({ config, setConfig, onStart }) {
  const valid = config.token && config.userId && config.niche;

  const step = (n, text) => (
    <div className="token-step" key={n}>
      <div className="step-n">{n}</div>
      <div className="step-t" dangerouslySetInnerHTML={{ __html: text }} />
    </div>
  );

  return (
    <div className="setup-wrap">
      <div className="setup-card">
        <div className="setup-title">⚡ REEL AUTO</div>
        <div className="setup-sub">
          Connect your Instagram Creator account. Claude AI will generate scripts, render the Reel videos, and post them 3× daily — automatically.
        </div>

        {/* Niche */}
        <div className="setup-section">
          <div className="setup-label">📌 Your Content Niche</div>
          <div className="niche-grid">
            {NICHES.map(n => (
              <div
                key={n.id}
                className={`niche-opt ${config.niche === n.id ? "sel" : ""}`}
                style={{ "--nc": n.color }}
                onClick={() => setConfig(c => ({ ...c, niche: n.id }))}
              >
                <div className="niche-emoji">{n.emoji}</div>
                <div className="niche-lbl">{n.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Instagram Handle */}
        <div className="setup-section">
          <div className="setup-label">📸 Your Instagram Handle</div>
          <input
            className="setup-input"
            placeholder="yourhandle (without @)"
            value={config.handle}
            onChange={e => setConfig(c => ({ ...c, handle: e.target.value.replace("@","") }))}
          />
        </div>

        {/* Access Token */}
        <div className="setup-section">
          <div className="setup-label">🔑 Instagram Access Token</div>
          <input
            className="setup-input"
            type="password"
            placeholder="EAAxxxxxxxxxxxxxxx..."
            value={config.token}
            onChange={e => setConfig(c => ({ ...c, token: e.target.value.trim() }))}
          />
          <div className="setup-hint">
            <b style={{color:"#666"}}>How to get your token:</b>
          </div>
          <div className="token-steps">
            {step(1, 'Go to <b><a href="https://developers.facebook.com/tools/explorer" target="_blank">Meta Graph API Explorer</a></b>')}
            {step(2, 'Click <b>Generate Access Token</b> → select your Instagram-connected Facebook app')}
            {step(3, 'Add permissions: <b>instagram_basic</b> + <b>instagram_content_publish</b>')}
            {step(4, 'Click <b>Generate Token</b> and paste it here. For long-lived token, exchange it via the token debugger.')}
          </div>
        </div>

        {/* User ID */}
        <div className="setup-section">
          <div className="setup-label">🆔 Instagram Business Account ID</div>
          <input
            className="setup-input"
            placeholder="17841400000000000"
            value={config.userId}
            onChange={e => setConfig(c => ({ ...c, userId: e.target.value.trim() }))}
          />
          <div className="setup-hint">
            Find it: Graph Explorer → type <code style={{color:"#bc1888"}}>me/accounts</code> → click your Page → copy <code style={{color:"#bc1888"}}>instagram_business_account.id</code>
          </div>
        </div>

        <button className="start-btn" disabled={!valid} onClick={onStart}>
          LAUNCH AUTOMATION →
        </button>
      </div>
    </div>
  );
}

// ─── Slot Card ───────────────────────────────────────────────────────────────

function SlotCard({ slot, data, progress, onProcess, onDownload, hasToken }) {
  const st = data.status;
  const statusInfo = {
    idle: { label: "Idle", cls: "s-idle", icon: "⬜" },
    generating: { label: "Generating AI...", cls: "s-generating", icon: "🤖" },
    rendering: { label: "Rendering Video...", cls: "s-rendering", icon: "🎬" },
    posting: { label: "Posting to IG...", cls: "s-posting", icon: "📤" },
    ready: { label: "Ready to Post", cls: "s-ready", icon: "✅" },
    posted: { label: "Live on Instagram!", cls: "s-posted", icon: "🟢" },
    error: { label: "Error", cls: "s-error", icon: "❌" },
  }[st] || { label: st, cls: "", icon: "❓" };

  const busy = ["generating","rendering","posting"].includes(st);

  return (
    <div className="slot-card" style={{ "--sa": slot.accent }}>
      <div className="slot-head">
        <div>
          <div className="slot-name">{slot.emoji} {slot.label}</div>
          <div className="slot-time">{slot.time} daily</div>
        </div>
        <div className={`slot-status ${statusInfo.cls}`}>
          <span>{statusInfo.icon}</span> {statusInfo.label}
        </div>
      </div>

      {st === "idle" || st === "error" ? (
        <div className="idle-state">
          <div className="idle-icon">🎬</div>
          <div className="idle-text">
            {st === "error" ? "⚠️ Failed — try again" : "Waiting to generate…"}
          </div>
        </div>
      ) : (
        <>
          {data.content && (
            <>
              <div className="slot-hook">"{data.content.hook}"</div>
              <div className="slot-tips">
                {(data.content.tips || []).map((t, i) => (
                  <div className="slot-tip" key={i}>
                    <span>0{i + 1}</span> {t}
                  </div>
                ))}
              </div>
            </>
          )}

          {st === "rendering" && (
            <div className="progress-bar-wrap">
              <div className="progress-track">
                <div className="progress-fill" style={{ width: `${(progress || 0) * 100}%` }} />
              </div>
              <div className="progress-pct">{Math.round((progress || 0) * 100)}%</div>
            </div>
          )}

          {data.videoUrl && st !== "rendering" && (
            <video className="video-preview" src={data.videoUrl} muted loop autoPlay playsInline />
          )}
        </>
      )}

      <div className="slot-actions">
        {(st === "idle" || st === "error") && (
          <button className="act-btn primary" disabled={busy} onClick={() => onProcess(slot.id)}>
            ⚡ Generate + Create Video {hasToken ? "+ Post" : "(Download)"}
          </button>
        )}
        {st === "ready" && hasToken && (
          <button className="act-btn primary" disabled={busy} onClick={() => onProcess(slot.id, true)}>
            📱 Post to Instagram Now
          </button>
        )}
        {(st === "ready" || st === "posted") && data.videoUrl && (
          <button className="act-btn dl" onClick={() => onDownload(data.videoUrl, slot.id)}>
            ⬇️ Download Reel (.webm)
          </button>
        )}
        {st === "posted" && (
          <button className="act-btn" onClick={() => onProcess(slot.id)}>
            🔄 Regenerate for Tomorrow
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

const INIT_SLOT = { status: "idle", content: null, videoBlob: null, videoUrl: null };

export default function App() {
  const [page, setPage] = useState("setup");
  const [config, setConfig] = useState({ token: "", userId: "", handle: "", niche: "" });
  const [autoMode, setAutoMode] = useState(false);
  const [slots, setSlots] = useState({
    morning: { ...INIT_SLOT },
    afternoon: { ...INIT_SLOT },
    evening: { ...INIT_SLOT },
  });
  const [progress, setProgress] = useState({});
  const [logs, setLogs] = useState([]);
  const logRef = useRef(null);

  const addLog = useCallback((msg) => {
    const isOk = msg.startsWith("✅") || msg.startsWith("🎉") || msg.startsWith("🟢");
    const isErr = msg.startsWith("❌") || msg.startsWith("⚠️");
    const isInfo = msg.startsWith("🚀") || msg.startsWith("📤") || msg.startsWith("📦") || msg.startsWith("📱") || msg.startsWith("⏳") || msg.startsWith("🤖") || msg.startsWith("🎬");
    setLogs(prev => [
      ...prev.slice(-79),
      { msg, time: new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" }), cls: isOk ? "ok" : isErr ? "err" : isInfo ? "info" : "" }
    ]);
    setTimeout(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, 50);
  }, []);

  const upd = (slotId, patch) => setSlots(p => ({ ...p, [slotId]: { ...p[slotId], ...patch } }));

  const runSlot = useCallback(async (slotId, postOnly = false) => {
    const niche = NICHES.find(n => n.id === config.niche);
    const slot = SLOTS.find(s => s.id === slotId);

    let content = slots[slotId].content;
    let videoBlob = slots[slotId].videoBlob;
    let videoUrl = slots[slotId].videoUrl;

    if (!postOnly) {
      // 1. Generate content
      upd(slotId, { status: "generating", content: null, videoBlob: null, videoUrl: null });
      addLog(`🤖 [${slot.label}] Generating content via Claude AI...`);
      try {
        content = await generateContent(config.niche, slot.label);
        upd(slotId, { content });
        addLog(`✅ Hook: "${content.hook}"`);
      } catch (err) {
        upd(slotId, { status: "error" });
        addLog(`❌ Content generation failed: ${err.message}`);
        return;
      }

      // 2. Render video
      upd(slotId, { status: "rendering" });
      addLog(`🎬 [${slot.label}] Rendering 27s Reel video...`);
      try {
        videoBlob = await createReelVideo(
          content, niche.color, config.handle,
          (p) => setProgress(prev => ({ ...prev, [slotId]: p }))
        );
        videoUrl = URL.createObjectURL(videoBlob);
        upd(slotId, { videoBlob, videoUrl });
        addLog(`✅ Video rendered: ${(videoBlob.size / 1048576).toFixed(1)} MB`);
      } catch (err) {
        upd(slotId, { status: "error" });
        addLog(`❌ Video render failed: ${err.message}`);
        return;
      }
    }

    // 3. Post to Instagram (if token configured)
    if (config.token && config.userId) {
      upd(slotId, { status: "posting" });
      try {
        await postToInstagram(videoBlob, content.caption, content.hashtags, config.token, config.userId, addLog);
        upd(slotId, { status: "posted" });
        addLog(`🟢 [${slot.label}] Reel is LIVE on Instagram!`);
      } catch (err) {
        upd(slotId, { status: "ready" }); // ready = can retry post / download
        addLog(`❌ Instagram post failed: ${err.message}`);
      }
    } else {
      upd(slotId, { status: "ready" });
      addLog(`✅ Video ready — add your Instagram token to auto-post`);
    }
  }, [config, slots, addLog]);

  // Auto scheduler
  useEffect(() => {
    if (!autoMode) return;
    addLog("⏰ Auto-scheduler ON — triggers at 09:00, 13:00, 19:00");
    const timer = setInterval(() => {
      const now = new Date();
      const h = now.getHours(), m = now.getMinutes();
      if (m !== 0) return;
      const map = { 9: "morning", 13: "afternoon", 19: "evening" };
      const sid = map[h];
      if (sid && slots[sid].status === "idle") {
        addLog(`⏰ Scheduler firing: ${sid}`);
        runSlot(sid);
      }
    }, 60000);
    return () => clearInterval(timer);
  }, [autoMode]);

  const download = (url, slotId) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = `reel-${slotId}-${Date.now()}.webm`;
    a.click();
  };

  const niche = NICHES.find(n => n.id === config.niche);
  const now = new Date();

  if (page === "setup") {
    return (
      <>
        <style>{css}</style>
        <div className="app">
          <SetupScreen config={config} setConfig={setConfig} onStart={() => setPage("dash")} />
        </div>
      </>
    );
  }

  return (
    <>
      <style>{css}</style>
      <div className="app">
        {/* Header */}
        <div className="header">
          <div className="logo">
            <div className="logo-icon">📱</div>
            <div>
              <div className="logo-name">REEL AUTO</div>
              <div className="logo-sub">{niche?.emoji} {niche?.label} · @{config.handle || "your account"}</div>
            </div>
          </div>
          <div className="header-right">
            <div className={`dot-badge ${config.token ? "connected" : "offline"}`}>
              <div className={`pulse ${config.token ? "on" : "off"}`} />
              {config.token ? "Instagram Connected" : "No Token — Download Mode"}
            </div>
            <button className="settings-btn" onClick={() => setPage("setup")}>⚙️</button>
          </div>
        </div>

        <div className="dash">
          {/* Auto Mode Bar */}
          <div className="auto-bar">
            <div className="auto-info">
              <div className="auto-title">🤖 Auto-Posting Schedule</div>
              <div className="auto-sub">Runs daily while this tab is open</div>
              <div className="auto-times">
                {SLOTS.map(s => {
                  const isNext = s.hour > now.getHours();
                  return (
                    <div key={s.id} className={`auto-time-badge ${isNext && autoMode ? "active" : ""}`}>
                      {s.emoji} {s.time}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="toggle-wrap">
              <div className="toggle-label">{autoMode ? "AUTO ON" : "AUTO OFF"}</div>
              <button className={`toggle ${autoMode ? "on" : "off"}`} onClick={() => setAutoMode(p => !p)}>
                <div className="toggle-knob" />
              </button>
            </div>
          </div>

          {/* 3 Slot Cards */}
          <div className="slots-grid">
            {SLOTS.map(slot => (
              <SlotCard
                key={slot.id}
                slot={slot}
                data={slots[slot.id]}
                progress={progress[slot.id]}
                onProcess={runSlot}
                onDownload={download}
                hasToken={!!config.token && !!config.userId}
              />
            ))}
          </div>

          {/* Activity Log */}
          <div className="log-panel">
            <div className="log-header">
              <div className="log-title">📋 Activity Log</div>
              <div className="log-count">{logs.length} events</div>
            </div>
            <div className="log-body" ref={logRef}>
              {logs.length === 0 && (
                <div className="log-line"><div className="log-msg" style={{color:"#333"}}>No activity yet. Click a slot to start.</div></div>
              )}
              {logs.map((l, i) => (
                <div className="log-line" key={i}>
                  <div className="log-time">{l.time}</div>
                  <div className={`log-msg ${l.cls}`}>{l.msg}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
